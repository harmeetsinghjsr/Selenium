package utils;

import org.apache.poi.xssf.usermodel.*;
import java.io.*;

public class ExcelUtils
{

    //for writing msg
     static final int COL_ACTUAL = 1;

     //for updating status
     static final int COL_STATUS = 2;

//    private ExcelUtils() {}

    public static XSSFWorkbook loadWorkbook(String path) throws IOException
    {
        FileInputStream file = new FileInputStream(path);
        try (file) {
            XSSFWorkbook book =  new XSSFWorkbook(file);
            return book;
        }
    }

    public static void saveWorkbook(XSSFWorkbook wb, String path) throws IOException
    {
        FileOutputStream fos = new FileOutputStream(path);
        try (fos) {
            wb.write(fos);
        }
    }

    public static void updateStatus(int rowIndex, String actualResult,boolean passed, XSSFSheet testSheet)
    {
        //getting current row from sheet
        XSSFRow row = testSheet.getRow(rowIndex);
        if (row == null) row = testSheet.createRow(rowIndex);

        //getting current cell of current row and setting the value
        XSSFCell actualCell = row.getCell(COL_ACTUAL);
        if (actualCell == null) actualCell = row.createCell(COL_ACTUAL);
        actualCell.setCellValue(actualResult);

        //getting current cell of current row and updating status -> pass/fail
        XSSFCell statusCell = row.getCell(COL_STATUS);
        if (statusCell == null) statusCell = row.createCell(COL_STATUS);
        statusCell.setCellValue(passed ? "PASS" : "FAIL");
    }

    public static XSSFSheet createResultsSheet(XSSFWorkbook wb)
    {
        XSSFSheet sheet = wb.createSheet("Toys Items");
        XSSFRow headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Item Name");
        headerRow.createCell(1).setCellValue("Item Link");
        return sheet;
    }

    public static void writeToyRow(XSSFSheet sheet, int rowNum, String text, String href)
    {
        XSSFRow row = sheet.createRow(rowNum);
        row.createCell(0).setCellValue(text);
        row.createCell(1).setCellValue(href);
    }

    public static void autoSizeResultColumns(XSSFSheet sheet)
    {
        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);
    }
}