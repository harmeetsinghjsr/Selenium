package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AdvancedSearchPage {

    private final WebDriver     driver;
    private final WebDriverWait wait;

    // ── Locators ──────────────────────────────────────────────────────────────
    By keywordsBox       = By.id("_nkw");
    By kwDropdown        = By.id("s0-1-20-4[0]-7[1]-_in_kw");
    By catDropdown       = By.id("s0-1-20-4[0]-7[3]-_sacat");
    By titleDescCb       = By.id("s0-1-20-5[1]-[0]-LH_TitleDesc");
    By newCondCb         = By.id("s0-1-20-6[4]-[0]-LH_ItemCondition");
    By freeReturnsCb     = By.id("s0-1-20-5[5]-[0]-LH_FR");
    By returnsAcceptedCb = By.id("s0-1-20-5[5]-[1]-LH_RPA");
    By worldwideRadio    = By.id("s0-1-20-6[7]-[3]-LH_PrefLoc");
    By searchBtn         = By.xpath(
            "//div[@class='adv-form__actions']//button[@type='submit'][normalize-space()='Search']");

    public AdvancedSearchPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    public void enterKeywords(String keywords) throws InterruptedException {
        WebElement box = wait.until(
                ExpectedConditions.visibilityOfElementLocated(keywordsBox));
        box.clear();
        box.sendKeys(keywords);
        Thread.sleep(1000);
    }

    public void selectKeywordType(String visibleText) throws InterruptedException {
        WebElement kwDropdownElement = driver.findElement(kwDropdown);
        Select     kwDropdownSelect  = new Select(kwDropdownElement);
        kwDropdownSelect.selectByVisibleText(visibleText);
        Thread.sleep(1000);
    }

    public void selectCategory(String visibleText) throws InterruptedException {
        WebElement catDropdownElement = driver.findElement(catDropdown);
        Select     catDropdownSelect  = new Select(catDropdownElement);
        catDropdownSelect.selectByVisibleText(visibleText);
        Thread.sleep(1000);
    }

    public void checkTitleAndDescription() throws InterruptedException {
        WebElement cb = driver.findElement(titleDescCb);
        if (!cb.isSelected()) cb.click();
        Thread.sleep(1000);
    }

    public void checkNewCondition() throws InterruptedException {
        WebElement cb = driver.findElement(newCondCb);
        if (!cb.isSelected()) cb.click();
        Thread.sleep(1000);
    }

    public void checkReturnsOptions() throws InterruptedException {
        WebElement fr = driver.findElement(freeReturnsCb);
        if (!fr.isSelected()) fr.click();
        Thread.sleep(500);

        WebElement ra = driver.findElement(returnsAcceptedCb);
        if (!ra.isSelected()) ra.click();
        Thread.sleep(1000);
    }

    public void selectWorldwideLocation() throws InterruptedException {
        WebElement radio = driver.findElement(worldwideRadio);
        if (!radio.isSelected()) radio.click();
        Thread.sleep(1000);
    }

    // returns void — test class is responsible for creating SearchResultsPage
    public void clickSearch() throws InterruptedException {
        driver.findElement(searchBtn).click();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.titleContains("Toys & Hobbies"));
    }
}