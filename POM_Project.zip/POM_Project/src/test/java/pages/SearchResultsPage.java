package pages;

import org.apache.poi.xssf.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.ExcelUtils;

import java.io.IOException;
import java.util.List;

public class SearchResultsPage {

    private final WebDriver     driver;
    private final WebDriverWait wait;

    public SearchResultsPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    public String getTitle() {
        return driver.getTitle();
    }

    public int getTotalLinkCount() {
        return driver.findElements(By.tagName("a")).size();
    }

    public int saveToysToExcel(String resultsPath) throws IOException, InterruptedException {
        Thread.sleep(1000);
        List<WebElement> allLinks = driver.findElements(By.tagName("a"));

        XSSFWorkbook wb    = new XSSFWorkbook();
        XSSFSheet    sheet = ExcelUtils.createResultsSheet(wb);

        int rowNum = 1, matchCount = 0;

        for (WebElement link : allLinks) {
            String text = link.getText().trim();
            String href = link.getAttribute("href");

            if (href == null || href.isEmpty() || text.isEmpty()) continue;
            System.out.println("HREF: " + href);

            if (text.toLowerCase().contains("toys")) {
                matchCount++;
                System.out.println("Matched [" + matchCount + "]: " + text);
                ExcelUtils.writeToyRow(sheet, rowNum++, text, href);
            }
        }

        ExcelUtils.autoSizeResultColumns(sheet);
        ExcelUtils.saveWorkbook(wb, resultsPath);
        wb.close();
        System.out.println("Results saved to: " + resultsPath);
        return matchCount;
    }
}