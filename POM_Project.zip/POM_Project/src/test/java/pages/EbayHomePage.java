package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EbayHomePage {

    private final WebDriver     driver;
    private final WebDriverWait wait;

    private final By advancedLink = By.linkText("Advanced");

    public EbayHomePage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    public void navigateTo() {
        driver.get("http://www.ebay.com");
    }

    // returns void — test class is responsible for creating the next page object
    public void clickAdvanced() throws InterruptedException {
        WebElement link = wait.until(
                ExpectedConditions.elementToBeClickable(advancedLink));
        link.click();
        Thread.sleep(1000);
    }
}