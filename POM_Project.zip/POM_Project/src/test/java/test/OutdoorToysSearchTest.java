package test;

import base.BaseTest;
import org.apache.poi.xssf.usermodel.*;
import org.testng.annotations.Test;
import pages.AdvancedSearchPage;
import pages.EbayHomePage;
import pages.SearchResultsPage;
import utils.ExcelUtils;

public class OutdoorToysSearchTest extends BaseTest {

    final String testDataPath = System.getProperty("user.dir")+"/excelfiles/Test_Data.xlsx";
    final String resultsPath = System.getProperty("user.dir")+"/eBay_Toys_Results.xlsx";
    // ── Row indices (0-based) ──────────────────────────────────────────────────
    private static final int ROW_LAUNCH      = 1;
    private static final int ROW_MAXIMIZE    = 2;
    private static final int ROW_ADVANCED    = 3;
    private static final int ROW_KEYWORDS    = 4;
    private static final int ROW_CATEGORY    = 5;
    private static final int ROW_TITLE_DESC  = 6;
    private static final int ROW_NEW         = 7;
    private static final int ROW_RETURNS     = 8;
    private static final int ROW_WORLDWIDE   = 9;
    private static final int ROW_SEARCH      = 10;
    private static final int ROW_GET_HREFS   = 11;
    private static final int ROW_VERIFY_TOYS = 12;
    private static final int ROW_CLOSE       = 13;

    @Test
    public void searchOutdoorToys() throws Exception {

        XSSFWorkbook wb    = ExcelUtils.loadWorkbook(testDataPath);
        XSSFSheet    sheet = wb.getSheetAt(0);

        try {
            // Step 1 – Open eBay
            // test class creates EbayHomePage explicitly
            EbayHomePage homePage = new EbayHomePage(driver, wait);
            homePage.navigateTo();
            ExcelUtils.updateStatus(ROW_LAUNCH, "eBay opened successfully", true, sheet);

            // Step 2 – Maximize (done in BaseTest, just log it)
            ExcelUtils.updateStatus(ROW_MAXIMIZE, "Window maximized", true, sheet);

            // Step 3 – Click Advanced
            // clickAdvanced() returns void now — test class creates AdvancedSearchPage itself
            homePage.clickAdvanced();
            AdvancedSearchPage advPage = new AdvancedSearchPage(driver, wait);
            ExcelUtils.updateStatus(ROW_ADVANCED, "Clicked Advanced search", true, sheet);

            // Step 4 – Keywords
            advPage.enterKeywords("outdoor toys");
            advPage.selectKeywordType("Any words, any order");
            ExcelUtils.updateStatus(ROW_KEYWORDS,
                    "Entered 'outdoor toys', selected Any words", true, sheet);

            // Step 5 – Category
            advPage.selectCategory("Toys & Hobbies");
            ExcelUtils.updateStatus(ROW_CATEGORY, "Selected Toys & Hobbies", true, sheet);

            // Step 6 – Title & description
            advPage.checkTitleAndDescription();
            ExcelUtils.updateStatus(ROW_TITLE_DESC,
                    "Title and description checked", true, sheet);

            // Step 7 – New condition
            advPage.checkNewCondition();
            ExcelUtils.updateStatus(ROW_NEW, "New condition checked", true, sheet);

            // Step 8 – Returns
            advPage.checkReturnsOptions();
            ExcelUtils.updateStatus(ROW_RETURNS,
                    "Free returns & Returns accepted checked", true, sheet);

            // Step 9 – Worldwide
            advPage.selectWorldwideLocation();
            ExcelUtils.updateStatus(ROW_WORLDWIDE,
                    "Worldwide location selected", true, sheet);

            // Step 10 – Search
            // clickSearch() returns void now — test class creates SearchResultsPage itself
            advPage.clickSearch();
            SearchResultsPage resultsPage = new SearchResultsPage(driver, wait);
            ExcelUtils.updateStatus(ROW_SEARCH,
                    "Search clicked. Title: " + resultsPage.getTitle(), true, sheet);

            // Step 11 – Grab links
            int totalLinks = resultsPage.getTotalLinkCount();
            ExcelUtils.updateStatus(ROW_GET_HREFS,
                    "Found " + totalLinks + " links on page", true, sheet);

            // Step 12 – Save toy items
            int matchCount = resultsPage.saveToysToExcel(resultsPath);
            ExcelUtils.updateStatus(ROW_VERIFY_TOYS,
                    matchCount + " items with 'toys' written to " + resultsPath,
                    true, sheet);

        } catch (Exception e) {
            System.out.println("Test stopped: " + e.getMessage());
            ExcelUtils.updateStatus(ROW_VERIFY_TOYS,
                    "Test failed: " + e.getMessage(), false, sheet);
            throw e;

        } finally {
            ExcelUtils.updateStatus(ROW_CLOSE, "Browser closed", true, sheet);
            ExcelUtils.saveWorkbook(wb, testDataPath);
            wb.close();
            System.out.println("Saved: " + testDataPath);
        }
    }
}