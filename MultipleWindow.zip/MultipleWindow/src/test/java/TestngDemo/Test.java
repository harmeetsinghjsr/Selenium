package TestngDemo;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class Test {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            driver.get("https://the-internet.herokuapp.com/iframe");

            // 1. Switch to the frame
            driver.switchTo().frame("mce_0_ifr");

            // 2. Wait for the editor body to be clickable/ready
            WebElement editor = wait.until(ExpectedConditions.elementToBeClickable(By.id("tinymce")));

            // 3. Instead of .clear(), use the Keyboard "Select All + Backspace" trick
            editor.click(); // Put focus in the box
            editor.sendKeys(Keys.chord(Keys.CONTROL, "a")); // Select all text
            editor.sendKeys(Keys.BACK_SPACE); // Delete it

            // 4. Type your new message
            editor.sendKeys("Hello Selenium! The clear() method was the problem.");

            // 5. Switch back out to prove it worked
            driver.switchTo().defaultContent();
            System.out.println("Heading: " + driver.findElement(By.tagName("h3")).getText());

        } finally {
            driver.quit();
        }
    }
}