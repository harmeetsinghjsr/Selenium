package TestngDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumDemo {
    public static void main(String[] args) {
        // 1. Initialize the WebDriver (Opens Chrome)
        WebDriver driver = new ChromeDriver();

        try {
            // 2. Navigate to a website
            driver.get("https://www.google.com");

            // 3. Locate the Search Box
            WebElement searchBox = driver.findElement(By.name("q"));

            // 4. Interaction: Type "Selenium", then clear it, then click it
            searchBox.sendKeys("Selenium");
            Thread.sleep(1000); // Small pause just so you can see it happen
            searchBox.clear();
            searchBox.click();

            // 5. Validation: Check Visibility and State
            boolean visible = searchBox.isDisplayed();
            boolean enabled = searchBox.isEnabled();
            System.out.println("Is search box visible? " + visible);
            System.out.println("Is search box enabled? " + enabled);

            // 6. Get Attribute (Checking the placeholder or type)
            String typeValue = searchBox.getAttribute("type");
            System.out.println("The input type is: " + typeValue);

            /* NOTE: The following lines expect specific HTML elements
               that aren't on the Google home page. They are included
               here as examples of how you would write them.
            */

            // Example: Get text from a paragraph <p id="msg">Hello</p>
            // String text = driver.findElement(By.id("msg")).getText();

            // Example: Check a checkbox <input type="checkbox" id="checkbox">
            // boolean checked = driver.findElement(By.id("checkbox")).isSelected();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 7. Close the browser
            driver.quit();
        }
    }
}
