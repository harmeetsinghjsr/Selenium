package org.example;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.*;

public class ExcelUtils {

    // Relative path to Excel file
    private static final String EXCEL_PATH = "test-data/TestData.xlsx";

    public static List<Map<String, String>> readExcelData(String sheetName) {
        List<Map<String, String>> dataList = new ArrayList<>();
        LoggerUtils.log("INFO", "Reading Excel: " + EXCEL_PATH + " | Sheet: " + sheetName);

        try (FileInputStream fis = new FileInputStream(EXCEL_PATH);
             Workbook wb = new XSSFWorkbook(fis)) {

            Sheet sheet = wb.getSheet(sheetName);
            if (sheet == null)
                throw new IllegalArgumentException("Sheet not found: " + sheetName);

            Row header = sheet.getRow(0);
            int cols = header.getLastCellNum();

            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;
                Map<String, String> rowMap = new LinkedHashMap<>();
                for (int c = 0; c < cols; c++) {
                    rowMap.put(cellVal(header.getCell(c)), cellVal(row.getCell(c)));
                }
                dataList.add(rowMap);
            }
            LoggerUtils.log("INFO", "Excel loaded. Rows found: " + dataList.size());

        } catch (IOException e) {
            LoggerUtils.log("ERROR", "Excel read error: " + e.getMessage());
            throw new RuntimeException(e);
        }
        return dataList;
    }

    public static void writeResult(String sheetName, int rowIndex,
                                   String actualValue, String status) {
        try (FileInputStream fis = new FileInputStream(EXCEL_PATH);
             Workbook wb = new XSSFWorkbook(fis)) {

            Sheet sheet = wb.getSheet(sheetName);
            Row headerRow = sheet.getRow(0);

            // Find column indices for "Actual" and "Status"
            int actualColIndex = -1;
            int statusColIndex = -1;

            for (int c = 0; c < headerRow.getLastCellNum(); c++) {
                String headerVal = cellVal(headerRow.getCell(c));
                if ("Actual".equalsIgnoreCase(headerVal))  actualColIndex = c;
                if ("Status".equalsIgnoreCase(headerVal))  statusColIndex = c;
            }

            // Get or create the data row
            Row dataRow = sheet.getRow(rowIndex + 1);
            if (dataRow == null) dataRow = sheet.createRow(rowIndex + 1);

            // Write Actual value
            if (actualColIndex != -1) {
                Cell actualCell = dataRow.getCell(actualColIndex);
                if (actualCell == null) actualCell = dataRow.createCell(actualColIndex);
                actualCell.setCellValue(actualValue);
            }

            // Write Status with color
            if (statusColIndex != -1) {
                Cell statusCell = dataRow.getCell(statusColIndex);
                if (statusCell == null) statusCell = dataRow.createCell(statusColIndex);

                CellStyle style = wb.createCellStyle();
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                if ("PASS".equalsIgnoreCase(status)) {
                    style.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
                } else {
                    style.setFillForegroundColor(IndexedColors.ROSE.getIndex());
                }
                statusCell.setCellStyle(style);
                statusCell.setCellValue(status);
            }

            // Save back to file
            try (FileOutputStream fos = new FileOutputStream(EXCEL_PATH)) {
                wb.write(fos);
            }

            LoggerUtils.log("INFO", "Excel updated → Row " + (rowIndex + 1)
                    + " | Actual: " + actualValue + " | Status: " + status);

        } catch (IOException e) {
            LoggerUtils.log("ERROR", "Failed to write result to Excel: " + e.getMessage());
        }
    }

    // Keep old writeStatus for backward compatibility
    public static void writeStatus(String sheetName, int rowIndex, String status) {
        writeResult(sheetName, rowIndex, "", status);
    }

    private static String cellVal(Cell cell) {
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING  -> cell.getStringCellValue().trim();
            case NUMERIC -> String.valueOf((long) cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            default      -> "";
        };
    }
}