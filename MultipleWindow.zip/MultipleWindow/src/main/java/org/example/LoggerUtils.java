package org.example;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LoggerUtils {

    private static final String LOG_FILE = "test-results/TestResults.log";
    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void log(String level, String message) {
        String entry = String.format("[%s] [%-5s] %s",
                LocalDateTime.now().format(FMT), level, message);
        System.out.println(entry);
        try (PrintWriter pw = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            pw.println(entry);
        } catch (IOException e) {
            System.err.println("Could not write to log file: " + e.getMessage());
        }
    }

    public static void logValidation(String name, boolean condition) {
        if (condition) log("PASS", name + " → PASSED ✔");
        else           log("FAIL", name + " → FAILED ✘");
    }

    public static void logSeparator() {
        log("INFO", "─".repeat(55));
    }
}