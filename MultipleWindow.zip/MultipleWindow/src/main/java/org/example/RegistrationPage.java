package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class RegistrationPage {

    private final WebDriver        driver;
    private final JavascriptExecutor js;

    private final By createAccountLink = By.linkText("Create Account");
    private final By termsLink         = By.linkText("terms and conditions");
    private final By allAnchors        = By.tagName("a");


    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
        this.js     = (JavascriptExecutor) driver;
    }

    // ── Reusable Methods ────────────────────────────────────────────────


    public void clickCreateAccount() {
        try {
            WaitUtils.waitForClickability(driver, createAccountLink).click();
            LoggerUtils.log("INFO", "Clicked 'Create Account' link.");
        } catch (Exception e) {
            LoggerUtils.log("ERROR", "Could not click 'Create Account': " + e.getMessage());
            throw e;
        }
    }

    public boolean isRegistrationPageOpen() {
        try {
            WaitUtils.waitForUrlContains(driver, "register");
            boolean isOpen = driver.getCurrentUrl().contains("register");
            LoggerUtils.log("INFO", "Page Title : " + driver.getTitle());
            LoggerUtils.log("INFO", "Page URL   : " + driver.getCurrentUrl());
            return isOpen;
        } catch (Exception e) {
            LoggerUtils.log("ERROR", "Registration page validation failed: " + e.getMessage());
            return false;
        }
    }

    public int collectAndPrintAllLinks() {
        try {
            List<WebElement> links = driver.findElements(allAnchors);
            int total = links.size();

            LoggerUtils.logSeparator();
            LoggerUtils.log("INFO", "Total links found on page: " + total);
            LoggerUtils.logSeparator();

            int idx = 1;
            for (WebElement link : links) {
                String text = link.getText().trim();
                String href = link.getAttribute("href");
                LoggerUtils.log("INFO", String.format(
                        "Link[%2d] Text: %-28s | URL: %s",
                        idx++,
                        text.isEmpty() ? "(no text)" : text,
                        href != null ? href : "N/A"));
            }
            LoggerUtils.logSeparator();
            return total;

        } catch (Exception e) {
            LoggerUtils.log("ERROR", "Failed to collect links: " + e.getMessage());
            return 0;
        }
    }

    public void clickTermsAndConditions() {
        try {
            WebElement terms = WaitUtils.waitForVisibility(driver, termsLink);
            // Scroll element to center of viewport before clicking
            js.executeScript("arguments[0].scrollIntoView({block:'center'});", terms);
            // JS click used to bypass ElementClickInterceptedException
            js.executeScript("arguments[0].click();", terms);
            LoggerUtils.log("INFO", "Clicked 'terms and conditions' via JS executor.");
        } catch (Exception e) {
            LoggerUtils.log("ERROR", "Could not click 'terms and conditions': " + e.getMessage());
            throw e;
        }
    }

    public String getChildWindowHandle(String parentHandle) {
        try {
            // Wait for child window to open
            WaitUtils.waitForNewWindow(driver, 2);

            for (String handle : driver.getWindowHandles()) {
                if (!handle.equals(parentHandle)) {
                    LoggerUtils.log("INFO", "Child window handle obtained.");
                    return handle;
                }
            }
            throw new RuntimeException("Child window handle not found after waiting.");
        } catch (Exception e) {
            LoggerUtils.log("ERROR", "Failed to get child window: " + e.getMessage());
            throw e;
        }
    }

    public void switchToWindow(String windowHandle) {
        try {
            driver.switchTo().window(windowHandle);
            // Wait until page title is not empty after switching
            new org.openqa.selenium.support.ui.WebDriverWait(driver, java.time.Duration.ofSeconds(10))
                    .until(d -> !d.getTitle().isEmpty());
            LoggerUtils.log("INFO", "Switched to window: [" + driver.getTitle() + "]");
        } catch (Exception e) {
            LoggerUtils.log("ERROR", "Failed to switch window: " + e.getMessage());
            throw e;
        }
    }

    public String getCurrentTitle() {
        return driver.getTitle();
    }

    public void closeCurrentWindow() {
        try {
            LoggerUtils.log("INFO", "Closing window: [" + driver.getTitle() + "]");
            driver.close();
        } catch (Exception e) {
            LoggerUtils.log("ERROR", "Failed to close window: " + e.getMessage());
            throw e;
        }
    }
}