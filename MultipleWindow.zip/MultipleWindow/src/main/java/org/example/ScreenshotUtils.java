package org.example;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ScreenshotUtils {

    private static final String SCREENSHOT_DIR = "test-results/screenshots/";

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    public static String captureScreenshot(WebDriver driver, String testCaseName) {
        String timestamp = LocalDateTime.now().format(FMT);
        String fileName  = testCaseName + "_" + timestamp + ".png";
        String filePath  = SCREENSHOT_DIR + fileName;

        try {
            // Create screenshots directory if it doesn't exist
            File dir = new File(SCREENSHOT_DIR);
            if (!dir.exists()) dir.mkdirs();

            // Take screenshot as file
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            // Copy to destination path
            FileUtils.copyFile(srcFile, new File(filePath));
            LoggerUtils.log("INFO", "Screenshot saved: " + filePath);

        } catch (Exception e) {
            LoggerUtils.log("ERROR", "Screenshot failed: " + e.getMessage());
        }

        return filePath;
    }
}