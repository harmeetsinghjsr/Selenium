package org.example;

import org.testng.Assert;
import org.testng.annotations.*;

import java.util.List;
import java.util.Map;

@Test(singleThreaded = true)
public class RediffWindowTest extends BaseTest {

    private static final int STEP_PAUSE = 2000;

    // Shared across all test methods
    private RegistrationPage page;
    private String           parentHandle;
    private String           childHandle;
    private int              linkCount;

    // Data from Excel
    private String                    browser;
    private String                    url;
    private List<Map<String, String>> allData;

    // Row indices matching Excel rows
    private static final int ROW_TC01 = 0;
    private static final int ROW_TC02 = 1;
    private static final int ROW_TC03 = 2;
    private static final int ROW_TC04 = 3;
    private static final int ROW_TC05 = 4;

    // ── BeforeClass: runs ONCE ────────────────────────────────────────────

    @BeforeClass
    public void setUp() {
        ExtentReportManager.initReport();
        LoggerUtils.logSeparator();
        LoggerUtils.log("INFO", "TEST SUITE STARTING - BROWSER OPENS ONCE");
        LoggerUtils.logSeparator();

        allData = ExcelUtils.readExcelData("TestData");
        browser = allData.get(0).get("Browser");
        url     = allData.get(0).get("URL");

        initDriver(browser);
        page = new RegistrationPage(driver);
        LoggerUtils.log("INFO", "Browser launched: " + browser.toUpperCase());
    }

    // ── TC01 ─────────────────────────────────────────────────────────────

    @Test(priority = 1, description = "Validate Rediff homepage loads")
    public void TC01_ValidateHomePage() {
        ExtentReportManager.startTest("TC01 - Validate Homepage",
                "Validate Rediff homepage loads successfully");
        String expected = allData.get(ROW_TC01).get("Expected");
        String actual   = "";
        String shot     = "";
        try {
            LoggerUtils.logSeparator();
            LoggerUtils.log("INFO", "TC01 - Validate Rediff Homepage");
            ExtentReportManager.logInfo("Opening URL: " + url);

            openUrl(url);
            pause("Opened Rediff homepage");

            actual = driver.getTitle();
            boolean result = actual.toLowerCase().contains(expected.toLowerCase());

            LoggerUtils.log("INFO", "TC01 Expected: " + expected);
            LoggerUtils.log("INFO", "TC01 Actual  : " + actual);
            LoggerUtils.logValidation("TC01 - Homepage loaded", result);

            shot = ScreenshotUtils.captureScreenshot(driver, "TC01");
            ExcelUtils.writeResult("TestData", ROW_TC01, actual, result ? "PASS" : "FAIL");

            if (result) {
                ExtentReportManager.logPass("Homepage loaded. Title: " + actual, shot);
            } else {
                ExtentReportManager.logFail("Homepage failed. Title: " + actual, shot);
            }

            Assert.assertTrue(result, "Homepage did not load!");
            LoggerUtils.log("PASS", "TC01 PASSED ✔");

        } catch (Exception e) {
            shot = ScreenshotUtils.captureScreenshot(driver, "TC01_FAIL");
            ExcelUtils.writeResult("TestData", ROW_TC01, actual, "FAIL");
            ExtentReportManager.logFail("TC01 FAILED: " + e.getMessage(), shot);
            LoggerUtils.log("FAIL", "TC01 FAILED: " + e.getMessage());
            Assert.fail("TC01 failed: " + e.getMessage());
        }
    }

    // ── TC02 ─────────────────────────────────────────────────────────────

    @Test(priority = 2, description = "Validate Registration page opens",
            dependsOnMethods = "TC01_ValidateHomePage")
    public void TC02_ValidateRegistrationPage() {
        ExtentReportManager.startTest("TC02 - Validate Registration Page",
                "Click Create Account and validate registration page opens");
        String expected = allData.get(ROW_TC02).get("Expected");
        String actual   = "";
        String shot     = "";
        try {
            LoggerUtils.logSeparator();
            LoggerUtils.log("INFO", "TC02 - Validate Registration Page");
            ExtentReportManager.logInfo("Clicking Create Account link");

            page.clickCreateAccount();
            parentHandle = driver.getWindowHandle();
            pause("Clicked Create Account");

            actual = driver.getCurrentUrl();
            boolean result = actual.toLowerCase().contains(expected.toLowerCase());

            LoggerUtils.log("INFO", "TC02 Expected: " + expected);
            LoggerUtils.log("INFO", "TC02 Actual  : " + actual);
            LoggerUtils.logValidation("TC02 - Registration page opened", result);

            shot = ScreenshotUtils.captureScreenshot(driver, "TC02");
            ExcelUtils.writeResult("TestData", ROW_TC02, actual, result ? "PASS" : "FAIL");

            if (result) {
                ExtentReportManager.logPass("Registration page opened. URL: " + actual, shot);
            } else {
                ExtentReportManager.logFail("Registration page failed. URL: " + actual, shot);
            }

            Assert.assertTrue(result, "Registration page did not open!");
            LoggerUtils.log("PASS", "TC02 PASSED ✔");

        } catch (Exception e) {
            shot = ScreenshotUtils.captureScreenshot(driver, "TC02_FAIL");
            ExcelUtils.writeResult("TestData", ROW_TC02, actual, "FAIL");
            ExtentReportManager.logFail("TC02 FAILED: " + e.getMessage(), shot);
            LoggerUtils.log("FAIL", "TC02 FAILED: " + e.getMessage());
            Assert.fail("TC02 failed: " + e.getMessage());
        }
    }

    // ── TC03 ─────────────────────────────────────────────────────────────

    @Test(priority = 3, description = "Validate links count on registration page",
            dependsOnMethods = "TC02_ValidateRegistrationPage")
    public void TC03_ValidateLinksCount() {
        ExtentReportManager.startTest("TC03 - Validate Links Count",
                "Count all links on registration page and validate");
        String expected = allData.get(ROW_TC03).get("Expected");
        String actual   = "";
        String shot     = "";
        try {
            LoggerUtils.logSeparator();
            LoggerUtils.log("INFO", "TC03 - Validate Links Count");
            ExtentReportManager.logInfo("Finding all links on page");

            linkCount = page.collectAndPrintAllLinks();
            actual    = String.valueOf(linkCount);
            boolean result = actual.equals(expected);

            LoggerUtils.log("INFO", "TC03 Expected: " + expected);
            LoggerUtils.log("INFO", "TC03 Actual  : " + actual);
            LoggerUtils.logValidation("TC03 - Links count matches", result);

            shot = ScreenshotUtils.captureScreenshot(driver, "TC03");
            ExcelUtils.writeResult("TestData", ROW_TC03, actual, result ? "PASS" : "FAIL");

            if (result) {
                ExtentReportManager.logPass("Links count: " + actual, shot);
            } else {
                ExtentReportManager.logFail("Links count mismatch. Expected: "
                        + expected + " Actual: " + actual, shot);
            }

            Assert.assertTrue(linkCount > 0, "No links found on page!");
            LoggerUtils.log("PASS", "TC03 PASSED ✔");

        } catch (Exception e) {
            shot = ScreenshotUtils.captureScreenshot(driver, "TC03_FAIL");
            ExcelUtils.writeResult("TestData", ROW_TC03, actual, "FAIL");
            ExtentReportManager.logFail("TC03 FAILED: " + e.getMessage(), shot);
            LoggerUtils.log("FAIL", "TC03 FAILED: " + e.getMessage());
            Assert.fail("TC03 failed: " + e.getMessage());
        }
    }

    // ── TC04 ─────────────────────────────────────────────────────────────


    @Test(priority = 4, description = "Validate child window opens",
            dependsOnMethods = "TC03_ValidateLinksCount")
    public void TC04_ValidateChildWindowOpens() {
        ExtentReportManager.startTest("TC04 - Validate Child Window Opens",
                "Click Terms and Conditions and validate child window opens");
        String expected = allData.get(ROW_TC04).get("Expected");
        String actual   = "";
        String shot     = "";
        try {
            LoggerUtils.logSeparator();
            LoggerUtils.log("INFO", "TC04 - Validate Child Window Opens");
            ExtentReportManager.logInfo("Clicking Terms and Conditions link");

            page.clickTermsAndConditions();
            pause("Clicked Terms and Conditions");

            childHandle = page.getChildWindowHandle(parentHandle);
            actual      = String.valueOf(driver.getWindowHandles().size());
            boolean result = actual.equals(expected);

            LoggerUtils.log("INFO", "TC04 Expected windows: " + expected);
            LoggerUtils.log("INFO", "TC04 Actual windows  : " + actual);
            LoggerUtils.logValidation("TC04 - Child window opened", childHandle != null);

            shot = ScreenshotUtils.captureScreenshot(driver, "TC04");
            ExcelUtils.writeResult("TestData", ROW_TC04, actual, result ? "PASS" : "FAIL");

            if (result) {
                ExtentReportManager.logPass("Child window opened. Windows: " + actual, shot);
            } else {
                ExtentReportManager.logFail("Window count mismatch. Expected: "
                        + expected + " Actual: " + actual, shot);
            }

            Assert.assertNotNull(childHandle, "Child window did not open!");
            LoggerUtils.log("PASS", "TC04 PASSED ✔");

        } catch (Exception e) {
            shot = ScreenshotUtils.captureScreenshot(driver, "TC04_FAIL");
            ExcelUtils.writeResult("TestData", ROW_TC04, actual, "FAIL");
            ExtentReportManager.logFail("TC04 FAILED: " + e.getMessage(), shot);
            LoggerUtils.log("FAIL", "TC04 FAILED: " + e.getMessage());
            Assert.fail("TC04 failed: " + e.getMessage());
        }
    }

    // ── TC05 ─────────────────────────────────────────────────────────────

    @Test(priority = 5, description = "Validate child window title",
            dependsOnMethods = "TC04_ValidateChildWindowOpens")
    public void TC05_ValidateChildWindowTitle() {
        ExtentReportManager.startTest("TC05 - Validate Child Window Title",
                "Switch to child window and validate its title");
        String expected = allData.get(ROW_TC05).get("Expected");
        String actual   = "";
        String shot     = "";
        try {
            LoggerUtils.logSeparator();
            LoggerUtils.log("INFO", "TC05 - Validate Child Window Title");
            ExtentReportManager.logInfo("Switching to child window");

            page.switchToWindow(childHandle);
            pause("Switched to child window");

            actual = page.getCurrentTitle();
            boolean result = actual.equalsIgnoreCase(expected);

            LoggerUtils.log("INFO", "TC05 Expected: " + expected);
            LoggerUtils.log("INFO", "TC05 Actual  : " + actual);
            LoggerUtils.logValidation("TC05 - Title matches", result);

            shot = ScreenshotUtils.captureScreenshot(driver, "TC05");
            ExcelUtils.writeResult("TestData", ROW_TC05, actual, result ? "PASS" : "FAIL");

            if (result) {
                ExtentReportManager.logPass("Title matched: " + actual, shot);
            } else {
                ExtentReportManager.logFail("Title mismatch. Expected: "
                        + expected + " Actual: " + actual, shot);
            }

            Assert.assertTrue(result,
                    "Title mismatch! Expected: " + expected + " | Actual: " + actual);

            page.closeCurrentWindow();
            pause("Child window closed");
            ExtentReportManager.logInfo("Child window closed");

            page.switchToWindow(parentHandle);
            LoggerUtils.log("INFO", "TC05 - Back on parent: " + page.getCurrentTitle());
            pause("Back on parent window");
            ExtentReportManager.logInfo("Switched back to parent window");

            LoggerUtils.log("PASS", "TC05 PASSED ✔");

        } catch (Exception e) {
            shot = ScreenshotUtils.captureScreenshot(driver, "TC05_FAIL");
            ExcelUtils.writeResult("TestData", ROW_TC05, actual, "FAIL");
            ExtentReportManager.logFail("TC05 FAILED: " + e.getMessage(), shot);
            LoggerUtils.log("FAIL", "TC05 FAILED: " + e.getMessage());
            Assert.fail("TC05 failed: " + e.getMessage());
        }
    }

    // ── AfterClass: runs ONCE ─────────────────────────────────────────────

    @AfterClass
    public void tearDownSuite() {
        pause("All tests done - closing browser");
        ExtentReportManager.flushReport();
        tearDown();
        LoggerUtils.logSeparator();
        LoggerUtils.log("INFO", "TEST SUITE COMPLETE - BROWSER CLOSED");
        LoggerUtils.logSeparator();
    }

    private void pause(String stepDescription) {
        try {
            LoggerUtils.log("INFO", "  >> " + stepDescription
                    + "  [pause " + (STEP_PAUSE / 1000) + "s]");
            Thread.sleep(STEP_PAUSE);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}