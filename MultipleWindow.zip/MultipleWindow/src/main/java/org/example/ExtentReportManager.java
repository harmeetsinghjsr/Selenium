package org.example;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager {

    // Relative path for the HTML report
    private static final String REPORT_PATH = "test-results/ExtentReport.html";

    // Single ExtentReports instance shared across all tests
    private static ExtentReports extent;

    // One ExtentTest per test case (thread-local for safety)
    private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    public static void initReport() {
        ExtentSparkReporter spark = new ExtentSparkReporter(REPORT_PATH);
        spark.config().setTheme(Theme.DARK);
        spark.config().setDocumentTitle("Rediff Automation Report");
        spark.config().setReportName("Rediffmail Multiple Window Test Results");
        spark.config().setTimeStampFormat("yyyy-MM-dd HH:mm:ss");

        extent = new ExtentReports();
        extent.attachReporter(spark);
        extent.setSystemInfo("Project",     "Rediffmail Multiple Window");
        extent.setSystemInfo("Browser",     "Chrome");
        extent.setSystemInfo("Environment", "https://www.rediff.com/");
        extent.setSystemInfo("Tester",      "Automation Team");

        LoggerUtils.log("INFO", "ExtentReport initialized: " + REPORT_PATH);
    }

    public static void startTest(String testName, String description) {
        ExtentTest extentTest = extent.createTest(testName, description);
        test.set(extentTest);
    }

    public static void logInfo(String message) {
        test.get().log(Status.INFO, message);
    }

    public static void logPass(String message, String screenshotPath) {
        try {
            test.get().pass(message,
                    com.aventstack.extentreports.MediaEntityBuilder
                            .createScreenCaptureFromPath(screenshotPath).build());
        } catch (Exception e) {
            test.get().pass(message);
        }
    }

    public static void logFail(String message, String screenshotPath) {
        try {
            test.get().fail(message,
                    com.aventstack.extentreports.MediaEntityBuilder
                            .createScreenCaptureFromPath(screenshotPath).build());
        } catch (Exception e) {
            test.get().fail(message);
        }
    }

    public static void flushReport() {
        if (extent != null) {
            extent.flush();
            LoggerUtils.log("INFO", "ExtentReport saved: " + REPORT_PATH);
        }
    }
}