package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import java.time.Duration;

public class BaseTest {

    protected WebDriver driver;
    public void initDriver(String browserName) {
        LoggerUtils.log("INFO", "Launching browser: " + browserName);

        switch (browserName.trim().toLowerCase()) {

            case "chrome":
                WebDriverManager.chromedriver().setup();
                ChromeOptions co = new ChromeOptions();
                co.addArguments("--start-maximized");
                driver = new ChromeDriver(co);
                break;

            case "edge":
                // Manually set EdgeDriver path - avoids network download (corporate network)
                // Replace the version number below with YOUR actual Edge version folder name
                // Check: C:\Program Files (x86)\Microsoft\Edge\Application\<version>\msedgedriver.exe
                System.setProperty("webdriver.edge.driver",
                        "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\146.0.3856.97\\msedgedriver.exe");
                EdgeOptions eo = new EdgeOptions();
                eo.addArguments("--start-maximized");
                driver = new EdgeDriver(eo);
                break;

            default:
                throw new IllegalArgumentException(
                        "Unknown browser: " + browserName + ". Use 'chrome' or 'edge'.");
        }

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        LoggerUtils.log("INFO", browserName + " launched successfully.");
    }

    public void openUrl(String url) {
        driver.get(url);
        LoggerUtils.log("INFO", "Opened URL: " + driver.getCurrentUrl());
    }

    public void tearDown() {
        if (driver != null) {
            driver.quit();
            LoggerUtils.log("INFO", "Browser closed.");
        }
    }
}