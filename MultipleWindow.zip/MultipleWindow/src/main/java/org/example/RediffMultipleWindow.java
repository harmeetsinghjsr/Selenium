package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;
import java.util.List;
import java.util.Set;

public class RediffMultipleWindow {
    public static void main(String[] args) throws InterruptedException {
        // ── 1. Launch Browser ──────────────────────────────────────────────
        ChromeOptions options = new ChromeOptions();
        WebDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

        try {
            // ── 2. Enter the URL ───────────────────────────────────────────
            driver.get("https://www.rediff.com/");
            System.out.println("Launched URL : " + driver.getCurrentUrl());

            // ── 3. Click on "Create Account" link ─────────────────────────
            // The homepage has a "Create Account" link in the top navigation
            WebElement createAccountLink = driver.findElement(
                    By.xpath("//a[contains(text(),'Create Account')]"));
            createAccountLink.click();
            System.out.println("Clicked 'Create Account' link.");

            Thread.sleep(2000);

            // Store parent window handle (Create Rediffmail account page)
            String parentWindow = driver.getWindowHandle();

            // ── 4. Validate "Create Rediffmail account" page is opened ─────
            String pageTitle = driver.getTitle();
            String pageUrl   = driver.getCurrentUrl();
            System.out.println("\n── Page Validation ──────────────────────────────────");
            System.out.println("Page Title : " + pageTitle);
            System.out.println("Page URL   : " + pageUrl);

            // Validate by checking the heading text present on the page
            WebElement heading = driver.findElement(
                    By.xpath("//h1[contains(text(),'Create a Rediffmail account')] | " +
                            "//div[contains(text(),'Create a Rediffmail account')] | " +
                            "//*[contains(text(),'Create a Rediffmail account')]"));

            boolean isCreatePage = heading.isDisplayed();
            System.out.println("'Create a Rediffmail account' page opened? : "
                    + (isCreatePage ? "YES ✔" : "NO ✘"));

            // ── 5. Find total number of links & print them ─────────────────
            List<WebElement> allLinks = driver.findElements(By.tagName("a"));

            System.out.println("\n── Links on 'Create Rediffmail Account' Page ────────");
            System.out.println("Total number of links found : " + allLinks.size());
            System.out.println("─".repeat(70));

            int count = 1;
            for (WebElement link : allLinks) {
                String text = link.getText().trim();
                String href = link.getAttribute("href");
                href = (href != null) ? href : "N/A";
                System.out.printf("  Link [%2d] | Text : %-30s | URL : %s%n",
                        count++, text.isEmpty() ? "(no text)" : text, href);
            }
            System.out.println("─".repeat(70));

            // ── 6. Click on "terms and conditions" link ────────────────────
            // As seen in screenshot: footer text contains "terms and conditions" hyperlink
            // "...you confirm that you accept the terms and conditions & privacy policy"
            WebElement termsLink = driver.findElement(
                    By.xpath("//a[contains(translate(text()," +
                            "'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," +
                            "'terms and conditions')]"));

            System.out.println("\nFound link : " + termsLink.getText());
            System.out.println("Href value : " + termsLink.getAttribute("href"));

            // Scroll the element into view first
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView({block:'center'});", termsLink);
            Thread.sleep(1000);

            // Use JS click to bypass ElementClickInterceptedException
            // (Element is blocked by an overlay/sticky footer at point 785,896)
            System.out.println("Clicking 'terms and conditions' via JavaScript executor...");
            js.executeScript("arguments[0].click();", termsLink);

            Thread.sleep(2000); // wait for child window to open

            // ── 7. Validate child window "Terms and Conditions" is opened ──
            Set<String> allWindows = driver.getWindowHandles();
            String childWindow = null;

            for (String win : allWindows) {
                if (!win.equals(parentWindow)) {
                    childWindow = win;
                    break;
                }
            }

            System.out.println("\n── Child Window Validation ──────────────────────────");
            System.out.println("Total windows open : " + allWindows.size());
            boolean childOpened = (childWindow != null);
            System.out.println("Child window opened? : " + (childOpened ? "YES ✔" : "NO ✘"));

            if (childOpened) {

                // ── 8. Switch to the child window ─────────────────────────
                driver.switchTo().window(childWindow);
                System.out.println("Switched to child window successfully.");

                // ── 9. Get the title of the child window ──────────────────
                String childTitle = driver.getTitle();
                System.out.println("Child Window Title : " + childTitle);

                // ── 10. Validate the title of the child window ────────────
                String expectedTitle = "Terms and Conditions";
                boolean titleMatch   = childTitle.toLowerCase()
                        .contains(expectedTitle.toLowerCase());

                System.out.println("Expected Title     : " + expectedTitle);
                System.out.println("Title Validation   : " + (titleMatch ? "PASS ✔" : "FAIL ✘"));

                // ── 11. Close the child window ─────────────────────────────
                driver.close();
                System.out.println("\nChild window closed.");

                // ── 12. Switch back to parent window ──────────────────────
                driver.switchTo().window(parentWindow);
                System.out.println("Switched back to parent window.");
                System.out.println("Parent Window Title: " + driver.getTitle());

            } else {
                System.out.println("Child window did NOT open. " +
                        "Terms link may have navigated within the same tab.");
            }

        } catch (Exception e) {
            System.err.println("\nTest FAILED — Exception: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // ── 13. Close the browser ──────────────────────────────────────
            Thread.sleep(2000);
            driver.quit();
            System.out.println("\nBrowser closed. Execution complete.");
        }
    }
}