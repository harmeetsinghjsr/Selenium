import { google } from 'googleapis'

function getCalendarClient() {
  const auth = new google.auth.GoogleAuth({
    credentials: {
      client_email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
      private_key:  process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    },
    scopes: ['https://www.googleapis.com/auth/calendar'],
  })
  return google.calendar({ version: 'v3', auth })
}

export async function createCalendarEvent(data: {
  summary: string; description: string
  startDateTime: string; endDateTime: string
  attendeeEmail: string
}) {
  const calendar = getCalendarClient()
  const event = await calendar.events.insert({
    calendarId: process.env.GOOGLE_CALENDAR_ID!,
    requestBody: {
      summary:     data.summary,
      description: data.description,
      start:  { dateTime: data.startDateTime, timeZone: 'Asia/Kolkata' },
      end:    { dateTime: data.endDateTime,   timeZone: 'Asia/Kolkata' },
      attendees: [{ email: data.attendeeEmail }],
      conferenceData: {
        createRequest: { requestId: `kt_${Date.now()}` },
      },
      reminders: {
        useDefault: false,
        overrides:  [
          { method: 'email', minutes: 24 * 60 },
          { method: 'popup', minutes: 30 },
        ],
      },
    },
    conferenceDataVersion: 1,
    sendUpdates: 'all',
  })
  return event.data
}
