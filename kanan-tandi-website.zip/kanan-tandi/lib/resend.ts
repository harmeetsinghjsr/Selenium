import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)
const FROM   = process.env.FROM_EMAIL || 'hello@kanantandi.com'

export async function sendBookingConfirmation(data: {
  name: string; email: string; service: string; date: string; slot: string; paymentId?: string
}) {
  await resend.emails.send({
    from:    FROM,
    to:      data.email,
    subject: 'Your Session is Confirmed — Kanan Tandi',
    html: `
      <div style="font-family:Georgia,serif;max-width:600px;margin:0 auto;background:#0a0908;color:#f5f0e8;padding:40px;">
        <h1 style="font-size:28px;font-weight:300;color:#c9a96e;margin-bottom:8px;">Session Confirmed ✓</h1>
        <p style="color:#9e9891;margin-bottom:30px;">Thank you for booking, ${data.name}.</p>
        <div style="border:1px solid #2c2824;padding:24px;margin-bottom:30px;">
          <p style="margin:0 0 12px;"><strong style="color:#c9a96e;font-size:11px;letter-spacing:2px;text-transform:uppercase;">Service</strong><br/>${data.service}</p>
          <p style="margin:0 0 12px;"><strong style="color:#c9a96e;font-size:11px;letter-spacing:2px;text-transform:uppercase;">Date &amp; Time</strong><br/>${data.date} at ${data.slot}</p>
          ${data.paymentId ? `<p style="margin:0;"><strong style="color:#c9a96e;font-size:11px;letter-spacing:2px;text-transform:uppercase;">Payment ID</strong><br/>${data.paymentId}</p>` : ''}
        </div>
        <p style="color:#9e9891;font-size:14px;line-height:1.8;">
          Kanan will share the meeting link within 24 hours. If you have any questions,
          reply to this email or WhatsApp +91 98765 43210.
        </p>
        <p style="color:#6b6560;font-size:12px;margin-top:40px;">
          With gratitude,<br/>Kanan Tandi<br/><a href="https://kanantandi.com" style="color:#c9a96e;">kanantandi.com</a>
        </p>
      </div>
    `,
  })
}

export async function sendContactNotification(data: {
  name: string; email: string; subject: string; message: string
}) {
  await resend.emails.send({
    from:    FROM,
    to:      process.env.ADMIN_EMAIL || FROM,
    subject: `New Contact: ${data.subject} — ${data.name}`,
    html: `
      <div style="font-family:Georgia,serif;max-width:600px;padding:40px;">
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> ${data.name}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Subject:</strong> ${data.subject}</p>
        <p><strong>Message:</strong></p>
        <p>${data.message}</p>
      </div>
    `,
  })
}

export async function sendNewsletterWelcome(email: string) {
  await resend.emails.send({
    from:    FROM,
    to:      email,
    subject: 'Welcome to the Inner Circle — Kanan Tandi',
    html: `
      <div style="font-family:Georgia,serif;max-width:600px;margin:0 auto;background:#0a0908;color:#f5f0e8;padding:40px;">
        <h1 style="font-size:24px;font-weight:300;color:#c9a96e;">Welcome to the Inner Circle</h1>
        <p style="color:#9e9891;line-height:1.8;">
          Thank you for subscribing. Every week, you'll receive carefully curated insights on body language,
          psychology, executive presence, and personal transformation — directly from Kanan.
        </p>
        <p style="color:#9e9891;line-height:1.8;">Stay curious. Stay present.</p>
        <p style="color:#6b6560;font-size:12px;margin-top:30px;">
          — Kanan Tandi<br/>
          <a href="https://kanantandi.com" style="color:#c9a96e;">kanantandi.com</a>
        </p>
      </div>
    `,
  })
}
