import { createClient } from '@sanity/client'
import imageUrlBuilder from '@sanity/image-url'

export const client = createClient({
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || 'your-project-id',
  dataset:   process.env.NEXT_PUBLIC_SANITY_DATASET   || 'production',
  apiVersion: '2024-01-01',
  useCdn:    true,
  token:     process.env.SANITY_API_TOKEN,
})

const builder = imageUrlBuilder(client)
export function urlForImage(source: any) {
  return builder.image(source)
}
