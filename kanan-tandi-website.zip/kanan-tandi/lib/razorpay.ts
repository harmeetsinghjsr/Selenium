import Razorpay from 'razorpay'
import crypto from 'crypto'

export const razorpay = new Razorpay({
  key_id:     process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_SECRET!,
})

export async function createOrder(amount: number) {
  const order = await razorpay.orders.create({
    amount:   amount * 100,
    currency: 'INR',
    receipt:  `rcpt_${Date.now()}`,
  })
  return order
}

export function verifyPaymentSignature(
  orderId: string,
  paymentId: string,
  signature: string
): boolean {
  const body      = `${orderId}|${paymentId}`
  const expected  = crypto
    .createHmac('sha256', process.env.RAZORPAY_SECRET!)
    .update(body)
    .digest('hex')
  return expected === signature
}
