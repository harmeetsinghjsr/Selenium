const WEBHOOK_URL = process.env.APPS_SCRIPT_WEBHOOK_URL!

export async function logToSheets(type: string, data: Record<string, unknown>) {
  if (!WEBHOOK_URL) {
    console.warn('APPS_SCRIPT_WEBHOOK_URL not set — skipping sheet log')
    return
  }
  try {
    await fetch(WEBHOOK_URL, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ type, timestamp: new Date().toISOString(), ...data }),
    })
  } catch (err) {
    console.error('Google Sheets logging failed:', err)
  }
}

// ----- Apps Script code (deploy at script.google.com) -----
// Paste this in your Google Apps Script project:
/*
function doPost(e) {
  try {
    const data   = JSON.parse(e.postData.contents)
    const ss     = SpreadsheetApp.getActiveSpreadsheet()
    const sheet  = ss.getSheetByName(data.type) || ss.insertSheet(data.type)

    if (sheet.getLastRow() === 0) {
      sheet.appendRow(Object.keys(data))
    }
    sheet.appendRow(Object.values(data))

    return ContentService
      .createTextOutput(JSON.stringify({ status: 'ok' }))
      .setMimeType(ContentService.MimeType.JSON)
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON)
  }
}
*/
