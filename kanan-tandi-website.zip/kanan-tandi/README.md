# Kanan Tandi — Premium Brand Website

> Complete Next.js 14 production website for body language & psychology expert Kanan Tandi.

---

## 🚀 Quick Start (5 minutes to localhost)

```bash
# 1. Install dependencies
npm install

# 2. Copy env file
cp .env.local.example .env.local

# 3. Fill in at minimum:
#    NEXT_PUBLIC_RAZORPAY_KEY_ID
#    RAZORPAY_KEY_ID + RAZORPAY_SECRET
#    RESEND_API_KEY
#    NEXTAUTH_SECRET  (run: openssl rand -base64 32)
#    ADMIN_PASSWORD_HASH  (see below)

# 4. Run dev server
npm run dev
```

Open http://localhost:3000 — site works with demo data even without Sanity/Sheets connected.

---

## 📦 What's Inside

### Pages (19 total)
| Route | Description |
|-------|-------------|
| `/` | Homepage — hero, services, testimonials, blog, CTA |
| `/about` | About Kanan — bio, timeline, stats |
| `/services` | All 6 services with details |
| `/book` | Full booking system with calendar + Razorpay |
| `/courses` | Course listing |
| `/courses/[slug]` | Individual course detail with curriculum |
| `/workshops` | Workshop listings with pricing |
| `/corporate` | Corporate training page |
| `/blog` | Blog listing |
| `/blog/[slug]` | Individual blog post |
| `/testimonials` | Full testimonials page |
| `/media` | Press & podcast features |
| `/contact` | Contact form |
| `/faq` | Accordion FAQ |
| `/privacy` | Privacy policy |
| `/terms` | Terms & conditions |
| `/refund` | Refund policy |
| `/admin` | Admin dashboard |
| `/admin/bookings` | Bookings management |
| `/admin/courses` | Course CRUD |
| `/admin/blogs` | Blog management |
| `/admin/leads` | Contact leads |
| `/admin/availability` | Availability settings |

### Tech Stack
- **Frontend**: Next.js 14 App Router + TypeScript + Tailwind CSS
- **Fonts**: Cormorant Garamond (serif) + Outfit (sans)
- **CMS**: Sanity.io (optional — site works with demo data without it)
- **Payments**: Razorpay (INR, UPI, cards, EMI)
- **Email**: Resend (booking confirmations, contact notifications, newsletter)
- **Database**: Google Sheets via Apps Script webhook (free, zero infra)
- **Calendar**: Google Calendar API via service account
- **Auth**: NextAuth.js (credentials-based admin login)
- **Hosting**: Vercel (recommended)

---

## 🔑 Environment Variables

Copy `.env.local.example` to `.env.local` and fill these:

### Required (site won't work without these)
```
RAZORPAY_KEY_ID=rzp_live_xxx
RAZORPAY_SECRET=xxx
NEXT_PUBLIC_RAZORPAY_KEY_ID=rzp_live_xxx
NEXTAUTH_SECRET=xxx   # openssl rand -base64 32
NEXTAUTH_URL=https://yourdomain.com
ADMIN_PASSWORD_HASH=xxx   # see below
```

### Recommended
```
RESEND_API_KEY=re_xxx
FROM_EMAIL=hello@kanantandi.com
ADMIN_EMAIL=kanan@kanantandi.com
```

### Optional (extra features)
```
NEXT_PUBLIC_SANITY_PROJECT_ID=xxx    # for CMS
NEXT_PUBLIC_SANITY_DATASET=production
SANITY_API_TOKEN=xxx
APPS_SCRIPT_WEBHOOK_URL=xxx          # for Google Sheets logging
GOOGLE_CALENDAR_ID=xxx               # for auto-calendar events
GOOGLE_SERVICE_ACCOUNT_EMAIL=xxx
GOOGLE_PRIVATE_KEY=xxx
```

---

## 🔐 Admin Setup

### 1. Generate password hash
```bash
node -e "const b=require('bcryptjs'); console.log(b.hashSync('YourPassword123', 10))"
```

### 2. Add to .env.local
```
ADMIN_PASSWORD_HASH=$2b$10$xxxxxxxxxxxxxxxxxxxxx
```

### 3. Access admin panel
Go to `/admin` → enter your password → full dashboard access.

---

## 💳 Razorpay Setup

1. Create account at https://dashboard.razorpay.com
2. Get API keys from Settings → API Keys
3. Use `rzp_test_xxx` for testing, `rzp_live_xxx` for production
4. Add keys to `.env.local`

---

## 📧 Resend Email Setup

1. Sign up at https://resend.com (free: 100 emails/day)
2. Add & verify your domain (kanantandi.com)
3. Create API key → add to `.env.local`
4. Emails sent: booking confirmations, contact notifications, newsletter welcome

---

## 📊 Google Sheets Setup (Free Database)

1. Create a new Google Sheet
2. Open Extensions → Apps Script
3. Paste the Apps Script code from `lib/google-sheets.ts` (see comment at bottom of file)
4. Deploy as Web App (access: Anyone)
5. Copy deployment URL → add as `APPS_SCRIPT_WEBHOOK_URL`

All bookings, leads, and newsletter signups will auto-log to sheets.

---

## 📅 Google Calendar Setup

1. Create a Google Cloud project
2. Enable Calendar API
3. Create a Service Account → download JSON key
4. Share your Google Calendar with the service account email
5. Add credentials to `.env.local`

---

## 🎨 Sanity CMS Setup (Optional)

Without Sanity, the site uses built-in demo data for courses, blogs, and testimonials. To connect Sanity:

```bash
npm create sanity@latest -- --project your-project-id --dataset production --template clean
```

Add schemas from `sanity/schemas/index.ts` to your Sanity Studio.

---

## 🌐 Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Add environment variables in Vercel dashboard:
# Project Settings → Environment Variables
# Add all variables from .env.local
```

Or connect your GitHub repo directly at vercel.com.

### Custom Domain
1. Vercel Dashboard → Project → Settings → Domains
2. Add `kanantandi.com` and `www.kanantandi.com`
3. Update DNS at your registrar (CNAME to `cname.vercel-dns.com`)

---

## 💰 Estimated Monthly Cost

| Service | Free Tier | Paid (if needed) |
|---------|-----------|------------------|
| Vercel Hosting | Free (hobby) | $20/mo (pro) |
| Sanity CMS | Free (3 users, 10GB) | $99/mo |
| Resend Email | 100/day free | $20/mo (50K emails) |
| Razorpay | 2% per transaction | — |
| Google Sheets | Free | Free |
| Google Calendar | Free | Free |

**Total at launch: ₹0/month**

---

## 📁 Project Structure

```
kanan-tandi/
├── app/
│   ├── (site)/          # Public website pages
│   │   ├── page.tsx     # Homepage
│   │   ├── about/
│   │   ├── book/        # Booking system
│   │   ├── courses/
│   │   ├── blog/
│   │   └── ...
│   ├── (admin)/         # Admin panel (protected)
│   │   └── admin/
│   ├── api/             # API routes
│   │   ├── payment/
│   │   ├── booking/
│   │   ├── contact/
│   │   └── newsletter/
│   ├── layout.tsx
│   └── globals.css
├── components/
│   ├── home/            # Homepage sections
│   └── layout/          # Navbar, Footer
├── lib/                 # Integrations
│   ├── sanity.ts
│   ├── razorpay.ts
│   ├── resend.ts
│   ├── google-sheets.ts
│   └── google-calendar.ts
├── sanity/schemas/      # CMS content types
├── public/
└── .env.local.example
```

---

## 🛠️ Common Tasks

### Add a new blog post
→ `/admin/blogs` → New Post → fill details → Save as Draft → Publish

### Add a new course  
→ `/admin/courses` → Add Course → fill price/date → Publish

### Change booking prices
→ Edit `app/(site)/book/page.tsx` → update the `services` array

### Update testimonials
→ Edit `components/home/TestimonialsSection.tsx`

### Change colors
→ Edit `tailwind.config.js` → colors section

### Change fonts
→ Edit `app/globals.css` → @import URL

---

## 📞 Support

For deployment help or custom changes, contact your developer.

Built with ❤️ for Kanan Tandi.
