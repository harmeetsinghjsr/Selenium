import { MetadataRoute } from 'next'

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_BASE_URL || 'https://kanantandi.com'
  const now  = new Date()

  const staticPages = [
    '/', '/about', '/services', '/workshops', '/courses',
    '/book', '/blog', '/contact', '/corporate', '/testimonials',
    '/media', '/faq', '/privacy', '/terms', '/refund',
  ]

  return staticPages.map((path) => ({
    url:             `${base}${path}`,
    lastModified:    now,
    changeFrequency: path === '/' ? 'daily' : 'weekly',
    priority:        path === '/' ? 1 : path === '/book' ? 0.9 : 0.8,
  }))
}
