import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Corporate Training — Body Language & Communication Workshops',
  description: 'Transform your team with Kanan Tandi\'s corporate workshops on body language, executive communication, and leadership presence.',
}

const programs = [
  { title:'Executive Communication Masterclass', duration:'4 hours', audience:'Senior leaders & C-suite', desc:'For executives who need to communicate with precision, authority, and gravitas. Covers non-verbal leadership, boardroom presence, and media communication.' },
  { title:'Team Dynamics & Non-Verbal Intelligence', duration:'Full Day', audience:'Teams of 10–50', desc:'Help teams read each other better, communicate with clarity, and reduce interpersonal friction through behavioural intelligence.' },
  { title:'Interview & Talent Assessment Training', duration:'Half Day', audience:'HR & Hiring Managers', desc:'Train your HR team to read body language cues during interviews, reduce bias, and make more accurate hiring decisions.' },
  { title:'Sales Presence & Influence Workshop', duration:'Full Day', audience:'Sales Teams', desc:'Help your sales team project confidence, read prospects, and use body language strategically to build trust and close more deals.' },
  { title:'Leadership Presence Intensive', duration:'2 Days', audience:'High-Potential Managers', desc:'A deep-dive program for emerging leaders developing gravitas, executive presence, and the ability to inspire through non-verbal communication.' },
]

const clients = ['Deloitte', 'HDFC Bank', 'Infosys', 'Tata Group', 'Google India', 'Razorpay', 'Byju\'s', 'OYO']

export default function CorporatePage() {
  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site">
          <p className="section-label">Corporate Training</p>
          <h1 className="section-title mb-6">Transform How<br />Your Team <em>Communicates</em></h1>
          <p className="text-light-grey text-base max-w-xl leading-relaxed mb-8">
            Bespoke workshops that build behavioural intelligence, executive presence, and communication
            excellence across your entire organisation.
          </p>
          <Link href="/contact" className="btn-primary">Request a Proposal</Link>
        </div>
      </div>

      {/* Client logos */}
      <div className="bg-charcoal border-y border-white/5 py-10 px-6">
        <div className="container-site">
          <p className="text-[0.62rem] tracking-widest uppercase text-grey text-center mb-8">Trusted by India's Best Companies</p>
          <div className="flex flex-wrap justify-center gap-8 lg:gap-16 opacity-30">
            {clients.map(c => (
              <span key={c} className="font-serif text-lg tracking-wider text-warm-white">{c}</span>
            ))}
          </div>
        </div>
      </div>

      <section className="bg-black py-20 px-6 lg:px-12">
        <div className="container-site">
          <p className="section-label">Programs</p>
          <h2 className="section-title mb-14">Training <em>Programs</em></h2>
          <div className="space-y-1">
            {programs.map((p) => (
              <div key={p.title} className="bg-charcoal border border-white/6 hover:border-gold/20 transition-all duration-300 p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-4 gap-6">
                <div>
                  <span className="block text-[0.6rem] tracking-widest uppercase text-gold mb-1">{p.duration}</span>
                  <span className="text-xs text-grey">{p.audience}</span>
                </div>
                <div className="lg:col-span-3">
                  <h3 className="font-serif text-xl font-light text-warm-white mb-3">{p.title}</h3>
                  <p className="text-grey text-sm leading-relaxed">{p.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site">
          <p className="section-label">How It Works</p>
          <h2 className="section-title mb-14">The Corporate <em>Process</em></h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-0 border border-white/5">
            {[
              { n:'01', title:'Discovery Call', desc:'Free 30-min call to understand your team\'s needs and goals.' },
              { n:'02', title:'Custom Proposal', desc:'Tailored program design with objectives, modules, and pricing.' },
              { n:'03', title:'Live Workshop', desc:'Engaging, practical sessions with your team — online or on-site.' },
              { n:'04', title:'Follow-Up Support', desc:'Post-workshop resources, Q&A, and implementation guidance.' },
            ].map(step => (
              <div key={step.n} className="border border-white/5 p-8">
                <span className="font-serif text-5xl text-gold/20 block leading-none mb-5">{step.n}</span>
                <h3 className="font-serif text-lg text-warm-white font-light mb-3">{step.title}</h3>
                <p className="text-grey text-sm leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="bg-black py-20 px-6 lg:px-12 text-center">
        <div className="container-site max-w-2xl mx-auto">
          <h3 className="font-serif text-3xl font-light text-warm-white mb-5">Ready to Elevate Your Team?</h3>
          <p className="text-grey text-sm mb-8 leading-relaxed">
            Get in touch to discuss your requirements. Kanan will personally respond within 24 hours.
          </p>
          <Link href="/contact" className="btn-primary">Request a Proposal</Link>
        </div>
      </div>
    </>
  )
}
