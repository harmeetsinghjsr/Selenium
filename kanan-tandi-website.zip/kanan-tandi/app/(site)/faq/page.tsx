'use client'
import { useState } from 'react'
import { Plus, Minus } from 'lucide-react'

const faqs = [
  { q: 'What exactly is a 1:1 consultation with Kanan?', a: 'A private, personalised Zoom session where Kanan works directly with you on your specific challenges — whether that\'s body language, confidence, communication, executive presence, or interview preparation. Sessions are either 60 or 90 minutes and include a personalised action plan.' },
  { q: 'How do I know which service is right for me?', a: 'If you\'re unsure, book a free 15-minute discovery call via the Contact page. Kanan will help you identify the best path based on your goals, current situation, and timeline.' },
  { q: 'Are sessions conducted online or in person?', a: 'All 1:1 consultations are conducted online via Zoom or Google Meet. Corporate workshops can be conducted in-person (Mumbai, Delhi, Bangalore and select cities) or online. Most group programs are online.' },
  { q: 'How quickly will I see results?', a: 'Many clients report noticeable shifts after just the first session. Deeper, sustained transformation typically unfolds over 4–8 weeks of consistent practice. Results depend on your commitment to applying the insights.' },
  { q: 'What is your refund policy?', a: 'We offer a full refund if you cancel at least 48 hours before your session. For online courses, a 7-day refund policy applies from the date of purchase. Please see the Refund Policy page for full details.' },
  { q: 'Can Kanan come to our company for a workshop?', a: 'Yes. Kanan conducts corporate workshops across India. Please reach out via the Corporate Training page or Contact page with details about your team size, location, and objectives.' },
  { q: 'Are your courses self-paced?', a: 'Yes, all online courses include lifetime access and are fully self-paced. Some courses also include optional live Q&A sessions with Kanan.' },
  { q: 'What payment methods do you accept?', a: 'We accept all major UPI apps (GPay, PhonePe, Paytm), credit/debit cards, net banking, and EMI through Razorpay. All payments are secure and encrypted.' },
  { q: 'Is there a community I can join?', a: 'Yes! All course and workshop participants get access to a private community where Kanan shares additional insights, answers questions, and facilitates connection among members.' },
]

export default function FAQPage() {
  const [open, setOpen] = useState<number | null>(0)

  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site">
          <p className="section-label">FAQ</p>
          <h1 className="section-title mb-6">Frequently Asked<br /><em>Questions</em></h1>
        </div>
      </div>

      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site max-w-3xl">
          <div className="space-y-1">
            {faqs.map((faq, i) => (
              <div key={i} className="border border-white/6 bg-black overflow-hidden">
                <button
                  onClick={() => setOpen(open === i ? null : i)}
                  className="w-full flex items-center justify-between gap-6 px-8 py-6 text-left group"
                >
                  <span className={`text-sm font-medium transition-colors duration-200 ${open === i ? 'text-gold' : 'text-warm-white group-hover:text-gold'}`}>
                    {faq.q}
                  </span>
                  {open === i
                    ? <Minus size={16} className="text-gold flex-shrink-0" />
                    : <Plus  size={16} className="text-grey flex-shrink-0 group-hover:text-gold transition-colors" />
                  }
                </button>
                {open === i && (
                  <div className="px-8 pb-6 border-t border-white/5 pt-4">
                    <p className="text-grey text-sm leading-relaxed">{faq.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-16 text-center border border-gold/20 bg-gold/5 p-10">
            <h3 className="font-serif text-2xl text-warm-white font-light mb-3">Still have questions?</h3>
            <p className="text-grey text-sm mb-6">Reach out directly and Kanan will personally respond.</p>
            <a href="/contact" className="btn-primary">Get in Touch</a>
          </div>
        </div>
      </section>
    </>
  )
}
