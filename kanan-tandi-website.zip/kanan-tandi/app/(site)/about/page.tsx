import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'About',
  description: 'Learn about Kanan Tandi — India\'s leading body language and behavioural intelligence expert.',
}

const milestones = [
  { year: '2016', title: 'The Beginning', desc: 'Started studying body language and behavioural psychology, fascinated by the science of human communication.' },
  { year: '2018', title: 'First Workshop', desc: 'Conducted first corporate workshop for a team of 50 — transforming how they showed up in client presentations.' },
  { year: '2020', title: 'Online Expansion', desc: 'Launched first online program, reaching professionals across India during the pandemic.' },
  { year: '2022', title: 'TEDx Speaker', desc: 'Delivered a TEDx talk on the neuroscience of body language to an audience of 3,000+.' },
  { year: '2024', title: 'Media Recognition', desc: 'Featured in Forbes India, NDTV, and Economic Times as a leading behavioural intelligence expert.' },
  { year: '2026', title: 'Expanding Impact', desc: '500+ lives transformed. Building India\'s most premium psychology and presence brand.' },
]

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <div className="pt-40 pb-24 px-6 lg:px-12 bg-black">
        <div className="container-site max-w-4xl">
          <p className="section-label">About</p>
          <h1 className="font-serif font-light text-warm-white leading-tight mb-8"
              style={{ fontSize: 'clamp(3rem, 7vw, 6rem)' }}>
            The Mind Behind<br /><em className="not-italic text-gold">the Method</em>
          </h1>
          <p className="text-light-grey text-base leading-relaxed max-w-2xl">
            Kanan Tandi is India's foremost body language and behavioural intelligence expert —
            a psychologist, coach, and speaker who has spent a decade studying the science of
            human communication, presence, and transformation.
          </p>
        </div>
      </div>

      {/* Photo + Bio */}
      <section className="bg-charcoal py-24 px-6 lg:px-12">
        <div className="container-site grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <div className="relative">
            <div className="aspect-[4/5] bg-dark border border-gold/20 flex items-center justify-center">
              <div className="text-center">
                <svg width="160" height="240" viewBox="0 0 160 240" fill="none">
                  <ellipse cx="80" cy="64" rx="38" ry="38" fill="#2c2824" stroke="#c9a96e" strokeWidth="0.5" strokeOpacity="0.5"/>
                  <path d="M10 240 Q10 155 80 145 Q150 155 150 240" fill="#2c2824" stroke="#c9a96e" strokeWidth="0.5" strokeOpacity="0.4"/>
                </svg>
                <p className="font-serif text-gold/40 tracking-[0.3em] text-sm mt-4">KANAN TANDI</p>
              </div>
              <span className="absolute top-4 left-4 w-10 h-10 border-l border-t border-gold/30" />
              <span className="absolute bottom-4 right-4 w-10 h-10 border-r border-b border-gold/30" />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-gold text-black p-6 text-center w-32">
              <span className="font-serif text-4xl font-light block leading-none">8+</span>
              <span className="text-[0.6rem] tracking-widest uppercase block mt-1">Years</span>
            </div>
          </div>

          <div className="pt-4">
            <p className="section-label">My Story</p>
            <h2 className="section-title mb-8">Behaviourist.<br /><em>Psychologist.</em><br />Transformer.</h2>
            <div className="space-y-5 text-light-grey text-sm leading-relaxed">
              <p>
                Growing up, I was fascinated by the gap between what people said and what they meant.
                I noticed how a slight shift in posture could change the entire energy of a conversation.
                How confidence was something you could learn — not something you were born with.
              </p>
              <p>
                After years of studying psychology, neuroscience, and body language — and working with
                hundreds of clients — I built a methodology that bridges ancient wisdom with modern science.
              </p>
              <p>
                Today, I work with executives, entrepreneurs, job seekers, and leaders to help them
                decode human behaviour, master their own presence, and show up fully in every context
                that matters.
              </p>
              <p>
                My work isn't about performance. It's about alignment — so that how you show up
                on the outside genuinely reflects the power you carry within.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 mt-8 mb-10">
              {['Body Language', 'Behavioural Analysis', 'NLP Practitioner', 'Executive Coaching',
                'Nervous System Science', 'Communication Psychology'].map((tag) => (
                <span key={tag} className="border border-gold/30 text-nude text-[0.7rem] tracking-wide uppercase px-3 py-1.5">
                  {tag}
                </span>
              ))}
            </div>
            <Link href="/book" className="btn-primary">Book a Session with Kanan</Link>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="bg-black py-24 px-6 lg:px-12">
        <div className="container-site">
          <p className="section-label">The Journey</p>
          <h2 className="section-title mb-16">Milestones &amp; <em>Moments</em></h2>
          <div className="relative">
            <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px bg-white/5" />
            <div className="space-y-12">
              {milestones.map((m, i) => (
                <div key={m.year}
                  className={`grid grid-cols-1 lg:grid-cols-2 gap-8 ${i % 2 === 0 ? '' : 'lg:direction-rtl'}`}>
                  <div className={`${i % 2 === 0 ? 'lg:text-right lg:pr-16' : 'lg:order-2 lg:pl-16'}`}>
                    <span className="font-serif text-5xl text-gold/20 block leading-none mb-2">{m.year}</span>
                    <h3 className="font-serif text-xl text-warm-white font-light mb-2">{m.title}</h3>
                    <p className="text-grey text-sm leading-relaxed">{m.desc}</p>
                  </div>
                  <div className={`hidden lg:flex items-start ${i % 2 === 0 ? 'justify-start pl-16' : 'justify-end pr-16 order-1'}`}>
                    <div className="w-3 h-3 rounded-full bg-gold mt-2 flex-shrink-0" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
          {[
            { num: '500+', label: 'Lives Transformed' },
            { num: '50+',  label: 'Corporate Workshops' },
            { num: '8+',   label: 'Years Experience' },
            { num: '10K+', label: 'Online Community' },
          ].map((s) => (
            <div key={s.label}>
              <div className="font-serif text-5xl lg:text-6xl font-light text-warm-white mb-2">{s.num}</div>
              <div className="text-[0.65rem] tracking-widest uppercase text-grey">{s.label}</div>
            </div>
          ))}
        </div>
      </section>
    </>
  )
}
