import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Testimonials — Real Stories of Transformation',
  description: 'Read stories from professionals, executives, and individuals transformed by Kanan Tandi\'s coaching.',
}

const testimonials = [
  { text:"Kanan's work changed how I carry myself in every room. I got promoted within 3 months. The changes were profound and lasting.", name:'Rohan Mehta', role:'Senior Manager, Deloitte', initial:'R', category:'1:1 Consultation' },
  { text:"I walked into my dream job interview with the confidence of someone who had done it a hundred times. Kanan gave me tools I use every single day.", name:'Priya Sharma', role:'Product Manager, Google India', initial:'P', category:'Interview Coaching' },
  { text:"Our entire leadership team attended the corporate workshop. The shift in how our leaders communicate has been extraordinary.", name:'Arun Kapoor', role:'CEO, TechVentures India', initial:'A', category:'Corporate Workshop' },
  { text:"I used to shrink in meetings. After working with Kanan, I realised I had been communicating fear without knowing it. That awareness alone changed everything.", name:'Sunita Rao', role:'IAS Officer', initial:'S', category:'1:1 Consultation' },
  { text:"The nervous system session was unlike anything I'd experienced. Kanan combines science with intuition in a way that creates real, embodied change.", name:'Vikram Nair', role:'Entrepreneur & TEDx Speaker', initial:'V', category:'Group Workshop' },
  { text:"As someone with severe social anxiety, the transformation I experienced through Kanan's program feels nothing short of miraculous.", name:'Anjali Singh', role:'Software Engineer, Microsoft', initial:'A', category:'Online Course' },
  { text:"Every leader in my team noticed an immediate change in how I showed up after just two sessions with Kanan. Worth every rupee.", name:'Kartik Joshi', role:'VP Engineering, Razorpay', initial:'K', category:'1:1 Consultation' },
  { text:"Kanan is the real deal. No fluff, no generic advice. Everything is evidence-based and tailored specifically to you.", name:'Meera Iyer', role:'Founder, Bloom Ventures', initial:'M', category:'Corporate Workshop' },
  { text:"The body language course fundamentally changed how I read rooms, handle negotiations, and present ideas. It's become a professional superpower.", name:'Siddharth Patel', role:'Sales Director, Salesforce India', initial:'S', category:'Online Course' },
]

export default function TestimonialsPage() {
  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site">
          <p className="section-label">Social Proof</p>
          <h1 className="section-title mb-6">Real Stories of<br /><em>Transformation</em></h1>
          <p className="text-light-grey text-base max-w-xl leading-relaxed">
            Every client walks in with a challenge. They walk out with a superpower.
            Here's what people say about working with Kanan.
          </p>
        </div>
      </div>

      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
            {[
              { num:'500+', label:'Clients Coached' },
              { num:'4.9', label:'Average Rating' },
              { num:'50+', label:'Corporate Clients' },
              { num:'94%', label:'Report Transformation' },
            ].map(s => (
              <div key={s.label} className="bg-black border border-white/6 p-6 text-center">
                <div className="font-serif text-4xl text-warm-white font-light mb-1">{s.num}</div>
                <div className="text-[0.62rem] tracking-widest uppercase text-grey">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {testimonials.map((t, i) => (
              <div key={i} className="bg-black border border-white/6 p-8 relative hover:border-gold/20 transition-all duration-300">
                <span className="absolute -top-2 left-6 font-serif text-7xl text-gold/10 leading-none">"</span>
                <div className="relative">
                  <span className="inline-block text-[0.6rem] tracking-widest uppercase text-gold border border-gold/30 px-2.5 py-1 mb-5">
                    {t.category}
                  </span>
                  <div className="flex gap-0.5 mb-4">
                    {[...Array(5)].map((_,j) => <span key={j} className="text-gold text-xs">★</span>)}
                  </div>
                  <p className="text-light-grey text-sm leading-relaxed italic mb-7">"{t.text}"</p>
                  <div className="flex items-center gap-3 border-t border-white/5 pt-5">
                    <div className="w-10 h-10 rounded-full bg-dark border border-gold/30 flex items-center justify-center font-serif text-gold">
                      {t.initial}
                    </div>
                    <div>
                      <p className="text-warm-white text-sm font-medium">{t.name}</p>
                      <p className="text-grey text-xs">{t.role}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-16">
            <h3 className="font-serif text-3xl text-warm-white font-light mb-4">Ready to Write Your Story?</h3>
            <p className="text-grey text-sm mb-8">Join hundreds of professionals who have transformed their presence and their careers.</p>
            <Link href="/book" className="btn-primary">Book Your Session</Link>
          </div>
        </div>
      </section>
    </>
  )
}
