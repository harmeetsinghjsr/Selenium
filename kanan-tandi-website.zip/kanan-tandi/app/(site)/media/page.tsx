import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Media Features — Kanan Tandi in the Press',
  description: 'Kanan Tandi as featured in Forbes India, NDTV, TEDx, Economic Times, and more.',
}

const features = [
  { outlet:'Forbes India', title:'Meet the Body Language Expert Changing How India\'s Leaders Communicate', type:'Article', year:'2025', summary:'A profile on Kanan\'s work with India\'s top executives and the science behind her methodology.' },
  { outlet:'NDTV', title:'The Psychology of First Impressions', type:'TV Feature', year:'2024', summary:'A segment on how body language shapes perception in the first seven seconds of meeting someone.' },
  { outlet:'TEDx', title:'The Language Your Body Speaks Without Words', type:'Talk', year:'2023', summary:'A TEDx talk on the neuroscience of body language and its impact on professional success.' },
  { outlet:'Economic Times', title:'Corporate India Discovers the Power of Body Language Coaching', type:'Article', year:'2024', summary:'Feature on how Fortune 500 companies are investing in behavioural intelligence training.' },
  { outlet:'Femina', title:'Read the Room: How to Master Non-Verbal Communication', type:'Magazine Feature', year:'2024', summary:'Tips and insights on reading people and projecting confidence in professional settings.' },
  { outlet:'Hindustan Times', title:'The Rise of Behavioural Intelligence Coaching in India', type:'Article', year:'2023', summary:'An exploration of India\'s growing appetite for psychology-based professional development.' },
]

const podcastAppearances = [
  { show:'The Learning Curve Podcast', episode:'Decoding Human Behaviour', host:'Nikhil Kamath', duration:'58 min' },
  { show:'Mindset Mastery', episode:'Your Body Language is Costing You Opportunities', host:'Shruti Shah', duration:'45 min' },
  { show:'Leaders of Tomorrow', episode:'The Science of Executive Presence', host:'Anirudh Batra', duration:'62 min' },
]

export default function MediaPage() {
  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site">
          <p className="section-label">In the Press</p>
          <h1 className="section-title mb-6">Media &amp; <em>Features</em></h1>
          <p className="text-light-grey text-base max-w-xl leading-relaxed">
            Kanan Tandi's expertise has been featured across India's leading media platforms,
            TV networks, and podcasts.
          </p>
        </div>
      </div>

      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site">
          <p className="section-label">Press & Publications</p>
          <div className="space-y-4 mb-20">
            {features.map((f) => (
              <div key={f.title}
                className="bg-black border border-white/6 hover:border-gold/20 transition-all duration-300 p-8 lg:p-10
                           grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
                <div>
                  <p className="font-serif text-xl text-warm-white mb-1">{f.outlet}</p>
                  <p className="text-[0.6rem] tracking-widest uppercase text-gold">{f.type} · {f.year}</p>
                </div>
                <div className="lg:col-span-3">
                  <h3 className="font-serif text-lg font-light text-warm-white mb-2">{f.title}</h3>
                  <p className="text-grey text-sm leading-relaxed">{f.summary}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Podcast appearances */}
          <p className="section-label">Podcast Appearances</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {podcastAppearances.map((p) => (
              <div key={p.episode}
                className="bg-black border border-white/6 hover:border-gold/20 transition-all duration-300 p-7">
                <div className="w-10 h-10 border border-gold/30 flex items-center justify-center text-gold mb-5 text-lg">
                  ▶
                </div>
                <p className="text-[0.6rem] tracking-widest uppercase text-gold mb-2">{p.show}</p>
                <h3 className="font-serif text-base font-light text-warm-white mb-2">{p.episode}</h3>
                <p className="text-grey text-xs">with {p.host} · {p.duration}</p>
              </div>
            ))}
          </div>

          {/* Media enquiry */}
          <div className="mt-16 border border-gold/20 bg-gold/5 p-10 text-center">
            <h3 className="font-serif text-2xl font-light text-warm-white mb-3">Media Enquiries</h3>
            <p className="text-grey text-sm mb-6">
              For interview requests, podcast invitations, or press enquiries, please get in touch.
            </p>
            <a href="mailto:media@kanantandi.com" className="btn-primary">media@kanantandi.com</a>
          </div>
        </div>
      </section>
    </>
  )
}
