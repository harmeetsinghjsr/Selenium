'use client'
import { useState } from 'react'
import toast from 'react-hot-toast'
import { Mail, Phone, Instagram, Linkedin } from 'lucide-react'

export default function ContactPage() {
  const [form, setForm]     = useState({ name:'', email:'', phone:'', subject:'', message:'' })
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/contact', {
        method:'POST', body:JSON.stringify(form),
        headers:{'Content-Type':'application/json'},
      })
      if (res.ok) { toast.success('Message sent! Kanan will reply soon.'); setForm({ name:'', email:'', phone:'', subject:'', message:'' }) }
      else toast.error('Something went wrong.')
    } catch { toast.error('Network error.') }
    finally { setLoading(false) }
  }

  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site">
          <p className="section-label">Contact</p>
          <h1 className="section-title mb-6">Let's <em>Connect</em></h1>
        </div>
      </div>

      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Info */}
          <div>
            <p className="text-light-grey text-sm leading-relaxed mb-10 max-w-sm">
              Whether you're interested in a 1:1 session, corporate workshop, or have a media
              enquiry — reach out and Kanan will personally respond.
            </p>
            <div className="space-y-6 mb-10">
              <a href="mailto:hello@kanantandi.com"
                className="flex items-center gap-4 text-light-grey hover:text-gold transition-colors duration-300 group">
                <div className="w-10 h-10 border border-white/10 group-hover:border-gold/40 flex items-center justify-center transition-colors duration-300">
                  <Mail size={16} />
                </div>
                <span className="text-sm">hello@kanantandi.com</span>
              </a>
              <a href="tel:+919876543210"
                className="flex items-center gap-4 text-light-grey hover:text-gold transition-colors duration-300 group">
                <div className="w-10 h-10 border border-white/10 group-hover:border-gold/40 flex items-center justify-center transition-colors duration-300">
                  <Phone size={16} />
                </div>
                <span className="text-sm">+91 98765 43210</span>
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-4 text-light-grey hover:text-gold transition-colors duration-300 group">
                <div className="w-10 h-10 border border-white/10 group-hover:border-gold/40 flex items-center justify-center transition-colors duration-300">
                  <Instagram size={16} />
                </div>
                <span className="text-sm">@kanantandi</span>
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-4 text-light-grey hover:text-gold transition-colors duration-300 group">
                <div className="w-10 h-10 border border-white/10 group-hover:border-gold/40 flex items-center justify-center transition-colors duration-300">
                  <Linkedin size={16} />
                </div>
                <span className="text-sm">Kanan Tandi</span>
              </a>
            </div>
            <div className="border border-gold/20 bg-gold/5 p-6">
              <p className="text-[0.65rem] tracking-widest uppercase text-gold mb-2">Response Time</p>
              <p className="text-warm-white text-sm">Within 24–48 hours on business days.</p>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Name</label>
                <input value={form.name} onChange={e => setForm(p=>({...p,name:e.target.value}))}
                  placeholder="Your name" className="input-field" required />
              </div>
              <div>
                <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Email</label>
                <input type="email" value={form.email} onChange={e => setForm(p=>({...p,email:e.target.value}))}
                  placeholder="your@email.com" className="input-field" required />
              </div>
            </div>
            <div>
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Phone</label>
              <input value={form.phone} onChange={e => setForm(p=>({...p,phone:e.target.value}))}
                placeholder="+91 98765 43210" className="input-field" />
            </div>
            <div>
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Subject</label>
              <select value={form.subject} onChange={e => setForm(p=>({...p,subject:e.target.value}))}
                className="input-field" required>
                <option value="">Select a topic</option>
                <option>1:1 Consultation Enquiry</option>
                <option>Corporate Workshop</option>
                <option>Course Information</option>
                <option>Media / Speaking Enquiry</option>
                <option>Partnership</option>
                <option>Other</option>
              </select>
            </div>
            <div>
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Message</label>
              <textarea value={form.message} onChange={e => setForm(p=>({...p,message:e.target.value}))}
                placeholder="Tell Kanan about yourself and what you're looking for..."
                rows={5} className="input-field resize-none" required />
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-50 mt-2">
              {loading ? 'Sending...' : 'Send Message'}
            </button>
          </form>
        </div>
      </section>
    </>
  )
}
