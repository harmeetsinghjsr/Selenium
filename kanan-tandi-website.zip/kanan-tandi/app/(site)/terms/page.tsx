import type { Metadata } from 'next'
export const metadata: Metadata = { title: 'Terms & Conditions' }
export default function TermsPage() {
  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site max-w-3xl">
          <p className="section-label">Legal</p>
          <h1 className="section-title mb-4">Terms &amp; <em>Conditions</em></h1>
          <p className="text-grey text-sm">Last updated: 1 May 2026</p>
        </div>
      </div>
      <section className="bg-charcoal py-16 px-6 lg:px-12">
        <div className="container-site max-w-3xl prose-kanan">
          <h2>1. Acceptance of Terms</h2>
          <p>By accessing and using this website, you accept and agree to be bound by these Terms and Conditions. If you do not agree, please do not use our services.</p>
          <h2>2. Services</h2>
          <p>Kanan Tandi provides coaching, consulting, and educational services in the areas of body language, behavioural psychology, and executive presence. Our services are for educational and developmental purposes only and do not constitute medical or psychological therapy.</p>
          <h2>3. Booking & Payments</h2>
          <p>All bookings must be paid in full at the time of scheduling. Prices are in Indian Rupees (INR) and include applicable taxes. Payment is processed securely through Razorpay.</p>
          <h2>4. Intellectual Property</h2>
          <p>All content on this website — including videos, course materials, articles, and images — is the intellectual property of Kanan Tandi and may not be reproduced, distributed, or used without written permission.</p>
          <h2>5. Limitation of Liability</h2>
          <p>Kanan Tandi shall not be liable for any indirect, incidental, or consequential damages arising from your use of our services. Results vary by individual and are not guaranteed.</p>
          <h2>6. Governing Law</h2>
          <p>These terms are governed by the laws of India. Any disputes shall be subject to the jurisdiction of the courts of Mumbai, Maharashtra.</p>
          <h2>7. Contact</h2>
          <p>For questions about these terms: legal@kanantandi.com</p>
        </div>
      </section>
    </>
  )
}
