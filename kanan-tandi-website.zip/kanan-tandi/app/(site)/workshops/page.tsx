import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Workshops — Live Transformation Programs',
  description: 'Join Kanan Tandi\'s live workshops on body language, executive presence, and nervous system regulation.',
}

const workshops = [
  {
    badge: 'Flagship Program',
    title: 'Body Language Mastery Intensive',
    desc: 'A transformative 2-day immersive workshop covering micro-expressions, posture science, vocal authority, reading people with precision, and projecting unshakeable confidence in any environment.',
    date: 'June 15–16, 2026',
    time: '10:00 AM – 5:00 PM IST',
    mode: 'Online (Zoom)',
    seats: '30 seats only',
    price: 4999,
    originalPrice: 7999,
    includes: ['Live sessions with Kanan', 'Workbook & resources', 'Recording access (14 days)', 'WhatsApp community access', 'Certificate of completion'],
    status: 'Filling Fast',
  },
  {
    badge: 'New Workshop',
    title: 'Nervous System Reset for Leaders',
    desc: 'Learn to regulate your nervous system under pressure, speak with calm authority, and lead from a place of groundedness. Essential for executives, managers, and anyone in high-pressure roles.',
    date: 'July 5, 2026',
    time: '2:00 PM – 6:00 PM IST',
    mode: 'Online (Zoom)',
    seats: '20 seats only',
    price: 2499,
    originalPrice: 3999,
    includes: ['4-hour live workshop', 'Nervous system toolkit PDF', 'Recording access (7 days)', 'Follow-up email support'],
    status: 'Open',
  },
  {
    badge: 'Corporate Special',
    title: 'Interview Confidence Bootcamp',
    desc: 'A high-intensity half-day workshop for job seekers and career changers. Cover every aspect of interview psychology — preparation, presence, answers, body language, and salary negotiation.',
    date: 'July 20, 2026',
    time: '10:00 AM – 2:00 PM IST',
    mode: 'Online (Zoom)',
    seats: '50 seats',
    price: 1499,
    originalPrice: 2499,
    includes: ['4-hour intensive session', 'Interview preparation templates', 'Mock interview feedback', 'Offer negotiation guide'],
    status: 'Open',
  },
]

export default function WorkshopsPage() {
  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site">
          <p className="section-label">Live Programs</p>
          <h1 className="section-title mb-6">Workshops &<br /><em>Live Events</em></h1>
          <p className="text-light-grey text-base max-w-xl leading-relaxed">
            Immersive, live learning experiences designed to create rapid, lasting transformation.
            Small groups. Deep work. Real results.
          </p>
        </div>
      </div>

      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site space-y-8">
          {workshops.map((w) => (
            <div key={w.title}
              className="bg-black border border-white/7 hover:border-gold/30 transition-all duration-300
                         grid grid-cols-1 lg:grid-cols-3 gap-0">
              {/* Main info */}
              <div className="lg:col-span-2 p-10 border-b lg:border-b-0 lg:border-r border-white/5">
                <div className="flex items-center gap-3 mb-6">
                  <span className="bg-gold/10 border border-gold/30 text-gold text-[0.62rem] tracking-widest uppercase px-3 py-1.5">
                    {w.badge}
                  </span>
                  <span className={`text-[0.6rem] tracking-wider uppercase px-2.5 py-1 ${
                    w.status === 'Filling Fast'
                      ? 'bg-red-900/30 border border-red-700/40 text-red-400'
                      : 'bg-green-900/20 border border-green-700/30 text-green-500'
                  }`}>
                    {w.status}
                  </span>
                </div>
                <h2 className="font-serif text-2xl font-light text-warm-white mb-4">{w.title}</h2>
                <p className="text-grey text-sm leading-relaxed mb-8">{w.desc}</p>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  {[['Date', w.date], ['Time', w.time], ['Format', w.mode], ['Seats', w.seats]].map(([label, val]) => (
                    <div key={label}>
                      <span className="block text-[0.6rem] tracking-widest uppercase text-gold mb-1">{label}</span>
                      <span className="text-light-grey text-xs">{val}</span>
                    </div>
                  ))}
                </div>

                <div>
                  <p className="text-[0.62rem] tracking-widest uppercase text-gold mb-3">What's Included</p>
                  <ul className="space-y-1.5">
                    {w.includes.map((item) => (
                      <li key={item} className="flex items-center gap-3 text-xs text-grey">
                        <span className="text-gold">✓</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Pricing & CTA */}
              <div className="p-10 flex flex-col justify-between">
                <div>
                  <p className="text-[0.62rem] tracking-widest uppercase text-gold mb-4">Investment</p>
                  <div className="mb-2">
                    <span className="font-serif text-4xl text-warm-white">₹{w.price.toLocaleString('en-IN')}</span>
                  </div>
                  <p className="text-grey/50 text-sm line-through mb-6">₹{w.originalPrice.toLocaleString('en-IN')}</p>
                  <p className="text-xs text-grey leading-relaxed mb-8">
                    Save ₹{(w.originalPrice - w.price).toLocaleString('en-IN')} with early bird pricing.
                    Price increases as seats fill.
                  </p>
                </div>
                <Link href="/book" className="btn-primary text-center block">
                  Register Now
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Corporate training CTA */}
        <div className="container-site mt-16 border border-gold/20 bg-gold/5 p-10 lg:p-14 text-center">
          <p className="text-[0.65rem] tracking-widest uppercase text-gold mb-4">For Teams</p>
          <h3 className="font-serif text-3xl font-light text-warm-white mb-4">Need a Private Corporate Workshop?</h3>
          <p className="text-grey text-sm max-w-xl mx-auto mb-8">
            Kanan delivers bespoke workshops for companies and teams. Customised content, flexible scheduling,
            and measurable outcomes.
          </p>
          <Link href="/corporate" className="btn-primary">Explore Corporate Training</Link>
        </div>
      </section>
    </>
  )
}
