import type { Metadata } from 'next'
export const metadata: Metadata = { title: 'Refund Policy' }
export default function RefundPage() {
  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site max-w-3xl">
          <p className="section-label">Legal</p>
          <h1 className="section-title mb-4">Refund <em>Policy</em></h1>
          <p className="text-grey text-sm">Last updated: 1 May 2026</p>
        </div>
      </div>
      <section className="bg-charcoal py-16 px-6 lg:px-12">
        <div className="container-site max-w-3xl prose-kanan">
          <h2>1:1 Consultation Sessions</h2>
          <p><strong>Full Refund:</strong> If you cancel at least 48 hours before your scheduled session, you will receive a full refund within 5–7 business days.</p>
          <p><strong>Partial Refund (50%):</strong> If you cancel 24–48 hours before your session, a 50% refund will be issued.</p>
          <p><strong>No Refund:</strong> Cancellations within 24 hours of the session or no-shows are not eligible for a refund. However, you may reschedule once with at least 24 hours' notice.</p>
          <h2>Online Courses</h2>
          <p><strong>7-Day Money-Back Guarantee:</strong> If you are not satisfied with an online course, you may request a full refund within 7 days of purchase, provided you have not completed more than 20% of the course content.</p>
          <h2>Workshops & Live Events</h2>
          <p><strong>Full Refund:</strong> Cancellation 7+ days before the event date.</p>
          <p><strong>50% Refund:</strong> Cancellation 3–7 days before the event.</p>
          <p><strong>No Refund:</strong> Cancellation within 3 days of the event. You may transfer your registration to another person.</p>
          <h2>Corporate Training</h2>
          <p>Refund terms for corporate engagements are specified in the individual service agreement.</p>
          <h2>How to Request a Refund</h2>
          <p>Email refunds@kanantandi.com with your booking reference number, reason for cancellation, and bank details for NEFT transfer. Refunds are processed within 5–7 business days.</p>
        </div>
      </section>
    </>
  )
}
