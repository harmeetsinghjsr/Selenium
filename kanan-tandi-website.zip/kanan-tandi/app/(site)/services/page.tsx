import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Services — Body Language, Psychology & Executive Presence',
  description: 'Explore all services by Kanan Tandi — 1:1 consultations, corporate workshops, online courses, and more.',
}

const services = [
  {
    num: '01', title: '1:1 Private Consultation',
    desc: 'The most personalised experience. A deep-dive session tailored entirely to your specific needs, challenges, and goals. Whether you need to overcome social anxiety, build executive presence, or decode a difficult person in your life — this session is built around you.',
    includes: ['60 or 90-minute Zoom session', 'Pre-session intake questionnaire', 'Personalised action plan', 'WhatsApp follow-up for 7 days'],
    price: 'From ₹1,999', href: '/book',
  },
  {
    num: '02', title: 'Corporate Training & Workshops',
    desc: 'Transform how your team communicates, presents, and leads. Kanan delivers bespoke workshops for corporations, startups, and educational institutions — covering body language, executive communication, team dynamics, and leadership presence.',
    includes: ['Half-day or full-day sessions', 'Customised content for your industry', 'Practical exercises and role-plays', 'Post-workshop resources and support'],
    price: 'Custom Pricing', href: '/corporate',
  },
  {
    num: '03', title: 'Interview Confidence Coaching',
    desc: 'High-stakes interviews require more than preparation — they require presence. Kanan\'s interview coaching combines psychological preparation, body language optimisation, and vocal confidence to give you a decisive edge.',
    includes: ['Mock interview with real feedback', 'Body language analysis', 'Answer structuring techniques', 'Salary negotiation coaching'],
    price: 'From ₹999', href: '/book',
  },
  {
    num: '04', title: 'Online Courses',
    desc: 'Deeply researched, beautifully designed self-paced programs that deliver real transformation on your own schedule. Each course combines video lessons, exercises, and community support.',
    includes: ['Lifetime access to course materials', 'Certificate of completion', 'Live Q&A sessions', 'Private community access'],
    price: 'From ₹1,799', href: '/courses',
  },
  {
    num: '05', title: 'Group Workshops',
    desc: 'Intimate cohort experiences that combine the power of personalised attention with the energy of group learning. Limited to small cohorts to ensure deep individual attention.',
    includes: ['8–20 participants per cohort', '2–4 week structured program', 'Weekly group calls', 'Personalised feedback'],
    price: 'From ₹2,499', href: '/workshops',
  },
  {
    num: '06', title: 'Keynote Speaking',
    desc: 'Book Kanan for your next event, conference, or corporate gathering. Her talks on body language, human behaviour, and psychological intelligence are engaging, evidence-based, and transformative.',
    includes: ['30–90 minute keynote talks', 'Interactive workshops', 'Panel discussions', 'Online and in-person formats'],
    price: 'Custom Pricing', href: '/contact',
  },
]

export default function ServicesPage() {
  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site">
          <p className="section-label">Services</p>
          <h1 className="section-title mb-6">Ways to Work<br /><em>With Kanan</em></h1>
          <p className="text-light-grey text-base max-w-xl leading-relaxed">
            Every service is designed with one goal — to create real, lasting transformation in how
            you show up and how the world responds to you.
          </p>
        </div>
      </div>

      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site space-y-1">
          {services.map((s, i) => (
            <div key={s.num}
              className="group bg-black border border-white/6 hover:border-gold/25 transition-all duration-300 p-10 lg:p-14
                         grid grid-cols-1 lg:grid-cols-3 gap-10">
              <div>
                <span className="font-serif text-6xl text-gold/15 group-hover:text-gold/30 transition-colors duration-300 block leading-none mb-4">
                  {s.num}
                </span>
                <h2 className="font-serif text-2xl font-light text-warm-white group-hover:text-gold transition-colors duration-300">
                  {s.title}
                </h2>
              </div>
              <div className="lg:col-span-2">
                <p className="text-light-grey text-sm leading-relaxed mb-6">{s.desc}</p>
                <ul className="space-y-2 mb-8">
                  {s.includes.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-sm text-grey">
                      <span className="text-gold mt-0.5 flex-shrink-0">—</span>
                      {item}
                    </li>
                  ))}
                </ul>
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <span className="font-serif text-xl text-warm-white">{s.price}</span>
                  <Link href={s.href} className="btn-gold-ghost">
                    {s.price === 'Custom Pricing' ? 'Get in Touch' : 'Book Now'}
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  )
}
