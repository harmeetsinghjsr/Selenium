import type { Metadata } from 'next'
import Link from 'next/link'
import HeroSection from '@/components/home/HeroSection'
import MarqueeBar from '@/components/home/MarqueeBar'
import ServicesSection from '@/components/home/ServicesSection'
import TestimonialsSection from '@/components/home/TestimonialsSection'
import NewsletterSection from '@/components/home/NewsletterSection'

export const metadata: Metadata = {
  title: 'Kanan Tandi | Body Language & Psychology Expert',
  description:
    "India's leading body language and behavioural intelligence expert. Transform how the world perceives you.",
}

const mediaLogos = ['TEDx', 'Forbes India', 'NDTV', 'Economic Times', 'Femina', 'Hindustan Times']

const workshops = [
  {
    badge: 'Flagship Program',
    title: 'Body Language Mastery Intensive',
    desc: 'A transformative 2-day immersive workshop on reading people, projecting authority, and mastering non-verbal communication.',
    date: 'June 15–16, 2026',
    mode: 'Online + Live',
    seats: 'Limited to 30',
    price: '₹4,999',
    priceNote: 'Early Bird',
  },
  {
    badge: 'New Workshop',
    title: 'Nervous System Reset for Leaders',
    desc: 'Learn to regulate your nervous system under pressure, speak with calm authority, and lead with emotional intelligence.',
    date: 'July 5, 2026',
    mode: 'Online',
    seats: 'Limited to 20',
    price: '₹2,499',
    priceNote: 'per person',
  },
]

const blogs = [
  {
    tag: 'Body Language',
    title: '7 Micro-Expressions That Reveal What People Are Really Thinking',
    excerpt: 'The face never lies — but most people don\'t know how to read it. Here\'s what science says about the seven universal micro-expressions...',
    date: 'May 2026',
    read: '6 min read',
    slug: '7-micro-expressions',
    symbol: '✦',
  },
  {
    tag: 'Psychology',
    title: 'The Nervous System Hierarchy: Why You Freeze Under Pressure',
    excerpt: 'Understanding your autonomic nervous system is the first step to mastering your responses in high-stakes situations...',
    date: 'April 2026',
    read: '8 min read',
    slug: 'nervous-system-hierarchy',
    symbol: '◈',
  },
  {
    tag: 'Executive Presence',
    title: 'How to Command a Room Without Saying a Word',
    excerpt: 'Executive presence is 93% non-verbal. Here\'s a step-by-step guide to projecting authority, warmth, and confidence simultaneously...',
    date: 'March 2026',
    read: '5 min read',
    slug: 'command-a-room',
    symbol: '❖',
  },
]

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <MarqueeBar />

      {/* Media logos */}
      <div className="bg-charcoal py-10 px-6 lg:px-12">
        <div className="container-site text-center">
          <p className="section-label justify-center mb-8">As Seen In</p>
          <div className="flex flex-wrap justify-center items-center gap-8 lg:gap-14 opacity-35">
            {mediaLogos.map((m) => (
              <span key={m} className="font-serif text-lg tracking-wider text-warm-white">
                {m}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* About snippet */}
      <section className="bg-charcoal py-28 px-6 lg:px-12">
        <div className="container-site grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Image placeholder */}
          <div className="relative order-2 lg:order-1">
            <div className="aspect-[3/4] bg-dark border border-gold/20 flex items-center justify-center relative overflow-hidden">
              <div className="text-center">
                <svg width="120" height="180" viewBox="0 0 120 180" fill="none">
                  <ellipse cx="60" cy="48" rx="28" ry="28" fill="#2c2824" stroke="#c9a96e" strokeWidth="0.5" strokeOpacity="0.5"/>
                  <path d="M10 180 Q10 115 60 108 Q110 115 110 180" fill="#2c2824" stroke="#c9a96e" strokeWidth="0.5" strokeOpacity="0.4"/>
                </svg>
                <p className="font-serif text-gold/40 tracking-[0.3em] text-xs mt-4">KANAN TANDI</p>
              </div>
              {/* Corner decorations */}
              <span className="absolute top-3 left-3 w-8 h-8 border-l border-t border-gold/30" />
              <span className="absolute bottom-3 right-3 w-8 h-8 border-r border-b border-gold/30" />
            </div>
            {/* Badge */}
            <div className="absolute -bottom-5 -right-5 bg-gold text-black p-5 text-center w-28">
              <span className="font-serif text-3xl font-light block leading-none">8+</span>
              <span className="text-[0.6rem] tracking-widest uppercase block mt-1">Years of Expertise</span>
            </div>
          </div>

          {/* Text */}
          <div className="order-1 lg:order-2">
            <p className="section-label">About Kanan</p>
            <h2 className="section-title mb-8">
              Behaviourist.<br /><em>Psychologist.</em><br />Transformer.
            </h2>
            <p className="text-light-grey leading-relaxed mb-5 text-[0.95rem]">
              Kanan Tandi is India's leading body language and behavioural intelligence expert,
              helping individuals, executives, and corporations decode the silent language of the
              human mind.
            </p>
            <p className="text-light-grey leading-relaxed mb-8 text-[0.95rem]">
              With deep expertise in psychology, nervous system science, and executive communication,
              Kanan has transformed the confidence, presence, and careers of hundreds of professionals
              across India.
            </p>
            <div className="flex flex-wrap gap-2 mb-10">
              {['Body Language', 'Psychology', 'Executive Presence', 'NLP', 'Nervous System', 'Behaviour Analysis'].map((tag) => (
                <span key={tag}
                  className="border border-gold/30 text-nude text-[0.7rem] tracking-[0.1em] uppercase px-3 py-1.5">
                  {tag}
                </span>
              ))}
            </div>
            <Link href="/about" className="btn-ghost">
              Learn My Story
            </Link>
          </div>
        </div>
      </section>

      <ServicesSection />

      {/* Transformation journey */}
      <div className="bg-charcoal py-28 px-6 lg:px-12 text-center">
        <div className="container-site">
          <p className="section-label justify-center">The Journey</p>
          <p className="font-serif text-warm-white font-light leading-tight max-w-2xl mx-auto mb-16"
             style={{ fontSize: 'clamp(1.8rem, 4vw, 3rem)' }}>
            Every transformation begins with a single moment of <em className="not-italic text-gold">self-awareness.</em>
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0 border border-white/5">
            {[
              { n: '01', title: 'Discovery Session',
                desc: 'We begin by understanding your current state, challenges, and deepest aspirations.' },
              { n: '02', title: 'Behavioural Analysis',
                desc: 'A deep diagnostic of your body language, communication patterns, and psychological triggers.' },
              { n: '03', title: 'Tailored Program',
                desc: 'A bespoke transformation roadmap designed specifically for your goals and growth edge.' },
              { n: '04', title: 'Integrated Mastery',
                desc: 'Sustainable embodied change — not just intellectual understanding, but lived transformation.' },
            ].map((step) => (
              <div key={step.n}
                className="border border-white/5 p-8 text-left hover:bg-black/40 transition-colors duration-300">
                <span className="font-serif text-5xl text-gold/15 leading-none block mb-6">{step.n}</span>
                <h3 className="font-serif text-lg text-warm-white font-light mb-3">{step.title}</h3>
                <p className="text-grey text-sm leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Workshops */}
      <section className="bg-black py-28 px-6 lg:px-12">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-14">
            <div>
              <p className="section-label">Live Programs</p>
              <h2 className="section-title">Upcoming<br /><em>Workshops</em></h2>
            </div>
            <Link href="/workshops" className="btn-ghost self-start">All Workshops</Link>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {workshops.map((w) => (
              <div key={w.title}
                className="border border-white/7 bg-charcoal p-10 hover:border-gold/40 transition-all duration-300">
                <span className="inline-block bg-gold/10 border border-gold/30 text-gold
                                 text-[0.62rem] tracking-[0.2em] uppercase px-3 py-1.5 mb-6">
                  {w.badge}
                </span>
                <h3 className="font-serif text-2xl font-light text-warm-white mb-4">{w.title}</h3>
                <p className="text-grey text-sm leading-relaxed mb-6">{w.desc}</p>
                <div className="flex flex-wrap gap-6 mb-6 text-sm">
                  {[['Date', w.date], ['Mode', w.mode], ['Seats', w.seats]].map(([label, val]) => (
                    <div key={label}>
                      <span className="block text-[0.62rem] tracking-widest uppercase text-gold mb-0.5">{label}</span>
                      <span className="text-light-grey text-xs">{val}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between flex-wrap gap-4 pt-6 border-t border-white/5">
                  <div>
                    <span className="font-serif text-3xl text-warm-white">{w.price}</span>
                    <span className="text-grey text-xs ml-2">{w.priceNote}</span>
                  </div>
                  <Link href="/workshops" className="btn-primary py-3 px-6 text-xs">Register Now</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <TestimonialsSection />

      {/* Blog */}
      <section className="bg-charcoal py-28 px-6 lg:px-12">
        <div className="container-site">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-14">
            <div>
              <p className="section-label">Insights</p>
              <h2 className="section-title">From the <em>Journal</em></h2>
            </div>
            <Link href="/blog" className="btn-ghost self-start">All Articles</Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {blogs.map((b) => (
              <Link key={b.slug} href={`/blog/${b.slug}`}
                className="group block border-b border-white/7 pb-8">
                <div className="aspect-video bg-dark border border-white/5 flex items-center justify-center
                                mb-6 text-4xl text-gold/20 group-hover:border-gold/20 transition-colors duration-300">
                  {b.symbol}
                </div>
                <p className="text-[0.62rem] tracking-[0.2em] uppercase text-gold mb-3">{b.tag}</p>
                <h3 className="font-serif text-xl font-light text-warm-white mb-3 leading-tight
                               group-hover:text-gold transition-colors duration-300">
                  {b.title}
                </h3>
                <p className="text-grey text-sm leading-relaxed mb-4">{b.excerpt}</p>
                <div className="flex gap-5 text-[0.7rem] text-grey">
                  <span>{b.date}</span>
                  <span>{b.read}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <div className="bg-dark border-y border-gold/15 py-24 px-6 lg:px-12 text-center relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(201,169,110,0.05),transparent_70%)]" />
        </div>
        <div className="relative container-site max-w-3xl mx-auto">
          <p className="text-[0.65rem] tracking-[0.3em] uppercase text-gold mb-5">Ready to begin?</p>
          <h2 className="font-serif font-light text-warm-white mb-5"
              style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)', lineHeight: 1.1 }}>
            Your presence is<br />your <em className="not-italic text-gold">greatest asset.</em>
          </h2>
          <p className="text-grey mb-10 text-base">Book a private consultation and begin your transformation today.</p>
          <div className="flex flex-wrap gap-5 justify-center">
            <Link href="/book" className="btn-primary">Book 1:1 Session</Link>
            <Link href="/services" className="btn-ghost">Explore All Programs</Link>
          </div>
        </div>
      </div>

      <NewsletterSection />
    </>
  )
}
