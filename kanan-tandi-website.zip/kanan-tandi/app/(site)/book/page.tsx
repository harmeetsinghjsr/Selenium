'use client'
import { useState } from 'react'
import toast from 'react-hot-toast'

const timeSlots = [
  '10:00 AM', '11:00 AM', '12:00 PM',
  '2:00 PM',  '3:00 PM',  '4:00 PM',
  '5:00 PM',  '6:00 PM',
]

const services = [
  { id: 'consult-60',  label: '60-min Consultation',         price: 2999 },
  { id: 'consult-90',  label: '90-min Deep Dive Session',    price: 4499 },
  { id: 'interview',   label: 'Interview Mastery Session',   price: 1999 },
  { id: 'corporate',   label: 'Corporate Discovery Call',    price: 0,    note: 'Free' },
]

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate()
}
function getFirstDay(year: number, month: number) {
  return new Date(year, month, 1).getDay()
}

const monthNames = ['January','February','March','April','May','June',
                    'July','August','September','October','November','December']

export default function BookPage() {
  const today = new Date()
  const [year, setYear]       = useState(today.getFullYear())
  const [month, setMonth]     = useState(today.getMonth())
  const [selectedDay, setDay] = useState<number | null>(null)
  const [selectedSlot, setSlot] = useState<string | null>(null)
  const [selectedSvc, setSvc]   = useState(services[0].id)
  const [step, setStep]         = useState<1 | 2 | 3>(1)
  const [form, setForm]         = useState({ name: '', email: '', phone: '', notes: '' })
  const [loading, setLoading]   = useState(false)

  const daysInMonth = getDaysInMonth(year, month)
  const firstDay    = getFirstDay(year, month)

  function prevMonth() {
    if (month === 0) { setYear(y => y - 1); setMonth(11) }
    else setMonth(m => m - 1)
    setDay(null); setSlot(null)
  }
  function nextMonth() {
    if (month === 11) { setYear(y => y + 1); setMonth(0) }
    else setMonth(m => m + 1)
    setDay(null); setSlot(null)
  }

  const selectedService = services.find(s => s.id === selectedSvc)!

  async function handlePayment() {
    setLoading(true)
    try {
      if (selectedService.price === 0) {
        // Free call — just submit
        await fetch('/api/booking', {
          method: 'POST',
          body: JSON.stringify({ ...form, service: selectedSvc, date: `${year}-${month+1}-${selectedDay}`, slot: selectedSlot }),
          headers: { 'Content-Type': 'application/json' },
        })
        setStep(3)
        return
      }

      const orderRes = await fetch('/api/payment/create-order', {
        method: 'POST',
        body: JSON.stringify({ amount: selectedService.price }),
        headers: { 'Content-Type': 'application/json' },
      })
      const order = await orderRes.json()

      const options = {
        key:    process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
        amount: order.amount,
        currency: 'INR',
        name:   'Kanan Tandi',
        description: selectedService.label,
        order_id: order.id,
        handler: async (response: Record<string, string>) => {
          await fetch('/api/payment/verify', {
            method: 'POST',
            body: JSON.stringify({ ...response, bookingData: { ...form, service: selectedSvc, date: `${year}-${month+1}-${selectedDay}`, slot: selectedSlot } }),
            headers: { 'Content-Type': 'application/json' },
          })
          setStep(3)
        },
        prefill:  { name: form.name, email: form.email, contact: form.phone },
        theme:    { color: '#c9a96e' },
      }
      // @ts-ignore
      const rzp = new window.Razorpay(options)
      rzp.open()
    } catch {
      toast.error('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  if (step === 3) return (
    <div className="min-h-screen bg-black flex items-center justify-center px-6 pt-32">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 bg-gold/10 border border-gold/30 rounded-full flex items-center justify-center mx-auto mb-8">
          <span className="text-gold text-2xl">✓</span>
        </div>
        <h1 className="font-serif text-4xl font-light text-warm-white mb-4">Booking Confirmed</h1>
        <p className="text-grey text-sm leading-relaxed mb-8">
          A confirmation email has been sent to <span className="text-gold">{form.email}</span>.
          Kanan will reach out with the session details shortly.
        </p>
        <a href="/" className="btn-primary inline-block">Back to Home</a>
      </div>
    </div>
  )

  return (
    <>
      {/* Razorpay script */}
      <script src="https://checkout.razorpay.com/v1/checkout.js" async />

      <div className="min-h-screen bg-black pt-32 pb-20 px-6 lg:px-12">
        <div className="container-site max-w-5xl">
          <p className="section-label">Book a Session</p>
          <h1 className="section-title mb-14">Schedule Your<br /><em>Consultation</em></h1>

          {/* Progress */}
          <div className="flex items-center gap-4 mb-12">
            {[1, 2].map((n) => (
              <div key={n} className="flex items-center gap-4">
                <div className={`w-8 h-8 rounded-full border flex items-center justify-center text-xs
                  ${step >= n ? 'bg-gold border-gold text-black' : 'border-white/20 text-grey'}`}>
                  {n}
                </div>
                <span className={`text-xs tracking-wider uppercase ${step >= n ? 'text-warm-white' : 'text-grey'}`}>
                  {n === 1 ? 'Pick a Time' : 'Your Details'}
                </span>
                {n < 2 && <span className="w-12 h-px bg-white/10" />}
              </div>
            ))}
          </div>

          {step === 1 && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Service select */}
              <div className="lg:col-span-1">
                <h3 className="text-[0.65rem] tracking-widest uppercase text-gold mb-5">Select Service</h3>
                <div className="space-y-3">
                  {services.map((s) => (
                    <button key={s.id}
                      onClick={() => setSvc(s.id)}
                      className={`w-full text-left p-4 border transition-all duration-200 ${
                        selectedSvc === s.id
                          ? 'border-gold bg-gold/5'
                          : 'border-white/8 bg-charcoal hover:border-white/20'
                      }`}>
                      <span className="block text-sm text-warm-white">{s.label}</span>
                      <span className="block text-xs text-gold mt-1">
                        {s.note || `₹${s.price.toLocaleString('en-IN')}`}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Calendar */}
              <div className="lg:col-span-2">
                <div className="bg-charcoal border border-white/8 p-6 mb-6">
                  <div className="flex items-center justify-between mb-6">
                    <button onClick={prevMonth} className="text-grey hover:text-warm-white text-lg px-2">‹</button>
                    <span className="font-serif text-lg text-warm-white">
                      {monthNames[month]} {year}
                    </span>
                    <button onClick={nextMonth} className="text-grey hover:text-warm-white text-lg px-2">›</button>
                  </div>
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {['Su','Mo','Tu','We','Th','Fr','Sa'].map(d => (
                      <div key={d} className="text-center text-[0.6rem] tracking-wider uppercase text-grey py-1">{d}</div>
                    ))}
                  </div>
                  <div className="grid grid-cols-7 gap-1">
                    {Array.from({ length: firstDay }).map((_, i) => <div key={`e${i}`} />)}
                    {Array.from({ length: daysInMonth }).map((_, i) => {
                      const day = i + 1
                      const isToday = day === today.getDate() && month === today.getMonth() && year === today.getFullYear()
                      const isPast  = new Date(year, month, day) < new Date(today.getFullYear(), today.getMonth(), today.getDate())
                      const isSel   = selectedDay === day
                      return (
                        <button key={day}
                          disabled={isPast}
                          onClick={() => { setDay(day); setSlot(null) }}
                          className={`aspect-square text-sm rounded transition-all duration-150 ${
                            isPast   ? 'text-grey/30 cursor-not-allowed' :
                            isSel    ? 'bg-gold text-black font-medium' :
                            isToday  ? 'border border-gold/50 text-gold' :
                                       'text-light-grey hover:bg-white/5'
                          }`}>
                          {day}
                        </button>
                      )
                    })}
                  </div>
                </div>

                {/* Time slots */}
                {selectedDay && (
                  <div>
                    <h3 className="text-[0.65rem] tracking-widest uppercase text-gold mb-4">
                      Available Times — {selectedDay} {monthNames[month]}
                    </h3>
                    <div className="grid grid-cols-4 gap-2">
                      {timeSlots.map((slot) => (
                        <button key={slot}
                          onClick={() => setSlot(slot)}
                          className={`py-2.5 text-xs border transition-all duration-150 ${
                            selectedSlot === slot
                              ? 'bg-gold border-gold text-black'
                              : 'border-white/10 text-light-grey hover:border-gold/40'
                          }`}>
                          {slot}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {selectedDay && selectedSlot && (
                  <button
                    onClick={() => setStep(2)}
                    className="btn-primary mt-8 w-full lg:w-auto"
                  >
                    Continue →
                  </button>
                )}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="max-w-xl">
              <h3 className="font-serif text-2xl text-warm-white font-light mb-2">Your Details</h3>
              <p className="text-grey text-sm mb-8">
                {selectedService.label} · {selectedDay} {monthNames[month]} · {selectedSlot}
              </p>
              <div className="space-y-4">
                {[
                  { key: 'name',  label: 'Full Name',    type: 'text',  placeholder: 'Your full name' },
                  { key: 'email', label: 'Email Address', type: 'email', placeholder: 'your@email.com' },
                  { key: 'phone', label: 'Phone Number',  type: 'tel',   placeholder: '+91 98765 43210' },
                ].map(f => (
                  <div key={f.key}>
                    <label className="block text-[0.65rem] tracking-widest uppercase text-gold mb-2">{f.label}</label>
                    <input
                      type={f.type}
                      value={form[f.key as keyof typeof form]}
                      onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                      placeholder={f.placeholder}
                      className="input-field"
                      required
                    />
                  </div>
                ))}
                <div>
                  <label className="block text-[0.65rem] tracking-widest uppercase text-gold mb-2">Notes (optional)</label>
                  <textarea
                    value={form.notes}
                    onChange={e => setForm(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="What would you like to focus on?"
                    rows={3}
                    className="input-field resize-none"
                  />
                </div>
              </div>

              <div className="mt-8 p-5 bg-charcoal border border-white/8">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-grey">{selectedService.label}</span>
                  <span className="text-warm-white">
                    {selectedService.price === 0 ? 'Free' : `₹${selectedService.price.toLocaleString('en-IN')}`}
                  </span>
                </div>
                <div className="flex justify-between text-xs text-grey">
                  <span>{selectedDay} {monthNames[month]} {year} · {selectedSlot}</span>
                </div>
              </div>

              <div className="flex gap-4 mt-6">
                <button onClick={() => setStep(1)} className="btn-ghost">← Back</button>
                <button
                  onClick={handlePayment}
                  disabled={loading || !form.name || !form.email || !form.phone}
                  className="btn-primary flex-1 disabled:opacity-50"
                >
                  {loading ? 'Processing...' : selectedService.price === 0 ? 'Confirm Booking' : `Pay ₹${selectedService.price.toLocaleString('en-IN')}`}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  )
}
