import type { Metadata } from 'next'
import Link from 'next/link'
import { client } from '@/lib/sanity'
import { urlForImage } from '@/lib/sanity'

export const metadata: Metadata = {
  title: 'Online Courses',
  description: 'Self-paced courses on body language, psychology, and executive presence by Kanan Tandi.',
}

async function getCourses() {
  try {
    return await client.fetch(`
      *[_type == "course" && published == true] | order(_createdAt desc) {
        _id, title, slug, description, price, earlyBirdPrice,
        date, thumbnail, maxSeats
      }
    `)
  } catch {
    return []
  }
}

// Fallback demo courses when Sanity not connected
const demoCourses = [
  {
    _id: '1',
    title: 'Body Language Mastery: The Complete Program',
    slug: { current: 'body-language-mastery' },
    description: 'A comprehensive 6-week program covering micro-expressions, posture science, vocal authority, and reading people with precision.',
    price: 7999,
    earlyBirdPrice: 4999,
    date: '2026-06-01',
    maxSeats: 50,
  },
  {
    _id: '2',
    title: 'Executive Presence Accelerator',
    slug: { current: 'executive-presence' },
    description: 'For leaders and managers who want to command respect, project confidence, and communicate with authority in every room.',
    price: 5999,
    earlyBirdPrice: 3499,
    date: '2026-07-01',
    maxSeats: 30,
  },
  {
    _id: '3',
    title: 'Interview Confidence Blueprint',
    slug: { current: 'interview-confidence' },
    description: 'Master the psychology and body language of winning interviews. Cover preparation, presence, and post-interview follow-up.',
    price: 2999,
    earlyBirdPrice: 1799,
    date: null,
    maxSeats: 100,
  },
  {
    _id: '4',
    title: 'Nervous System Reset',
    slug: { current: 'nervous-system-reset' },
    description: 'Regulate your stress response, overcome anxiety, and learn to stay calm and confident in high-pressure situations.',
    price: 3999,
    earlyBirdPrice: 2499,
    date: '2026-06-15',
    maxSeats: 40,
  },
]

export default async function CoursesPage() {
  const courses = (await getCourses()).length > 0 ? await getCourses() : demoCourses

  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site">
          <p className="section-label">Online Programs</p>
          <h1 className="section-title mb-6">Transform at<br /><em>Your Own Pace</em></h1>
          <p className="text-light-grey text-base max-w-xl leading-relaxed">
            Deeply researched, beautifully designed online courses that deliver real results —
            wherever you are in the world.
          </p>
        </div>
      </div>

      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {courses.map((course: typeof demoCourses[0]) => (
              <div key={course._id}
                className="bg-black border border-white/7 hover:border-gold/30 transition-all duration-300 group">
                {/* Thumbnail */}
                <div className="aspect-video bg-dark border-b border-white/5 flex items-center justify-center
                                text-5xl text-gold/15 group-hover:text-gold/25 transition-colors duration-300">
                  ✦
                </div>
                <div className="p-8">
                  <h2 className="font-serif text-xl font-light text-warm-white mb-3 group-hover:text-gold transition-colors duration-300">
                    {course.title}
                  </h2>
                  <p className="text-grey text-sm leading-relaxed mb-6">{course.description}</p>

                  {course.date && (
                    <p className="text-[0.65rem] tracking-widest uppercase text-gold mb-4">
                      Starts {new Date(course.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                  )}

                  <div className="flex items-center justify-between flex-wrap gap-4 pt-5 border-t border-white/5">
                    <div>
                      {course.earlyBirdPrice && course.earlyBirdPrice < course.price ? (
                        <>
                          <span className="font-serif text-2xl text-warm-white">
                            ₹{course.earlyBirdPrice.toLocaleString('en-IN')}
                          </span>
                          <span className="text-grey/50 text-sm line-through ml-3">
                            ₹{course.price.toLocaleString('en-IN')}
                          </span>
                        </>
                      ) : (
                        <span className="font-serif text-2xl text-warm-white">
                          ₹{course.price.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>
                    <Link href={`/courses/${course.slug.current}`} className="btn-primary py-2.5 px-6 text-xs">
                      Enroll Now
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
