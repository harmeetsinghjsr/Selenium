import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { client } from '@/lib/sanity'

interface Props { params: { slug: string } }

async function getCourse(slug: string) {
  try {
    return await client.fetch(
      `*[_type == "course" && slug.current == $slug && published == true][0]`,
      { slug }
    )
  } catch { return null }
}

const demoCourses: Record<string, { title: string; description: string; price: number; earlyBirdPrice: number; date: string; maxSeats: number; includes: string[]; curriculum: { week: string; title: string; desc: string }[] }> = {
  'body-language-mastery': {
    title: 'Body Language Mastery: The Complete Program',
    description: 'A comprehensive 6-week deep-dive into the science of non-verbal communication. You\'ll learn to read people with precision, project unshakeable confidence, and use body language as a strategic advantage in every area of life.',
    price: 7999, earlyBirdPrice: 4999, date: '2026-06-01', maxSeats: 50,
    includes: ['6 weeks of live + recorded sessions', 'Weekly 1-hour Q&A calls with Kanan', 'Workbooks and practice exercises', 'Private community access', 'Certificate of completion', 'Lifetime access to recordings'],
    curriculum: [
      { week:'Week 1', title:'The Science of Non-Verbal Communication', desc:'Foundations of body language science, how the brain processes visual cues, and the seven universal emotions.' },
      { week:'Week 2', title:'Reading Micro-Expressions', desc:'How to spot micro-expressions in real-time conversations — the 7 universals and how to respond.' },
      { week:'Week 3', title:'Posture, Space & Power', desc:'How body positioning, spatial ownership, and posture science directly impact how others perceive you.' },
      { week:'Week 4', title:'Vocal Confidence & Paralanguage', desc:'The 38% of communication that is vocal tone, pace, and pitch — and how to master each element.' },
      { week:'Week 5', title:'Detecting Deception', desc:'Evidence-based techniques for reading honesty and deception in personal and professional contexts.' },
      { week:'Week 6', title:'Strategic Application', desc:'Applying everything in high-stakes scenarios: job interviews, negotiations, presentations, first dates.' },
    ],
  },
  'executive-presence': {
    title: 'Executive Presence Accelerator',
    description: 'For leaders and managers who want to command respect, project confidence, and communicate with authority. This 4-week intensive program combines body language, vocal work, and psychological presence to create a leader people instinctively follow.',
    price: 5999, earlyBirdPrice: 3499, date: '2026-07-01', maxSeats: 30,
    includes: ['4 weeks of live sessions', 'Personalised presence audit', 'Video feedback from Kanan', 'Private community', 'Certificate of completion'],
    curriculum: [
      { week:'Week 1', title:'Diagnosing Your Presence', desc:'A deep-dive analysis of how you currently show up — and identifying your specific growth edge.' },
      { week:'Week 2', title:'The Physicality of Leadership', desc:'Posture, stillness, spatial ownership, and the entry — the non-verbal foundations of authority.' },
      { week:'Week 3', title:'Vocal Authority', desc:'Command attention with your voice — tempo, pitch, pause, and the psychology of being heard.' },
      { week:'Week 4', title:'High-Stakes Performance', desc:'Applying your presence in boardrooms, town halls, media appearances, and difficult conversations.' },
    ],
  },
  'interview-confidence': {
    title: 'Interview Confidence Blueprint',
    description: 'Everything you need to walk into any interview — from campus placements to CXO roles — with calm, grounded confidence. Combines psychology, body language, and structured answer frameworks.',
    price: 2999, earlyBirdPrice: 1799, date: '', maxSeats: 100,
    includes: ['Self-paced video curriculum', 'Interview cheat sheet PDF', 'Answer framework templates', 'Mock interview guide', 'Lifetime access'],
    curriculum: [
      { week:'Module 1', title:'Interview Psychology', desc:'Understanding what interviewers are really looking for — and how to give it to them.' },
      { week:'Module 2', title:'Body Language for Interviews', desc:'Entrance, handshake, posture, eye contact, and the nervous system regulation techniques that work in the room.' },
      { week:'Module 3', title:'Answer Frameworks', desc:'STAR, CAR, SOAR — structured frameworks for answering any behavioural or competency question.' },
      { week:'Module 4', title:'Salary Negotiation', desc:'The psychology and body language of negotiating confidently — and getting what you\'re worth.' },
    ],
  },
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const course = await getCourse(params.slug)
  const demo   = demoCourses[params.slug]
  return { title: course?.title || demo?.title || 'Course', description: course?.description || demo?.description || '' }
}

export default async function CourseDetailPage({ params }: Props) {
  const course = await getCourse(params.slug)
  const demo   = demoCourses[params.slug]
  if (!course && !demo) notFound()
  const data = course || demo

  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site max-w-4xl">
          <Link href="/courses" className="text-[0.65rem] tracking-widest uppercase text-gold hover:text-gold-light transition-colors flex items-center gap-2 mb-8">
            ← All Courses
          </Link>
          <h1 className="font-serif font-light text-warm-white leading-tight mb-6"
              style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
            {data.title}
          </h1>
          <p className="text-light-grey text-base leading-relaxed max-w-2xl">{data.description}</p>
        </div>
      </div>

      <div className="bg-charcoal py-16 px-6 lg:px-12">
        <div className="container-site grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main content */}
          <div className="lg:col-span-2">
            {/* Curriculum */}
            <h2 className="font-serif text-2xl font-light text-warm-white mb-8">Course Curriculum</h2>
            <div className="space-y-3 mb-12">
              {data.curriculum.map((item, i) => (
                <div key={i} className="border border-white/7 bg-black p-6">
                  <p className="text-[0.62rem] tracking-widest uppercase text-gold mb-1">{item.week}</p>
                  <h3 className="font-serif text-lg font-light text-warm-white mb-2">{item.title}</h3>
                  <p className="text-grey text-sm leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>

            {/* What's included */}
            <h2 className="font-serif text-2xl font-light text-warm-white mb-6">What's Included</h2>
            <ul className="space-y-3">
              {data.includes.map((item) => (
                <li key={item} className="flex items-center gap-3 text-light-grey text-sm">
                  <span className="text-gold text-base">✓</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Sticky pricing card */}
          <div className="lg:sticky lg:top-32 self-start">
            <div className="bg-black border border-gold/20 p-8">
              <div className="aspect-video bg-dark border border-white/5 flex items-center justify-center text-4xl text-gold/15 mb-6">
                ✦
              </div>
              <div className="mb-2">
                <span className="font-serif text-4xl text-warm-white">₹{data.earlyBirdPrice.toLocaleString('en-IN')}</span>
              </div>
              <p className="text-grey/50 text-sm line-through mb-1">₹{data.price.toLocaleString('en-IN')}</p>
              <p className="text-gold text-xs mb-5">Early Bird Pricing</p>
              {data.date && (
                <p className="text-[0.62rem] tracking-widest uppercase text-grey mb-6">
                  Starts {new Date(data.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                </p>
              )}
              <Link href="/book" className="btn-primary block text-center mb-4">
                Enroll Now
              </Link>
              <Link href="/contact" className="btn-ghost block text-center text-xs">
                Have Questions? Ask Us
              </Link>
              <p className="text-grey/50 text-xs text-center mt-4">7-day money-back guarantee</p>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
