import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Privacy Policy' }

export default function PrivacyPage() {
  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site max-w-3xl">
          <p className="section-label">Legal</p>
          <h1 className="section-title mb-4">Privacy <em>Policy</em></h1>
          <p className="text-grey text-sm">Last updated: 1 May 2026</p>
        </div>
      </div>
      <section className="bg-charcoal py-16 px-6 lg:px-12">
        <div className="container-site max-w-3xl prose-kanan">
          <h2>1. Information We Collect</h2>
          <p>We collect information you provide directly to us when you book a session, purchase a course, subscribe to our newsletter, or contact us. This may include your name, email address, phone number, and payment information.</p>
          <h2>2. How We Use Your Information</h2>
          <p>We use the information we collect to provide, maintain, and improve our services, process transactions, send confirmations and receipts, respond to your enquiries, and send marketing communications (which you can opt out of at any time).</p>
          <h2>3. Information Sharing</h2>
          <p>We do not sell, trade, or rent your personal information to third parties. We may share your information with trusted service providers (such as payment processors and email platforms) solely for the purpose of delivering our services.</p>
          <h2>4. Payment Security</h2>
          <p>All payment transactions are processed by Razorpay, a PCI-DSS compliant payment gateway. We do not store your full card details on our servers.</p>
          <h2>5. Cookies</h2>
          <p>We use essential cookies to maintain session state and improve website performance. We use analytics cookies (Google Analytics) to understand how visitors interact with our site. You can disable cookies through your browser settings.</p>
          <h2>6. Your Rights</h2>
          <p>You have the right to access, correct, or delete your personal information. To exercise these rights, please contact us at privacy@kanantandi.com.</p>
          <h2>7. Contact</h2>
          <p>For privacy-related queries, please contact: privacy@kanantandi.com</p>
        </div>
      </section>
    </>
  )
}
