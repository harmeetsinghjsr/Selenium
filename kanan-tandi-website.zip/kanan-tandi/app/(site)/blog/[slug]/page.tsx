import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { client } from '@/lib/sanity'

interface Props { params: { slug: string } }

async function getBlog(slug: string) {
  try {
    return await client.fetch(
      `*[_type == "blog" && slug.current == $slug && published == true][0]{
        title, excerpt, category, publishedAt, readTime, content
      }`,
      { slug }
    )
  } catch { return null }
}

// Demo content for when Sanity is not connected
const demoBlogs: Record<string, { title: string; category: string; publishedAt: string; readTime: number; excerpt: string; body: string }> = {
  '7-micro-expressions': {
    title: '7 Micro-Expressions That Reveal What People Are Really Thinking',
    category: 'Body Language',
    publishedAt: '2026-05-01',
    readTime: 6,
    excerpt: 'The face never lies — but most people don\'t know how to read it.',
    body: `## What Are Micro-Expressions?

Micro-expressions are brief, involuntary facial expressions that occur when a person either tries to conceal or unconsciously suppresses an emotion. They last only 1/25th to 1/5th of a second — so fast that most people miss them entirely.

Pioneered by psychologist Dr. Paul Ekman, micro-expressions reveal the seven universal emotions: **happiness, sadness, contempt, disgust, fear, anger, and surprise**.

## The 7 Universal Micro-Expressions

**1. Happiness** — Genuine happiness involves the orbicularis oculi muscle (around the eyes), causing crow's feet. A fake smile only moves the zygomatic major muscle (corners of the mouth).

**2. Sadness** — The inner corners of the eyebrows angle upward and together. The lower lip trembles or pouts slightly.

**3. Fear** — Eyebrows raise and pull together. Upper eyelids lift, lower eyelids tense. Lips stretch horizontally.

**4. Anger** — Brows lower and pull together. Eyes stare hard. Lips press together or open with tension.

**5. Disgust** — Upper lip curls. Nose wrinkles. Cheeks raise. This is the most universally recognisable expression.

**6. Contempt** — The only asymmetrical micro-expression. One corner of the mouth pulls up and back. A flash of contempt is one of the most reliable predictors of relationship breakdown.

**7. Surprise** — Eyebrows curve upward. Upper eyelids open wide. Jaw drops slightly. Surprise lasts less than a second — if it lasts longer, it may be feigned.

## How to Practice Reading Micro-Expressions

Start by watching interviews and muting the audio. Focus entirely on the face. Notice the flickers — the split-second shifts that contradict the words. With practice, you'll begin to see the emotional truth beneath every conversation.

> "The face is the mirror of the mind, and eyes without speaking confess the secrets of the heart." — St. Jerome`,
  },
  'nervous-system-hierarchy': {
    title: 'The Nervous System Hierarchy: Why You Freeze Under Pressure',
    category: 'Psychology',
    publishedAt: '2026-04-15',
    readTime: 8,
    excerpt: 'Understanding your autonomic nervous system is the first step to mastering your responses.',
    body: `## The Polyvagal Theory: A Framework for Understanding Stress

Dr. Stephen Porges' Polyvagal Theory revolutionised our understanding of the autonomic nervous system. It describes three distinct states that our nervous system cycles through — and understanding them is the key to regulating your responses under pressure.

## The Three Nervous System States

**1. Ventral Vagal (Safe & Social)**
This is your optimal state. You feel calm, connected, creative, and capable. Your voice is melodic, your face is expressive, your listening is sharp. This is where peak performance lives.

**2. Sympathetic Activation (Fight or Flight)**
When the nervous system perceives threat, it mobilises. Heart rate increases. Blood flow rushes to limbs. Digestion shuts down. Your brain narrows its focus. In a job interview or presentation, this shows up as a racing heart, dry mouth, or rushing speech.

**3. Dorsal Vagal (Freeze/Shutdown)**
The oldest evolutionary response. When fight or flight fails, the system collapses — you go blank, dissociate, or lose access to words. This is why people "freeze" in high-stakes moments.

## Why This Matters for Your Career

Most people try to manage their anxiety through willpower — "just calm down." But the nervous system doesn't respond to logic when it's in threat mode. It responds to physiological signals.

## Regulation Techniques That Actually Work

- **Physiological sigh**: Double inhale through the nose, long slow exhale through the mouth. This is the fastest way to downregulate the sympathetic nervous system.
- **Orienting response**: Slowly look around the room, let your eyes rest on objects without urgency. This signals safety to the nervous system.
- **Social engagement**: Talk to someone before a high-stakes event. The vagal nerve responds to human voice and eye contact.`,
  },
  'command-a-room': {
    title: 'How to Command a Room Without Saying a Word',
    category: 'Executive Presence',
    publishedAt: '2026-03-20',
    readTime: 5,
    excerpt: 'Executive presence is 93% non-verbal.',
    body: `## The Myth of Natural Presence

Most people believe commanding a room is something you either have or you don't. A natural charisma. An innate magnetism. This belief is wrong — and it keeps thousands of talented professionals invisible.

Executive presence is a skill. It is learnable, practicable, and measurable.

## The 5 Non-Verbal Pillars of Room Command

**1. Stillness**
People who command rooms move less, not more. Every unnecessary gesture dilutes authority. Train yourself to default to stillness — hands at rest, minimal head nodding, grounded feet.

**2. Spatial Ownership**
Expand, don't contract. Take up space — both physical (posture, arm placement) and environmental (where you sit, how you enter). Contraction signals submission. Expansion signals authority.

**3. Slow Everything Down**
The most commanding speakers pause before answering. They finish sentences without rushing. They look at someone for a full beat before looking away. Speed is the enemy of gravitas.

**4. Eye Contact Architecture**
Practice triangular eye contact — move between both eyes and the mouth. Maintain eye contact for 60–70% of the time when listening, and 40–60% when speaking. This signals confidence without aggression.

**5. The Entry**
You set the tone the moment you walk in. Pause at the threshold. Scan the room slowly. Move with intention. The first 7 seconds determine how the next 60 minutes are perceived.

> The room doesn't respond to what you say first. It responds to how you arrive.`,
  },
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const blog = await getBlog(params.slug)
  const demo = demoBlogs[params.slug]
  const title = blog?.title || demo?.title || 'Blog Post'
  return { title, description: blog?.excerpt || demo?.excerpt || '' }
}

export default async function BlogPostPage({ params }: Props) {
  const blog = await getBlog(params.slug)
  const demo = demoBlogs[params.slug]

  if (!blog && !demo) notFound()

  const data = blog || demo

  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site max-w-3xl">
          <Link href="/blog" className="text-[0.65rem] tracking-widest uppercase text-gold hover:text-gold-light transition-colors flex items-center gap-2 mb-8">
            ← Back to Journal
          </Link>
          <p className="section-label">{data.category}</p>
          <h1 className="font-serif font-light text-warm-white leading-tight mb-6"
              style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
            {data.title}
          </h1>
          <div className="flex gap-6 text-xs text-grey">
            <span>{new Date(data.publishedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
            <span>{data.readTime} min read</span>
            <span>By Kanan Tandi</span>
          </div>
        </div>
      </div>

      <article className="bg-charcoal py-16 px-6 lg:px-12">
        <div className="container-site max-w-3xl">
          {/* Thumbnail placeholder */}
          <div className="aspect-video bg-dark border border-white/5 flex items-center justify-center text-6xl text-gold/10 mb-12">
            ✦
          </div>

          {/* Render demo blog body as prose */}
          <div className="prose-kanan">
            {demo?.body ? (
              demo.body.split('\n').map((line, i) => {
                if (line.startsWith('## ')) return <h2 key={i}>{line.replace('## ', '')}</h2>
                if (line.startsWith('**') && line.endsWith('**')) return <p key={i}><strong>{line.replace(/\*\*/g, '')}</strong></p>
                if (line.startsWith('> ')) return <blockquote key={i}>{line.replace('> ', '')}</blockquote>
                if (line.startsWith('- ')) return <ul key={i}><li>{line.replace('- ', '')}</li></ul>
                if (line.trim() === '') return null
                return <p key={i}>{line}</p>
              })
            ) : (
              <p>Content loading from Sanity CMS...</p>
            )}
          </div>

          {/* Author card */}
          <div className="border border-white/8 bg-black p-8 mt-16 flex items-start gap-6">
            <div className="w-16 h-16 rounded-full bg-dark border border-gold/30 flex items-center justify-center font-serif text-gold text-2xl flex-shrink-0">
              K
            </div>
            <div>
              <p className="font-serif text-lg text-warm-white font-light mb-1">Kanan Tandi</p>
              <p className="text-[0.62rem] tracking-widest uppercase text-gold mb-3">Body Language & Psychology Expert</p>
              <p className="text-grey text-sm leading-relaxed">
                India's leading behavioural intelligence expert, helping professionals transform how
                they show up through the science of body language and psychology.
              </p>
              <Link href="/book" className="inline-block mt-4 btn-gold-ghost text-xs py-2 px-5">
                Book a Session
              </Link>
            </div>
          </div>
        </div>
      </article>
    </>
  )
}
