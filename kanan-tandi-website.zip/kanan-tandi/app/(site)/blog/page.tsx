import type { Metadata } from 'next'
import Link from 'next/link'
import { client } from '@/lib/sanity'

export const metadata: Metadata = {
  title: 'Blog — Insights on Psychology & Presence',
  description: 'Expert articles on body language, psychology, executive presence, and personal transformation by Kanan Tandi.',
}

async function getBlogs() {
  try {
    return await client.fetch(`
      *[_type == "blog" && published == true] | order(publishedAt desc) {
        _id, title, slug, excerpt, category, publishedAt, readTime
      }
    `)
  } catch {
    return []
  }
}

const demoBlogs = [
  { _id:'1', title:'7 Micro-Expressions That Reveal What People Are Really Thinking', slug:{current:'7-micro-expressions'}, excerpt:'The face never lies — but most people don\'t know how to read it. Here\'s what science says...', category:'Body Language', publishedAt:'2026-05-01', readTime:6 },
  { _id:'2', title:'The Nervous System Hierarchy: Why You Freeze Under Pressure', slug:{current:'nervous-system-hierarchy'}, excerpt:'Understanding your autonomic nervous system is the first step to mastering your responses in high-stakes situations...', category:'Psychology', publishedAt:'2026-04-15', readTime:8 },
  { _id:'3', title:'How to Command a Room Without Saying a Word', slug:{current:'command-a-room'}, excerpt:'Executive presence is 93% non-verbal. Here\'s a step-by-step guide to projecting authority...', category:'Executive Presence', publishedAt:'2026-03-20', readTime:5 },
  { _id:'4', title:'The Power Pose Myth — And What Actually Works', slug:{current:'power-pose-myth'}, excerpt:'Amy Cuddy\'s research sparked global conversation. But what does the latest science actually say about posture and confidence?', category:'Body Language', publishedAt:'2026-03-01', readTime:7 },
  { _id:'5', title:'Reading Liars: 9 Behavioural Cues to Watch For', slug:{current:'reading-liars'}, excerpt:'Deception detection is a nuanced skill — here\'s what trained behaviour analysts actually look for...', category:'Behaviour Analysis', publishedAt:'2026-02-10', readTime:9 },
  { _id:'6', title:'Why Your Voice Undermines Your Authority (And How to Fix It)', slug:{current:'vocal-authority'}, excerpt:'Vocal tone, pace, and pitch account for 38% of your impact. Most people are unconsciously signalling weakness...', category:'Communication', publishedAt:'2026-01-25', readTime:6 },
]

const symbols = ['✦', '◈', '❖', '◆', '✧', '◇']

export default async function BlogPage() {
  const blogs = (await getBlogs()).length > 0 ? await getBlogs() : demoBlogs

  return (
    <>
      <div className="pt-40 pb-16 px-6 lg:px-12 bg-black">
        <div className="container-site">
          <p className="section-label">The Journal</p>
          <h1 className="section-title mb-6">Insights &amp; <em>Wisdom</em></h1>
          <p className="text-light-grey text-base max-w-xl leading-relaxed">
            Deeply researched articles on human psychology, body language, executive presence,
            and the science of transformation.
          </p>
        </div>
      </div>

      <section className="bg-charcoal py-20 px-6 lg:px-12">
        <div className="container-site">
          {/* Featured post */}
          {blogs[0] && (
            <Link href={`/blog/${blogs[0].slug.current}`}
              className="group block border border-white/7 bg-black hover:border-gold/30 transition-all duration-300 mb-6 p-10 lg:p-14">
              <p className="text-[0.62rem] tracking-[0.25em] uppercase text-gold mb-4">{blogs[0].category} · Featured</p>
              <h2 className="font-serif text-3xl lg:text-4xl font-light text-warm-white mb-5 max-w-3xl leading-tight
                             group-hover:text-gold transition-colors duration-300">
                {blogs[0].title}
              </h2>
              <p className="text-grey text-sm leading-relaxed max-w-2xl mb-6">{blogs[0].excerpt}</p>
              <div className="flex gap-6 text-xs text-grey">
                <span>{new Date(blogs[0].publishedAt).toLocaleDateString('en-IN', { day:'numeric', month:'long', year:'numeric' })}</span>
                <span>{blogs[0].readTime} min read</span>
              </div>
            </Link>
          )}

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {blogs.slice(1).map((b: typeof demoBlogs[0], i: number) => (
              <Link key={b._id} href={`/blog/${b.slug.current}`}
                className="group block border-b border-white/7 pb-8 hover:border-gold/20 transition-all duration-300">
                <div className="aspect-video bg-dark border border-white/5 flex items-center justify-center
                                mb-5 text-4xl text-gold/15 group-hover:text-gold/30 transition-colors duration-300
                                group-hover:border-gold/15">
                  {symbols[i % symbols.length]}
                </div>
                <p className="text-[0.6rem] tracking-[0.2em] uppercase text-gold mb-2.5">{b.category}</p>
                <h3 className="font-serif text-lg font-light text-warm-white mb-3 leading-snug
                               group-hover:text-gold transition-colors duration-300">
                  {b.title}
                </h3>
                <p className="text-grey text-xs leading-relaxed mb-4">{b.excerpt}</p>
                <div className="flex gap-5 text-[0.68rem] text-grey">
                  <span>{new Date(b.publishedAt).toLocaleDateString('en-IN', { day:'numeric', month:'short' })}</span>
                  <span>{b.readTime} min read</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
