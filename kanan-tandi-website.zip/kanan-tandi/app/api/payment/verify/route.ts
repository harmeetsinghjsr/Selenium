import { NextResponse } from 'next/server'
import { verifyPaymentSignature } from '@/lib/razorpay'
import { logToSheets } from '@/lib/google-sheets'
import { sendBookingConfirmation } from '@/lib/resend'
import { createCalendarEvent } from '@/lib/google-calendar'

export async function POST(req: Request) {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      bookingData,
    } = await req.json()

    const isValid = verifyPaymentSignature(
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature
    )

    if (!isValid) {
      return NextResponse.json({ error: 'Invalid payment signature' }, { status: 400 })
    }

    // Log to Google Sheets
    await logToSheets('bookings', {
      name:      bookingData.name,
      email:     bookingData.email,
      phone:     bookingData.phone,
      service:   bookingData.service,
      date:      bookingData.date,
      slot:      bookingData.slot,
      paymentId: razorpay_payment_id,
      orderId:   razorpay_order_id,
    })

    // Send confirmation email
    await sendBookingConfirmation({
      name:      bookingData.name,
      email:     bookingData.email,
      service:   bookingData.service,
      date:      bookingData.date,
      slot:      bookingData.slot,
      paymentId: razorpay_payment_id,
    })

    // Add to Google Calendar (optional — wrap in try/catch so it doesn't block)
    try {
      const [datePart] = bookingData.date.split('T')
      const timePart   = bookingData.slot.replace(':00 ', '').replace(' AM', '').replace(' PM', '')
      // parse IST time into ISO — simplified
      const startISO = `${datePart}T${timePart.padStart(5,'0')}:00+05:30`
      const endISO   = `${datePart}T${(parseInt(timePart)+1).toString().padStart(2,'0')}:00:00+05:30`
      await createCalendarEvent({
        summary:       `${bookingData.service} — ${bookingData.name}`,
        description:   `Booking by ${bookingData.name} (${bookingData.email})`,
        startDateTime: startISO,
        endDateTime:   endISO,
        attendeeEmail: bookingData.email,
      })
    } catch (calErr) {
      console.warn('Calendar event creation failed (non-blocking):', calErr)
    }

    return NextResponse.json({ success: true, paymentId: razorpay_payment_id })
  } catch (err) {
    console.error('Payment verify error:', err)
    return NextResponse.json({ error: 'Verification failed' }, { status: 500 })
  }
}
