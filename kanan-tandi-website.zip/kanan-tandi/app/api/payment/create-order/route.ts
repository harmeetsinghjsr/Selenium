import { NextResponse } from 'next/server'
import { createOrder } from '@/lib/razorpay'

export async function POST(req: Request) {
  try {
    const { amount } = await req.json()
    if (!amount || amount < 1) {
      return NextResponse.json({ error: 'Invalid amount' }, { status: 400 })
    }
    const order = await createOrder(Number(amount))
    return NextResponse.json(order)
  } catch (err) {
    console.error('Create order error:', err)
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 })
  }
}
