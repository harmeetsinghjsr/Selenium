import { NextResponse } from 'next/server'
import { logToSheets } from '@/lib/google-sheets'
import { sendNewsletterWelcome } from '@/lib/resend'

export async function POST(req: Request) {
  try {
    const { email } = await req.json()
    if (!email || !email.includes('@')) {
      return NextResponse.json({ error: 'Invalid email' }, { status: 400 })
    }

    await logToSheets('newsletter', { email })
    await sendNewsletterWelcome(email)

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('Newsletter error:', err)
    return NextResponse.json({ error: 'Subscription failed' }, { status: 500 })
  }
}
