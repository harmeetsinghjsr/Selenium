import { NextResponse } from 'next/server'
import { logToSheets } from '@/lib/google-sheets'
import { sendBookingConfirmation } from '@/lib/resend'

export async function POST(req: Request) {
  try {
    const body = await req.json()

    await logToSheets('bookings', {
      name:    body.name,
      email:   body.email,
      phone:   body.phone,
      service: body.service,
      date:    body.date,
      slot:    body.slot,
      notes:   body.notes || '',
      paid:    false,
    })

    await sendBookingConfirmation({
      name:    body.name,
      email:   body.email,
      service: body.service,
      date:    body.date,
      slot:    body.slot,
    })

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('Booking error:', err)
    return NextResponse.json({ error: 'Booking failed' }, { status: 500 })
  }
}
