import { NextResponse } from 'next/server'
import { logToSheets } from '@/lib/google-sheets'
import { sendContactNotification } from '@/lib/resend'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { name, email, phone, subject, message } = body

    if (!name || !email || !subject || !message) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    await logToSheets('leads', { name, email, phone: phone || '', subject, message })
    await sendContactNotification({ name, email, subject, message })

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('Contact error:', err)
    return NextResponse.json({ error: 'Failed to send message' }, { status: 500 })
  }
}
