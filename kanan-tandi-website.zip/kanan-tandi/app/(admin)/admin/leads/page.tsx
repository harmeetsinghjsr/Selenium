import type { Metadata } from 'next'
export const metadata: Metadata = { title: 'Leads | Admin' }

const mockLeads = [
  { id:'L001', name:'Priya Sharma',   email:'priya@gmail.com',     phone:'+91 98765 11111', subject:'1:1 Consultation Enquiry', date:'May 12, 2026', status:'Replied' },
  { id:'L002', name:'Rohan Mehta',    email:'rohan@outlook.com',   phone:'+91 98765 22222', subject:'Corporate Workshop',        date:'May 11, 2026', status:'New' },
  { id:'L003', name:'Arun Kapoor',    email:'arun@company.com',    phone:'+91 98765 33333', subject:'Media / Speaking Enquiry',  date:'May 10, 2026', status:'New' },
  { id:'L004', name:'Sunita Rao',     email:'sunita@gov.in',       phone:'+91 98765 44444', subject:'Course Information',        date:'May 9, 2026',  status:'Converted' },
  { id:'L005', name:'Vikram Nair',    email:'vikram@startup.io',   phone:'+91 98765 55555', subject:'Partnership',               date:'May 8, 2026',  status:'Replied' },
  { id:'L006', name:'Meera Iyer',     email:'meera@corp.in',       phone:'+91 98765 66666', subject:'Corporate Workshop',        date:'May 7, 2026',  status:'Converted' },
]

const statusColors: Record<string, string> = {
  New:       'bg-blue-900/30 text-blue-400',
  Replied:   'bg-yellow-900/20 text-yellow-500',
  Converted: 'bg-green-900/30 text-green-400',
  Closed:    'bg-white/5 text-grey',
}

export default function AdminLeadsPage() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="font-serif text-3xl font-light text-warm-white mb-1">Leads</h1>
        <p className="text-grey text-sm">Contact form submissions and enquiries.</p>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label:'Total Leads', value:'234' },
          { label:'New (This Week)', value:'28' },
          { label:'Conversion Rate', value:'34%' },
          { label:'Avg Response Time', value:'4 hrs' },
        ].map(s => (
          <div key={s.label} className="bg-charcoal border border-white/6 p-5 text-center">
            <div className="font-serif text-2xl text-warm-white mb-1">{s.value}</div>
            <div className="text-[0.6rem] tracking-widest uppercase text-grey">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="bg-charcoal border border-white/6 overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/5">
              {['ID', 'Name', 'Contact', 'Subject', 'Date', 'Status'].map(h => (
                <th key={h} className="text-left px-5 py-4 text-[0.6rem] tracking-widest uppercase text-grey font-normal">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {mockLeads.map(lead => (
              <tr key={lead.id} className="border-b border-white/4 hover:bg-white/2 transition-colors">
                <td className="px-5 py-4 text-xs text-grey font-mono">{lead.id}</td>
                <td className="px-5 py-4 text-sm text-warm-white">{lead.name}</td>
                <td className="px-5 py-4">
                  <div className="text-xs text-grey">{lead.email}</div>
                  <div className="text-xs text-grey">{lead.phone}</div>
                </td>
                <td className="px-5 py-4 text-sm text-grey">{lead.subject}</td>
                <td className="px-5 py-4 text-sm text-grey">{lead.date}</td>
                <td className="px-5 py-4">
                  <span className={`text-[0.58rem] tracking-wider uppercase px-2 py-1 ${statusColors[lead.status]}`}>
                    {lead.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
