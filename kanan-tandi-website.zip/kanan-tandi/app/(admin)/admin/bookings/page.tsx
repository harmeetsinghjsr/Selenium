import type { Metadata } from 'next'
import { logToSheets } from '@/lib/google-sheets'

export const metadata: Metadata = { title: 'Bookings | Admin' }

const mockBookings = [
  { id:'BK001', name:'Priya Sharma',  email:'priya@gmail.com',   phone:'+91 98765 11111', service:'1:1 Consultation 60min', date:'June 15, 2026', slot:'3:00 PM', status:'Confirmed', amount:2999, paymentId:'pay_abc123' },
  { id:'BK002', name:'Rohan Mehta',   email:'rohan@outlook.com', phone:'+91 98765 22222', service:'Interview Coaching',     date:'June 14, 2026', slot:'11:00 AM', status:'Completed', amount:1999, paymentId:'pay_def456' },
  { id:'BK003', name:'Arun Kapoor',   email:'arun@company.com',  phone:'+91 98765 33333', service:'Corporate Discovery Call', date:'June 12, 2026', slot:'2:00 PM', status:'Pending', amount:0, paymentId:'' },
  { id:'BK004', name:'Sunita Rao',    email:'sunita@gov.in',     phone:'+91 98765 44444', service:'1:1 Consultation 90min', date:'June 11, 2026', slot:'4:00 PM', status:'Confirmed', amount:4499, paymentId:'pay_ghi789' },
]

const statusColors: Record<string, string> = {
  Confirmed: 'bg-green-900/30 text-green-400',
  Completed: 'bg-blue-900/30 text-blue-400',
  Pending:   'bg-yellow-900/20 text-yellow-500',
  Cancelled: 'bg-red-900/20 text-red-400',
}

export default function AdminBookingsPage() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="font-serif text-3xl font-light text-warm-white mb-1">Bookings</h1>
        <p className="text-grey text-sm">All session bookings in one place.</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label:'Total', value:'47' },
          { label:'Confirmed', value:'28' },
          { label:'Pending', value:'5' },
          { label:'This Month Revenue', value:'₹84,470' },
        ].map(s => (
          <div key={s.label} className="bg-charcoal border border-white/6 p-5 text-center">
            <div className="font-serif text-2xl text-warm-white mb-1">{s.value}</div>
            <div className="text-[0.6rem] tracking-widest uppercase text-grey">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="bg-charcoal border border-white/6 overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/5">
              {['ID', 'Client', 'Service', 'Date & Time', 'Status', 'Amount', 'Payment ID'].map(h => (
                <th key={h} className="text-left px-5 py-4 text-[0.6rem] tracking-widest uppercase text-grey font-normal">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {mockBookings.map(b => (
              <tr key={b.id} className="border-b border-white/4 hover:bg-white/2 transition-colors">
                <td className="px-5 py-4 text-xs text-grey font-mono">{b.id}</td>
                <td className="px-5 py-4">
                  <div className="text-sm text-warm-white">{b.name}</div>
                  <div className="text-xs text-grey">{b.email}</div>
                </td>
                <td className="px-5 py-4 text-sm text-grey">{b.service}</td>
                <td className="px-5 py-4">
                  <div className="text-sm text-light-grey">{b.date}</div>
                  <div className="text-xs text-grey">{b.slot}</div>
                </td>
                <td className="px-5 py-4">
                  <span className={`text-[0.58rem] tracking-wider uppercase px-2 py-1 ${statusColors[b.status]}`}>
                    {b.status}
                  </span>
                </td>
                <td className="px-5 py-4 text-sm text-gold">
                  {b.amount > 0 ? `₹${b.amount.toLocaleString('en-IN')}` : 'Free'}
                </td>
                <td className="px-5 py-4 text-xs text-grey font-mono">{b.paymentId || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
