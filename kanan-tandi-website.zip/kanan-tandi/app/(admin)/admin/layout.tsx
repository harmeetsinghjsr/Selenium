import Link from 'next/link'
import { LayoutDashboard, BookOpen, Calendar, FileText, Users, CreditCard, Settings } from 'lucide-react'

const navItems = [
  { label:'Dashboard',  href:'/admin',              icon: LayoutDashboard },
  { label:'Bookings',   href:'/admin/bookings',     icon: Calendar },
  { label:'Courses',    href:'/admin/courses',      icon: BookOpen },
  { label:'Blog',       href:'/admin/blogs',        icon: FileText },
  { label:'Leads',      href:'/admin/leads',        icon: Users },
  { label:'Availability', href:'/admin/availability', icon: Calendar },
]

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-black flex">
      {/* Sidebar */}
      <aside className="w-64 bg-charcoal border-r border-white/5 flex flex-col">
        <div className="p-6 border-b border-white/5">
          <Link href="/" className="font-serif text-lg tracking-widest text-warm-white block">
            KANAN <span className="text-gold">TANDI</span>
          </Link>
          <p className="text-[0.6rem] tracking-widest uppercase text-grey mt-1">Admin Panel</p>
        </div>
        <nav className="flex-1 p-4">
          <ul className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon
              return (
                <li key={item.href}>
                  <Link href={item.href}
                    className="flex items-center gap-3 px-4 py-3 text-sm text-grey hover:text-warm-white
                               hover:bg-white/5 transition-all duration-200 rounded-sm group">
                    <Icon size={16} className="group-hover:text-gold transition-colors duration-200" />
                    {item.label}
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>
        <div className="p-4 border-t border-white/5">
          <Link href="/api/auth/signout"
            className="flex items-center gap-3 px-4 py-3 text-xs text-grey hover:text-warm-white transition-colors duration-200">
            <Settings size={14} />
            Sign Out
          </Link>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  )
}
