'use client'
import { useState } from 'react'
import { Plus, Edit, Trash2, Eye, EyeOff } from 'lucide-react'

type Course = {
  id: string; title: string; price: number; earlyBirdPrice: number
  date: string; published: boolean; seats: number
}

const initialCourses: Course[] = [
  { id:'1', title:'Body Language Mastery: The Complete Program', price:7999, earlyBirdPrice:4999, date:'2026-06-01', published:true, seats:50 },
  { id:'2', title:'Executive Presence Accelerator', price:5999, earlyBirdPrice:3499, date:'2026-07-01', published:true, seats:30 },
  { id:'3', title:'Interview Confidence Blueprint', price:2999, earlyBirdPrice:1799, date:'', published:false, seats:100 },
]

export default function AdminCoursesPage() {
  const [courses, setCourses] = useState<Course[]>(initialCourses)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({
    title:'', description:'', price:'', earlyBirdPrice:'', date:'', seats:'', meetingLink:''
  })

  function handleAdd() {
    const newCourse: Course = {
      id: Date.now().toString(),
      title: form.title,
      price: Number(form.price),
      earlyBirdPrice: Number(form.earlyBirdPrice),
      date: form.date,
      published: false,
      seats: Number(form.seats) || 50,
    }
    setCourses(prev => [newCourse, ...prev])
    setForm({ title:'', description:'', price:'', earlyBirdPrice:'', date:'', seats:'', meetingLink:'' })
    setShowForm(false)
  }

  function togglePublish(id: string) {
    setCourses(prev => prev.map(c => c.id === id ? {...c, published: !c.published} : c))
  }

  function deleteCourse(id: string) {
    if (confirm('Delete this course?')) setCourses(prev => prev.filter(c => c.id !== id))
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-serif text-3xl font-light text-warm-white mb-1">Courses</h1>
          <p className="text-grey text-sm">Manage your online programs and workshops.</p>
        </div>
        <button onClick={() => setShowForm(v => !v)} className="btn-primary flex items-center gap-2">
          <Plus size={16} /> Add Course
        </button>
      </div>

      {/* Add form */}
      {showForm && (
        <div className="bg-charcoal border border-gold/20 p-8 mb-8">
          <h2 className="font-serif text-xl text-warm-white font-light mb-6">New Course</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {[
              { key:'title',         label:'Course Title',      type:'text',   span:2 },
              { key:'description',   label:'Short Description', type:'text',   span:2 },
              { key:'price',         label:'Full Price (₹)',     type:'number', span:1 },
              { key:'earlyBirdPrice',label:'Early Bird Price',   type:'number', span:1 },
              { key:'date',          label:'Start Date',         type:'date',   span:1 },
              { key:'seats',         label:'Max Seats',          type:'number', span:1 },
              { key:'meetingLink',   label:'Meeting Link',       type:'url',    span:2 },
            ].map(f => (
              <div key={f.key} className={f.span === 2 ? 'md:col-span-2' : ''}>
                <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">{f.label}</label>
                <input
                  type={f.type}
                  value={form[f.key as keyof typeof form]}
                  onChange={e => setForm(p => ({...p, [f.key]: e.target.value}))}
                  className="input-field"
                />
              </div>
            ))}
          </div>
          <div className="flex gap-4 mt-6">
            <button onClick={handleAdd} className="btn-primary">Create Course</button>
            <button onClick={() => setShowForm(false)} className="btn-ghost">Cancel</button>
          </div>
        </div>
      )}

      {/* Course list */}
      <div className="space-y-3">
        {courses.map((course) => (
          <div key={course.id}
            className="bg-charcoal border border-white/6 p-6 flex items-center justify-between gap-6 flex-wrap">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 mb-1">
                <h3 className="font-serif text-lg text-warm-white font-light truncate">{course.title}</h3>
                <span className={`text-[0.55rem] tracking-widest uppercase px-2 py-0.5 flex-shrink-0 ${
                  course.published ? 'bg-green-900/30 text-green-400' : 'bg-yellow-900/20 text-yellow-500'
                }`}>
                  {course.published ? 'Published' : 'Draft'}
                </span>
              </div>
              <div className="flex gap-6 text-xs text-grey">
                <span>₹{course.price.toLocaleString('en-IN')}</span>
                {course.earlyBirdPrice < course.price && (
                  <span className="text-gold">Early Bird: ₹{course.earlyBirdPrice.toLocaleString('en-IN')}</span>
                )}
                {course.date && <span>{course.date}</span>}
                <span>{course.seats} seats</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => togglePublish(course.id)}
                className="w-9 h-9 border border-white/10 flex items-center justify-center
                           text-grey hover:text-gold hover:border-gold/40 transition-all duration-200">
                {course.published ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
              <button className="w-9 h-9 border border-white/10 flex items-center justify-center
                                 text-grey hover:text-gold hover:border-gold/40 transition-all duration-200">
                <Edit size={15} />
              </button>
              <button onClick={() => deleteCourse(course.id)}
                className="w-9 h-9 border border-white/10 flex items-center justify-center
                           text-grey hover:text-red-400 hover:border-red-900/50 transition-all duration-200">
                <Trash2 size={15} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
