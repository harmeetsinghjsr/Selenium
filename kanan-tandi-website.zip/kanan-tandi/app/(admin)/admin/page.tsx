import type { Metadata } from 'next'
import Link from 'next/link'
import { BookOpen, Calendar, Users, TrendingUp } from 'lucide-react'

export const metadata: Metadata = { title: 'Admin Dashboard' }

const stats = [
  { label:'Total Bookings',    value:'47',    change:'+12 this month', icon: Calendar,    color:'text-blue-400' },
  { label:'Active Courses',    value:'4',     change:'2 drafts pending', icon: BookOpen,  color:'text-gold' },
  { label:'Total Leads',       value:'234',   change:'+28 this week',    icon: Users,     color:'text-green-400' },
  { label:'Revenue (month)',   value:'₹1.2L', change:'+18% vs last month', icon: TrendingUp, color:'text-purple-400' },
]

const recentBookings = [
  { name:'Priya Sharma',  service:'1:1 Consultation', date:'June 15', status:'Confirmed', amount:'₹2,999' },
  { name:'Rohan Mehta',   service:'Interview Coaching', date:'June 14', status:'Completed', amount:'₹1,999' },
  { name:'Arun Kapoor',   service:'Corporate Workshop', date:'June 12', status:'Pending', amount:'Custom' },
  { name:'Sunita Rao',    service:'1:1 Consultation', date:'June 11', status:'Confirmed', amount:'₹4,499' },
  { name:'Vikram Nair',   service:'Group Workshop',   date:'June 10', status:'Completed', amount:'₹2,499' },
]

export default function AdminDashboard() {
  return (
    <div className="p-8">
      <div className="mb-10">
        <h1 className="font-serif text-3xl font-light text-warm-white mb-1">Dashboard</h1>
        <p className="text-grey text-sm">Welcome back, Kanan. Here's what's happening.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {stats.map((s) => {
          const Icon = s.icon
          return (
            <div key={s.label} className="bg-charcoal border border-white/6 p-6">
              <div className="flex items-center justify-between mb-4">
                <p className="text-[0.65rem] tracking-widest uppercase text-grey">{s.label}</p>
                <Icon size={16} className={s.color} />
              </div>
              <p className="font-serif text-3xl text-warm-white mb-1">{s.value}</p>
              <p className="text-[0.7rem] text-grey">{s.change}</p>
            </div>
          )
        })}
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-10">
        {[
          { label:'Add New Course',    href:'/admin/courses', emoji:'📚' },
          { label:'Write Blog Post',   href:'/admin/blogs',   emoji:'✍️' },
          { label:'View Bookings',     href:'/admin/bookings', emoji:'📅' },
          { label:'Set Availability',  href:'/admin/availability', emoji:'🗓️' },
        ].map((action) => (
          <Link key={action.href} href={action.href}
            className="bg-dark border border-white/6 hover:border-gold/30 p-5 transition-all duration-200 text-center">
            <span className="block text-2xl mb-2">{action.emoji}</span>
            <span className="text-sm text-light-grey">{action.label}</span>
          </Link>
        ))}
      </div>

      {/* Recent Bookings */}
      <div className="bg-charcoal border border-white/6">
        <div className="flex items-center justify-between p-6 border-b border-white/5">
          <h2 className="font-serif text-lg font-light text-warm-white">Recent Bookings</h2>
          <Link href="/admin/bookings" className="text-gold text-xs hover:underline">View All</Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                {['Client', 'Service', 'Date', 'Status', 'Amount'].map((h) => (
                  <th key={h} className="text-left px-6 py-3 text-[0.62rem] tracking-widest uppercase text-grey font-normal">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentBookings.map((b, i) => (
                <tr key={i} className="border-b border-white/5 hover:bg-white/2 transition-colors">
                  <td className="px-6 py-4 text-sm text-warm-white">{b.name}</td>
                  <td className="px-6 py-4 text-sm text-grey">{b.service}</td>
                  <td className="px-6 py-4 text-sm text-grey">{b.date}</td>
                  <td className="px-6 py-4">
                    <span className={`text-[0.6rem] tracking-wider uppercase px-2 py-1 ${
                      b.status === 'Confirmed'  ? 'bg-green-900/30 text-green-400' :
                      b.status === 'Completed'  ? 'bg-blue-900/30 text-blue-400' :
                                                  'bg-yellow-900/30 text-yellow-400'
                    }`}>
                      {b.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gold font-medium">{b.amount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
