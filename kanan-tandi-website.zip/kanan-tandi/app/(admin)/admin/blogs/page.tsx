'use client'
import { useState } from 'react'
import { Plus, Edit, Trash2, Eye, EyeOff } from 'lucide-react'

type Blog = { id:string; title:string; category:string; publishedAt:string; published:boolean; readTime:number }

const initialBlogs: Blog[] = [
  { id:'1', title:'7 Micro-Expressions That Reveal What People Are Really Thinking', category:'Body Language', publishedAt:'2026-05-01', published:true, readTime:6 },
  { id:'2', title:'The Nervous System Hierarchy: Why You Freeze Under Pressure', category:'Psychology', publishedAt:'2026-04-15', published:true, readTime:8 },
  { id:'3', title:'How to Command a Room Without Saying a Word', category:'Executive Presence', publishedAt:'2026-03-20', published:true, readTime:5 },
  { id:'4', title:'Draft: Relationship Attachment Styles Explained', category:'Relationship Psychology', publishedAt:'', published:false, readTime:7 },
]

const categories = ['Body Language', 'Psychology', 'Executive Presence', 'Communication', 'Behaviour Analysis', 'Relationship Psychology', 'Interview Confidence']

export default function AdminBlogsPage() {
  const [blogs, setBlogs]     = useState<Blog[]>(initialBlogs)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ title:'', category:categories[0], excerpt:'', content:'', seoTitle:'', seoDesc:'', readTime:'5' })

  function handleAdd() {
    const newBlog: Blog = {
      id: Date.now().toString(), title:form.title, category:form.category,
      publishedAt: new Date().toISOString().split('T')[0], published:false, readTime:Number(form.readTime),
    }
    setBlogs(prev => [newBlog, ...prev])
    setShowForm(false)
  }

  function togglePublish(id: string) {
    setBlogs(prev => prev.map(b => b.id === id ? {...b, published:!b.published} : b))
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-serif text-3xl font-light text-warm-white mb-1">Blog Posts</h1>
          <p className="text-grey text-sm">Create and manage your journal articles.</p>
        </div>
        <button onClick={() => setShowForm(v => !v)} className="btn-primary flex items-center gap-2">
          <Plus size={16} /> New Post
        </button>
      </div>

      {showForm && (
        <div className="bg-charcoal border border-gold/20 p-8 mb-8">
          <h2 className="font-serif text-xl text-warm-white font-light mb-6">New Blog Post</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="md:col-span-2">
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Post Title</label>
              <input value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))} className="input-field" placeholder="Enter blog title..." />
            </div>
            <div>
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Category</label>
              <select value={form.category} onChange={e=>setForm(p=>({...p,category:e.target.value}))} className="input-field">
                {categories.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Read Time (mins)</label>
              <input type="number" value={form.readTime} onChange={e=>setForm(p=>({...p,readTime:e.target.value}))} className="input-field" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Excerpt</label>
              <textarea value={form.excerpt} onChange={e=>setForm(p=>({...p,excerpt:e.target.value}))} rows={2} className="input-field resize-none" placeholder="Short summary..." />
            </div>
            <div className="md:col-span-2">
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">Content (Markdown)</label>
              <textarea value={form.content} onChange={e=>setForm(p=>({...p,content:e.target.value}))} rows={8} className="input-field resize-none font-mono text-xs" placeholder="Write your blog post content here in Markdown..." />
            </div>
            <div>
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">SEO Title</label>
              <input value={form.seoTitle} onChange={e=>setForm(p=>({...p,seoTitle:e.target.value}))} className="input-field" placeholder="SEO optimised title..." />
            </div>
            <div>
              <label className="block text-[0.62rem] tracking-widest uppercase text-gold mb-2">SEO Description</label>
              <input value={form.seoDesc} onChange={e=>setForm(p=>({...p,seoDesc:e.target.value}))} className="input-field" placeholder="Meta description (155 chars)..." />
            </div>
          </div>
          <p className="text-[0.6rem] text-grey mb-4">
            💡 For advanced editing with image uploads and rich content, connect Sanity CMS (see README).
          </p>
          <div className="flex gap-4">
            <button onClick={handleAdd} className="btn-primary">Save as Draft</button>
            <button onClick={() => setShowForm(false)} className="btn-ghost">Cancel</button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {blogs.map((blog) => (
          <div key={blog.id}
            className="bg-charcoal border border-white/6 p-5 flex items-center justify-between gap-4 flex-wrap hover:border-white/10 transition-colors">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 mb-1 flex-wrap">
                <h3 className="font-serif text-base text-warm-white font-light truncate">{blog.title}</h3>
                <span className={`text-[0.55rem] tracking-widest uppercase px-2 py-0.5 flex-shrink-0 ${
                  blog.published ? 'bg-green-900/30 text-green-400' : 'bg-yellow-900/20 text-yellow-500'
                }`}>
                  {blog.published ? 'Published' : 'Draft'}
                </span>
              </div>
              <div className="flex gap-4 text-xs text-grey">
                <span className="text-gold">{blog.category}</span>
                {blog.publishedAt && <span>{blog.publishedAt}</span>}
                <span>{blog.readTime} min read</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => togglePublish(blog.id)}
                className="w-9 h-9 border border-white/10 flex items-center justify-center text-grey hover:text-gold hover:border-gold/40 transition-all duration-200">
                {blog.published ? <EyeOff size={15}/> : <Eye size={15}/>}
              </button>
              <button className="w-9 h-9 border border-white/10 flex items-center justify-center text-grey hover:text-gold hover:border-gold/40 transition-all">
                <Edit size={15}/>
              </button>
              <button onClick={() => setBlogs(prev => prev.filter(b => b.id !== blog.id))}
                className="w-9 h-9 border border-white/10 flex items-center justify-center text-grey hover:text-red-400 hover:border-red-900/50 transition-all">
                <Trash2 size={15}/>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
