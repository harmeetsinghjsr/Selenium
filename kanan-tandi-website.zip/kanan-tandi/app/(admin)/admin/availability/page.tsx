'use client'
import { useState } from 'react'

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
const slots = ['9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM', '6:00 PM', '7:00 PM']

type Availability = Record<string, string[]>

const defaultAvailability: Availability = {
  Monday:    ['10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM', '4:00 PM'],
  Tuesday:   ['10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM'],
  Wednesday: ['2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM'],
  Thursday:  ['10:00 AM', '11:00 AM'],
  Friday:    ['10:00 AM', '2:00 PM', '3:00 PM'],
  Saturday:  [],
  Sunday:    [],
}

export default function AdminAvailabilityPage() {
  const [availability, setAvailability] = useState<Availability>(defaultAvailability)
  const [saved, setSaved] = useState(false)

  function toggleSlot(day: string, slot: string) {
    setAvailability(prev => {
      const current = prev[day] || []
      const next = current.includes(slot) ? current.filter(s => s !== slot) : [...current, slot]
      return { ...prev, [day]: next }
    })
    setSaved(false)
  }

  function handleSave() {
    // In production: POST to an API route that saves to Google Sheets or DB
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-serif text-3xl font-light text-warm-white mb-1">Availability</h1>
          <p className="text-grey text-sm">Set which time slots are available for booking each week.</p>
        </div>
        <button onClick={handleSave} className="btn-primary">
          {saved ? '✓ Saved!' : 'Save Availability'}
        </button>
      </div>

      <div className="space-y-4">
        {days.map(day => (
          <div key={day} className="bg-charcoal border border-white/6 p-6">
            <div className="flex items-center gap-4 mb-4">
              <h3 className="text-sm font-medium text-warm-white w-28">{day}</h3>
              <span className="text-[0.6rem] tracking-widest uppercase text-grey">
                {(availability[day] || []).length} slots available
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {slots.map(slot => {
                const isActive = (availability[day] || []).includes(slot)
                return (
                  <button
                    key={slot}
                    onClick={() => toggleSlot(day, slot)}
                    className={`px-4 py-2 text-xs border transition-all duration-150 ${
                      isActive
                        ? 'bg-gold border-gold text-black'
                        : 'border-white/10 text-grey hover:border-gold/40 hover:text-light-grey'
                    }`}
                  >
                    {slot}
                  </button>
                )
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 border border-gold/20 bg-gold/5 p-6">
        <p className="text-[0.65rem] tracking-widest uppercase text-gold mb-2">Note</p>
        <p className="text-grey text-sm">
          Changes here update which time slots appear on the public booking page.
          For Google Calendar integration, connect your calendar in the .env file.
        </p>
      </div>
    </div>
  )
}
