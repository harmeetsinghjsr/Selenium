import type { Metadata } from 'next'
import './globals.css'
import { Toaster } from 'react-hot-toast'

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_BASE_URL || 'https://kanantandi.com'),
  title: {
    default: 'Kanan Tandi | Body Language & Psychology Expert',
    template: '%s | Kanan Tandi',
  },
  description:
    'India\'s leading body language and behavioural intelligence expert. 1:1 consultations, workshops, and online courses on executive presence, psychology, and personal transformation.',
  keywords: [
    'body language expert India',
    'executive presence coach',
    'interview confidence coach',
    'psychology coach India',
    'human behaviour expert',
    'corporate communication trainer',
    'nervous system regulation',
    'behaviour analysis',
    'kanan tandi',
  ],
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    url: 'https://kanantandi.com',
    siteName: 'Kanan Tandi',
    title: 'Kanan Tandi | Body Language & Psychology Expert',
    description:
      'Decode the language beyond words. Master body language, executive presence, and psychological intelligence.',
    images: [{ url: '/og-image.jpg', width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Kanan Tandi | Body Language & Psychology Expert',
    description: 'Decode the language beyond words.',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large' },
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="grain">
      <body>
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#1e1b18',
              color: '#f5f0e8',
              border: '1px solid #2c2824',
              fontFamily: 'Outfit, sans-serif',
              fontSize: '0.85rem',
            },
          }}
        />
      </body>
    </html>
  )
}
