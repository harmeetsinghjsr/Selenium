'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Menu, X } from 'lucide-react'

const links = [
  { label: 'About',      href: '/about' },
  { label: 'Services',   href: '/services' },
  { label: 'Workshops',  href: '/workshops' },
  { label: 'Courses',    href: '/courses' },
  { label: 'Blog',       href: '/blog' },
  { label: 'Media',      href: '/media' },
  { label: 'Contact',    href: '/contact' },
]

export default function Navbar() {
  const [scrolled, setScrolled]   = useState(false)
  const [menuOpen, setMenuOpen]   = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-black/95 backdrop-blur-md border-b border-white/5 py-4'
            : 'py-7'
        }`}
      >
        <div className="container-site flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="font-serif text-xl font-light tracking-widest text-warm-white">
            KANAN <span className="text-gold">TANDI</span>
          </Link>

          {/* Desktop Nav */}
          <ul className="hidden lg:flex items-center gap-9">
            {links.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  className={`text-[0.7rem] tracking-[0.15em] uppercase transition-colors duration-300 ${
                    pathname === l.href ? 'text-gold' : 'text-light-grey hover:text-warm-white'
                  }`}
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>

          {/* CTA */}
          <Link href="/book" className="hidden lg:block btn-gold-ghost text-[0.7rem] py-2.5 px-5">
            Book Session
          </Link>

          {/* Mobile Menu Toggle */}
          <button
            className="lg:hidden text-warm-white"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>

      {/* Mobile Drawer */}
      <div
        className={`fixed inset-0 z-40 bg-black/98 flex flex-col justify-center items-center gap-8 transition-all duration-500 lg:hidden ${
          menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        {links.map((l, i) => (
          <Link
            key={l.href}
            href={l.href}
            onClick={() => setMenuOpen(false)}
            className="font-serif text-3xl font-light text-warm-white hover:text-gold transition-colors duration-300"
            style={{ animationDelay: `${i * 0.06}s` }}
          >
            {l.label}
          </Link>
        ))}
        <Link
          href="/book"
          onClick={() => setMenuOpen(false)}
          className="btn-primary mt-4"
        >
          Book a Session
        </Link>
      </div>
    </>
  )
}
