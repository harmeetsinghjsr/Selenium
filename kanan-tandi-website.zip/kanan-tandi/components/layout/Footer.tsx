import Link from 'next/link'
import { Instagram, Linkedin, Youtube } from 'lucide-react'

const services = [
  { label: '1:1 Consultation', href: '/book' },
  { label: 'Corporate Training', href: '/corporate' },
  { label: 'Group Workshops', href: '/workshops' },
  { label: 'Online Courses', href: '/courses' },
  { label: 'Interview Coaching', href: '/services' },
]
const learn = [
  { label: 'Blog', href: '/blog' },
  { label: 'Media Features', href: '/media' },
  { label: 'Testimonials', href: '/testimonials' },
  { label: 'About Kanan', href: '/about' },
  { label: 'FAQ', href: '/faq' },
]
const legal = [
  { label: 'Privacy Policy', href: '/privacy' },
  { label: 'Terms & Conditions', href: '/terms' },
  { label: 'Refund Policy', href: '/refund' },
  { label: 'Contact', href: '/contact' },
]

export default function Footer() {
  return (
    <footer className="bg-charcoal border-t border-white/5">
      <div className="container-site py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div>
            <Link href="/" className="font-serif text-2xl font-light tracking-widest text-warm-white block mb-5">
              KANAN <span className="text-gold">TANDI</span>
            </Link>
            <p className="text-grey text-sm leading-relaxed mb-7 max-w-xs">
              Transforming how people show up — in boardrooms, interviews, and life.
            </p>
            <div className="flex gap-3">
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"
                className="w-10 h-10 border border-white/10 flex items-center justify-center
                           text-grey hover:text-gold hover:border-gold transition-all duration-300">
                <Linkedin size={16} />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"
                className="w-10 h-10 border border-white/10 flex items-center justify-center
                           text-grey hover:text-gold hover:border-gold transition-all duration-300">
                <Instagram size={16} />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer"
                className="w-10 h-10 border border-white/10 flex items-center justify-center
                           text-grey hover:text-gold hover:border-gold transition-all duration-300">
                <Youtube size={16} />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-[0.65rem] tracking-[0.25em] uppercase text-nude mb-6">Services</h4>
            <ul className="space-y-3">
              {services.map((s) => (
                <li key={s.href}>
                  <Link href={s.href} className="text-grey text-sm hover:text-warm-white transition-colors duration-300">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Learn */}
          <div>
            <h4 className="text-[0.65rem] tracking-[0.25em] uppercase text-nude mb-6">Explore</h4>
            <ul className="space-y-3">
              {learn.map((s) => (
                <li key={s.href}>
                  <Link href={s.href} className="text-grey text-sm hover:text-warm-white transition-colors duration-300">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-[0.65rem] tracking-[0.25em] uppercase text-nude mb-6">Legal</h4>
            <ul className="space-y-3">
              {legal.map((s) => (
                <li key={s.href}>
                  <Link href={s.href} className="text-grey text-sm hover:text-warm-white transition-colors duration-300">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-grey text-xs">
            © {new Date().getFullYear()} Kanan Tandi. All rights reserved.
          </p>
          <p className="text-grey/50 text-xs">
            Designed with intention. Built with precision.
          </p>
        </div>
      </div>
    </footer>
  )
}
