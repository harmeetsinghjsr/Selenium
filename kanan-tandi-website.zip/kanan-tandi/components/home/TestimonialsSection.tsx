const testimonials = [
  {
    text: "Kanan's work changed how I carry myself in every room. I got promoted within 3 months of working with her. The changes were profound and lasting.",
    name: 'Rohan Mehta',
    role: 'Senior Manager, Deloitte',
    initial: 'R',
  },
  {
    text: "I walked into my dream job interview with the confidence of someone who had done it a hundred times. Kanan gave me tools I use every single day.",
    name: 'Priya Sharma',
    role: 'Product Manager, Google India',
    initial: 'P',
  },
  {
    text: "Our entire leadership team attended the corporate workshop. The shift in how our leaders communicate and present themselves has been extraordinary.",
    name: 'Arun Kapoor',
    role: 'CEO, TechVentures India',
    initial: 'A',
  },
  {
    text: "I used to shrink in meetings. After working with Kanan, I realised I had been communicating fear without knowing it. That awareness alone changed everything.",
    name: 'Sunita Rao',
    role: 'IAS Officer, Government of India',
    initial: 'S',
  },
  {
    text: "The nervous system session was unlike anything I'd experienced. Kanan combines science with intuition in a way that creates real, embodied change.",
    name: 'Vikram Nair',
    role: 'Entrepreneur & TEDx Speaker',
    initial: 'V',
  },
  {
    text: "As someone who had severe social anxiety, the transformation I experienced through Kanan's program feels nothing short of miraculous.",
    name: 'Anjali Singh',
    role: 'Software Engineer, Microsoft',
    initial: 'A',
  },
]

export default function TestimonialsSection() {
  return (
    <section className="bg-black py-28 px-6 lg:px-12">
      <div className="container-site">
        <p className="section-label">Transformations</p>
        <h2 className="section-title mb-14">
          What Clients <em>Say</em>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="bg-charcoal border border-white/5 p-8 relative overflow-hidden
                         hover:border-gold/20 transition-all duration-300"
            >
              {/* Quote mark */}
              <span className="absolute -top-2 left-6 font-serif text-[7rem] text-gold/10 leading-none select-none">
                "
              </span>

              <div className="relative">
                <div className="flex gap-0.5 mb-5">
                  {[...Array(5)].map((_, j) => (
                    <span key={j} className="text-gold text-xs">★</span>
                  ))}
                </div>
                <p className="text-light-grey text-sm leading-relaxed italic mb-7">
                  "{t.text}"
                </p>
                <div className="flex items-center gap-3 border-t border-white/5 pt-5">
                  <div className="w-11 h-11 rounded-full bg-dark border border-gold/30 flex items-center
                                  justify-content-center justify-center font-serif text-gold text-base">
                    {t.initial}
                  </div>
                  <div>
                    <p className="text-warm-white text-sm font-medium">{t.name}</p>
                    <p className="text-grey text-xs mt-0.5">{t.role}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
