const items = [
  'Body Language', 'Executive Presence', 'Nervous System Regulation',
  'Interview Confidence', 'Human Psychology', 'Behaviour Analysis',
  'Corporate Training', 'Personal Transformation', 'Communication Mastery',
  'Relationship Psychology',
]

export default function MarqueeBar() {
  const doubled = [...items, ...items]
  return (
    <div className="bg-charcoal border-y border-white/5 overflow-hidden py-4">
      <div className="flex gap-14 whitespace-nowrap marquee-track">
        {doubled.map((item, i) => (
          <span key={i} className="flex items-center gap-4 text-[0.62rem] tracking-[0.25em] uppercase text-grey flex-shrink-0">
            <span className="w-1 h-1 rounded-full bg-gold flex-shrink-0" />
            {item}
          </span>
        ))}
      </div>
    </div>
  )
}
