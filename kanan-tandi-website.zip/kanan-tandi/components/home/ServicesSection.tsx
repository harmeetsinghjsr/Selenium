import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

const services = [
  {
    num: '01',
    title: '1:1 Consultation',
    desc: 'Deep-dive personalised sessions addressing your unique challenges in confidence, communication, and executive presence.',
    href: '/book',
  },
  {
    num: '02',
    title: 'Corporate Workshops',
    desc: 'Transformational workshops for teams and organisations — body language, leadership communication, and team dynamics.',
    href: '/corporate',
  },
  {
    num: '03',
    title: 'Online Courses',
    desc: 'Self-paced digital programs designed to build lasting skills in psychology, communication, and personal presence.',
    href: '/courses',
  },
  {
    num: '04',
    title: 'Interview Mastery',
    desc: 'Targeted coaching for high-stakes interviews — posture, micro-expressions, vocal confidence, and psychological preparation.',
    href: '/services',
  },
  {
    num: '05',
    title: 'Group Workshops',
    desc: 'Intimate cohort-based transformation experiences combining neuroscience, body work, and psychological intelligence.',
    href: '/workshops',
  },
  {
    num: '06',
    title: 'Relationship Psychology',
    desc: 'Understanding human connection at the deepest level — attachment, communication patterns, and emotional intelligence.',
    href: '/services',
  },
]

export default function ServicesSection() {
  return (
    <section className="bg-black py-28 px-6 lg:px-12">
      <div className="container-site">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-14">
          <div>
            <p className="section-label">What I Offer</p>
            <h2 className="section-title">
              Expertise<br />
              <em>Crafted</em> for You
            </h2>
          </div>
          <Link href="/services" className="btn-ghost self-start lg:self-auto">
            View All Services
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/[0.04]">
          {services.map((s) => (
            <Link
              key={s.num}
              href={s.href}
              className="group bg-charcoal hover:bg-dark p-10 transition-all duration-400 relative
                         overflow-hidden block"
            >
              {/* Left accent bar */}
              <span className="absolute left-0 top-0 w-0.5 h-0 bg-gold group-hover:h-full transition-all duration-500" />

              <div className="font-serif text-4xl text-gold/20 group-hover:text-gold/40 mb-8 transition-colors duration-300 leading-none">
                {s.num}
              </div>
              <h3 className="font-serif text-xl text-warm-white font-light mb-4 group-hover:text-gold transition-colors duration-300">
                {s.title}
              </h3>
              <p className="text-grey text-sm leading-relaxed mb-6">{s.desc}</p>
              <ArrowRight
                size={18}
                className="text-gold opacity-0 group-hover:opacity-100 group-hover:translate-x-1
                           transition-all duration-300"
              />
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
