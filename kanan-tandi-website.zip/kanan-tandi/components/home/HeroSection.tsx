'use client'
import { useEffect, useRef } from 'react'
import Link from 'next/link'

export default function HeroSection() {
  const ref = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const items = el.querySelectorAll<HTMLElement>('[data-fade]')
    items.forEach((item, i) => {
      item.style.animation = `fadeUp 0.9s ease ${i * 0.18}s forwards`
      item.style.opacity = '0'
    })
  }, [])

  return (
    <section
      ref={ref}
      className="relative min-h-screen flex flex-col justify-center overflow-hidden pt-32 pb-20 px-6 lg:px-12"
    >
      {/* Background glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute right-1/4 top-1/3 w-[600px] h-[600px] rounded-full
                        bg-gold/[0.04] blur-[120px]" />
        <div className="absolute left-1/4 bottom-1/4 w-[400px] h-[400px] rounded-full
                        bg-nude/[0.03] blur-[100px]" />
        {/* Vertical line */}
        <div className="hidden xl:block absolute top-0 right-[32%] w-px h-full
                        bg-gradient-to-b from-transparent via-gold/20 to-transparent" />
      </div>

      <div className="relative max-w-5xl">
        <p data-fade className="text-[0.68rem] tracking-[0.35em] uppercase text-gold mb-8 flex items-center gap-4">
          <span className="block w-10 h-px bg-gold" />
          Body Language &amp; Behavioural Intelligence Expert
        </p>

        <h1
          data-fade
          className="font-serif font-light text-warm-white leading-[1.04] mb-7"
          style={{ fontSize: 'clamp(3.6rem, 9vw, 7.5rem)' }}
        >
          Decode the<br />
          Language<br />
          <em className="not-italic text-gold">Beyond Words</em>
        </h1>

        <p data-fade className="text-light-grey text-base leading-relaxed max-w-md mb-10 font-light">
          Master the science of human behaviour, executive presence, and psychological intelligence —
          and transform how the world perceives you.
        </p>

        <div data-fade className="flex flex-wrap gap-5 items-center">
          <Link href="/book" className="btn-primary">
            Book 1:1 Consultation
          </Link>
          <Link href="/services" className="btn-ghost">
            Explore Programs
          </Link>
        </div>
      </div>

      {/* Stats — desktop only */}
      <div className="hidden xl:flex absolute right-16 top-1/2 -translate-y-1/2 flex-col gap-10">
        {[
          { num: '500+', label: 'Lives Transformed' },
          { num: '8+',   label: 'Years Experience' },
          { num: '50+',  label: 'Corporate Workshops' },
        ].map((s) => (
          <div key={s.label} className="text-right">
            <div className="font-serif text-5xl font-light text-warm-white leading-none">
              {s.num}
            </div>
            <div className="text-[0.6rem] tracking-[0.2em] uppercase text-grey mt-1">
              {s.label}
            </div>
          </div>
        ))}
      </div>

      {/* Scroll hint */}
      <div
        data-fade
        className="absolute bottom-10 left-6 lg:left-12 flex items-center gap-4
                   text-[0.65rem] tracking-[0.2em] uppercase text-grey"
      >
        <span className="block w-14 h-px bg-grey" />
        Scroll to discover
      </div>
    </section>
  )
}
