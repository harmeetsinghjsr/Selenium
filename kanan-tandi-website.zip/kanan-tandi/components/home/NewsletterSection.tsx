'use client'
import { useState } from 'react'
import toast from 'react-hot-toast'

export default function NewsletterSection() {
  const [email, setEmail]     = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!email) return
    setLoading(true)
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        body: JSON.stringify({ email }),
        headers: { 'Content-Type': 'application/json' },
      })
      if (res.ok) {
        toast.success('Welcome to the Inner Circle!')
        setEmail('')
      } else {
        toast.error('Something went wrong. Please try again.')
      }
    } catch {
      toast.error('Network error. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <section className="bg-charcoal py-24 px-6 lg:px-12">
      <div className="container-site">
        <div className="max-w-xl mx-auto text-center">
          <p className="section-label justify-center">The Inner Circle</p>
          <h2 className="font-serif text-3xl lg:text-4xl font-light text-warm-white mb-4">
            Insights on Psychology<br />&amp; Presence
          </h2>
          <p className="text-grey text-sm leading-relaxed mb-10">
            Join 2,000+ professionals receiving weekly wisdom on body language,
            psychology, and personal transformation.
          </p>
          <form onSubmit={handleSubmit} className="flex gap-0">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email address"
              className="input-field flex-1 border-r-0"
              required
            />
            <button
              type="submit"
              disabled={loading}
              className="btn-primary whitespace-nowrap disabled:opacity-60"
            >
              {loading ? 'Joining...' : 'Subscribe'}
            </button>
          </form>
          <p className="text-grey/50 text-xs mt-4">No spam. Unsubscribe anytime.</p>
        </div>
      </div>
    </section>
  )
}
