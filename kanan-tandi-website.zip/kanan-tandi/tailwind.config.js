/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        black:    '#0a0908',
        charcoal: '#161412',
        dark:     '#1e1b18',
        mid:      '#2c2824',
        grey:     '#6b6560',
        'light-grey': '#9e9891',
        'warm-white': '#f5f0e8',
        ivory:    '#faf6ef',
        gold:     '#c9a96e',
        'gold-light': '#dfc090',
        nude:     '#d4b896',
        beige:    '#e8ddd0',
        skin:     '#c4a882',
      },
      fontFamily: {
        sans:  ['Outfit', 'sans-serif'],
        serif: ['Cormorant Garamond', 'serif'],
      },
      animation: {
        marquee: 'marquee 30s linear infinite',
        fadeUp:  'fadeUp 0.8s ease forwards',
      },
      keyframes: {
        marquee: {
          '0%':   { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
        fadeUp: {
          from: { opacity: 0, transform: 'translateY(28px)' },
          to:   { opacity: 1, transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
}
