// ====== COURSE SCHEMA ======
export const courseSchema = {
  name: 'course', title: 'Course', type: 'document',
  fields: [
    { name: 'title',          type: 'string',   title: 'Course Title', validation: (R: any) => R.required() },
    { name: 'slug',           type: 'slug',     title: 'URL Slug',     options: { source: 'title', maxLength: 96 } },
    { name: 'thumbnail',      type: 'image',    title: 'Thumbnail',    options: { hotspot: true } },
    { name: 'description',    type: 'text',     title: 'Short Description' },
    { name: 'content',        type: 'array',    title: 'Course Content', of: [{ type: 'block' }] },
    { name: 'price',          type: 'number',   title: 'Price (₹)', validation: (R: any) => R.required().min(0) },
    { name: 'earlyBirdPrice', type: 'number',   title: 'Early Bird Price (₹)' },
    { name: 'date',           type: 'datetime', title: 'Start Date/Time' },
    { name: 'meetingLink',    type: 'url',      title: 'Meeting Link (Zoom/GMeet)' },
    { name: 'maxSeats',       type: 'number',   title: 'Maximum Seats' },
    { name: 'published',      type: 'boolean',  title: 'Published?', initialValue: false },
    { name: 'featured',       type: 'boolean',  title: 'Featured on Homepage?', initialValue: false },
  ],
  preview: { select: { title: 'title', subtitle: 'price', media: 'thumbnail' } },
}

// ====== BLOG SCHEMA ======
export const blogSchema = {
  name: 'blog', title: 'Blog Post', type: 'document',
  fields: [
    { name: 'title',       type: 'string',   title: 'Title', validation: (R: any) => R.required() },
    { name: 'slug',        type: 'slug',     title: 'Slug',  options: { source: 'title' } },
    { name: 'category',    type: 'string',   title: 'Category',
      options: { list: ['Body Language','Psychology','Executive Presence','Communication','Behaviour Analysis','Relationship Psychology'] } },
    { name: 'coverImage',  type: 'image',    title: 'Cover Image', options: { hotspot: true } },
    { name: 'excerpt',     type: 'text',     title: 'Excerpt' },
    { name: 'content',     type: 'array',    title: 'Content', of: [{ type: 'block' }, { type: 'image' }] },
    { name: 'seoTitle',    type: 'string',   title: 'SEO Title' },
    { name: 'seoDesc',     type: 'text',     title: 'SEO Description' },
    { name: 'readTime',    type: 'number',   title: 'Read Time (minutes)' },
    { name: 'publishedAt', type: 'datetime', title: 'Publish Date' },
    { name: 'published',   type: 'boolean',  title: 'Published?', initialValue: false },
  ],
}

// ====== TESTIMONIAL SCHEMA ======
export const testimonialSchema = {
  name: 'testimonial', title: 'Testimonial', type: 'document',
  fields: [
    { name: 'name',     type: 'string', title: 'Client Name', validation: (R: any) => R.required() },
    { name: 'role',     type: 'string', title: 'Role & Company' },
    { name: 'text',     type: 'text',   title: 'Testimonial Text', validation: (R: any) => R.required() },
    { name: 'category', type: 'string', title: 'Service Category',
      options: { list: ['1:1 Consultation','Corporate Workshop','Online Course','Group Workshop','Interview Coaching'] } },
    { name: 'rating',   type: 'number', title: 'Rating (1–5)', initialValue: 5 },
    { name: 'photo',    type: 'image',  title: 'Client Photo (optional)' },
    { name: 'featured', type: 'boolean', title: 'Show on Homepage?', initialValue: false },
  ],
}

// ====== WORKSHOP SCHEMA ======
export const workshopSchema = {
  name: 'workshop', title: 'Workshop', type: 'document',
  fields: [
    { name: 'title',         type: 'string',   title: 'Workshop Title' },
    { name: 'slug',          type: 'slug',     options: { source: 'title' } },
    { name: 'badge',         type: 'string',   title: 'Badge Label (e.g. Flagship Program)' },
    { name: 'description',   type: 'text',     title: 'Description' },
    { name: 'thumbnail',     type: 'image',    title: 'Thumbnail' },
    { name: 'date',          type: 'datetime', title: 'Workshop Date' },
    { name: 'duration',      type: 'string',   title: 'Duration (e.g. 2 Days)' },
    { name: 'mode',          type: 'string',   title: 'Mode (Online/In-Person/Hybrid)' },
    { name: 'price',         type: 'number',   title: 'Price (₹)' },
    { name: 'originalPrice', type: 'number',   title: 'Original Price (₹)' },
    { name: 'maxSeats',      type: 'number',   title: 'Max Seats' },
    { name: 'includes',      type: 'array',    title: 'What\'s Included', of: [{ type: 'string' }] },
    { name: 'published',     type: 'boolean',  title: 'Published?', initialValue: false },
  ],
}
