//package org.example;
//
//import org.apache.poi.ss.usermodel.*;
//import org.apache.poi.xssf.usermodel.*;
//import org.openqa.selenium.*;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.*;
//
//import java.io.*;
//import java.time.Duration;
//import java.util.List;
//
//public class OutdoorToysSearchTest {
//
//    // ── Excel file paths ──────────────────────────────────────────────────────
//    static final String TEST_DATA_PATH  = System.getProperty("user.dir") + "/excelfiles/Test_Data.xlsx";
//    static final String RESULTS_PATH    = System.getProperty("user.dir") + "/eBay_Toys_Results.xlsx";
//
//    // ── Test_Data.xlsx column indices (0-based) ───────────────────────────────
//    static final int COL_ACTUAL  = 2;  // C - Actual Result
//    static final int COL_STATUS  = 3;  // D - Status
//
//    // ── Test_Data.xlsx row indices (0-based, row 0 = header) ─────────────────
//    static final int ROW_LAUNCH      = 1;
//    static final int ROW_MAXIMIZE    = 2;
//    static final int ROW_ADVANCED    = 3;
//    static final int ROW_KEYWORDS    = 4;
//    static final int ROW_CATEGORY    = 5;
//    static final int ROW_TITLE_DESC  = 6;
//    static final int ROW_NEW         = 7;
//    static final int ROW_RETURNS     = 8;
//    static final int ROW_WORLDWIDE   = 9;
//    static final int ROW_SEARCH      = 10;
//    static final int ROW_GET_HREFS   = 11;
//    static final int ROW_VERIFY_TOYS = 12;
//    static final int ROW_CLOSE       = 13;
//
//    public static void main(String[] args) throws InterruptedException {
//
//        // ── Load Test_Data.xlsx — declared just before use ────────────────────
//        XSSFWorkbook testWorkbook;
//        XSSFSheet    testSheet;
//        try (FileInputStream fis = new FileInputStream(TEST_DATA_PATH)) {
//            testWorkbook = new XSSFWorkbook(fis);
//            testSheet    = testWorkbook.getSheetAt(0);
//        } catch (Exception e) {
//            System.out.println("Error: " + e.getMessage());
//            return;
//        }
//
//        // ── Cell styles — declared just before use ────────────────────────────
//        XSSFCellStyle passStyle = testWorkbook.createCellStyle();
//        passStyle.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
//        passStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//
//        XSSFCellStyle failStyle = testWorkbook.createCellStyle();
//        failStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
//        failStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//
//        // ── Bold font — declared just before use ──────────────────────────────
//        XSSFFont boldFont = testWorkbook.createFont();
//        boldFont.setBold(true);
//        passStyle.setFont(boldFont);
//        failStyle.setFont(boldFont);
//
//        // ── Launch browser — declared just before use ─────────────────────────
//        WebDriver driver = new ChromeDriver();
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//
//        try {
//            // ── Step 1: Open eBay ─────────────────────────────────────────────
//            try {
//                driver.get("http://www.ebay.com");
//                updateStatus(ROW_LAUNCH, "eBay opened successfully", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_LAUNCH, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 2: Maximize window ───────────────────────────────────────
//            try {
//                driver.manage().window().maximize();
//                updateStatus(ROW_MAXIMIZE, "Window maximized", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_MAXIMIZE, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 3: Click Advanced ────────────────────────────────────────
//            try {
//                WebElement advancedLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Advanced")));
//                advancedLink.click();
//                Thread.sleep(1000);
//
//                updateStatus(ROW_ADVANCED, "Clicked Advanced search", true, testSheet, passStyle, failStyle);
//
//            } catch (Exception e) {
//                updateStatus(ROW_ADVANCED, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 4: Enter keywords ────────────────────────────────────────
//            try {
//                WebElement keywordsBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("_nkw")));
//                keywordsBox.clear();
//                keywordsBox.sendKeys("outdoor toys");
//                Thread.sleep(1000);
//
//                WebElement kwDropdown = driver.findElement(By.id("s0-1-20-4[0]-7[1]-_in_kw"));
//                Select select = new Select(kwDropdown);
//                select.selectByVisibleText("Any words, any order");
//                Thread.sleep(1000);
//
//                updateStatus(ROW_KEYWORDS, "Entered 'outdoor toys', selected Any words", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_KEYWORDS, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 5: Select category ───────────────────────────────────────
//            try {
//                WebElement catDropdown = driver.findElement(By.id("s0-1-20-4[0]-7[3]-_sacat"));
//                Select select = new Select(catDropdown);
//                select.selectByVisibleText("Toys & Hobbies");
//                Thread.sleep(1000);
//
//                updateStatus(ROW_CATEGORY, "Selected Toys & Hobbies", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_CATEGORY, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 6: Title and description checkbox ────────────────────────
//            try {
//                WebElement cb = driver.findElement(By.id("s0-1-20-5[1]-[0]-LH_TitleDesc"));
//                if (!cb.isSelected())
//                {
//                    cb.click();
//                }
//                Thread.sleep(1000);
//
//                updateStatus(ROW_TITLE_DESC, "Title and description checked", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_TITLE_DESC, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 7: New condition checkbox ────────────────────────────────
//            try {
//                WebElement cb = driver.findElement(By.id("s0-1-20-6[4]-[0]-LH_ItemCondition"));
//                if (!cb.isSelected())
//                {
//                    cb.click();
//                }
//                Thread.sleep(1000);
//                updateStatus(ROW_NEW, "New condition checked", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_NEW, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 8: Free returns + Returns accepted ───────────────────────
//            try {
//                WebElement frCb = driver.findElement(By.id("s0-1-20-5[5]-[0]-LH_FR"));
//                if (!frCb.isSelected()) frCb.click();
//                Thread.sleep(500);
//
//                WebElement rpaCb = driver.findElement(By.id("s0-1-20-5[5]-[1]-LH_RPA"));
//                if (!rpaCb.isSelected())
//                {
//                    rpaCb.click();
//                }
//                Thread.sleep(1000);
//                updateStatus(ROW_RETURNS, "Free returns & Returns accepted checked", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_RETURNS, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 9: Worldwide radio button ────────────────────────────────
//            try {
//                WebElement radio = driver.findElement(By.id("s0-1-20-6[7]-[3]-LH_PrefLoc"));
//                if (!radio.isSelected())
//                {
//                    radio.click();
//                }
//                Thread.sleep(1000);
//                updateStatus(ROW_WORLDWIDE, "Worldwide location selected", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_WORLDWIDE, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 10: Click Search ─────────────────────────────────────────
//            try {
//                WebElement searchBtn = driver.findElement(By.xpath("//div[@class='adv-form__actions']//button[@type='submit'][normalize-space()='Search']"));
//                searchBtn.click();
//                Thread.sleep(1000);
//                wait.until(ExpectedConditions.titleContains("Toys & Hobbies"));
//                System.out.println("Results page title: " + driver.getTitle());
//                updateStatus(ROW_SEARCH, "Search clicked. Title: " + driver.getTitle(), true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_SEARCH, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 11: Collect all hrefs ────────────────────────────────────
//            List<WebElement> allLinks;
//            try {
//                Thread.sleep(1000);
//                allLinks = driver.findElements(By.tagName("a"));
//                System.out.println("Total links found: " + allLinks.size());
//                updateStatus(ROW_GET_HREFS, "Found " + allLinks.size() + " links on page", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_GET_HREFS, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//            // ── Step 12: Filter items with "toys" → write eBay_Toys_Results ───
//            try {
//                // ── Results workbook — declared just before use ───────────────
//                XSSFWorkbook resultsWb    = new XSSFWorkbook();
//                XSSFSheet    resultsSheet = resultsWb.createSheet("Toys Items");
//
//                // ── Header style — declared just before use ───────────────────
//                XSSFCellStyle hStyle = resultsWb.createCellStyle();
//                XSSFFont      hFont  = resultsWb.createFont();
//                hFont.setBold(true);
//                hStyle.setFont(hFont);
//
//                XSSFRow hRow = resultsSheet.createRow(0);
//                XSSFCell c0  = hRow.createCell(0); c0.setCellValue("Item Name"); c0.setCellStyle(hStyle);
//                XSSFCell c1  = hRow.createCell(1); c1.setCellValue("Item Link");  c1.setCellStyle(hStyle);
//
//                int rowNum = 1, matchCount = 0;
//
//                for (WebElement link : allLinks) {
//                    String text = link.getText().trim();
//                    String href = link.getAttribute("href");
//
//                    if (href == null || href.isEmpty() || text.isEmpty()) continue;
//                    System.out.println("HREF: " + href);
//
//                    if (text.toLowerCase().contains("toys")) {
//                        matchCount++;
//                        System.out.println("  ✔ Matched [" + matchCount + "]: " + text);
//                        XSSFRow r = resultsSheet.createRow(rowNum++);
//                        r.createCell(0).setCellValue(text);
//                        r.createCell(1).setCellValue(href);
//                    }
//                }
//
//                resultsSheet.autoSizeColumn(0);
//                resultsSheet.autoSizeColumn(1);
//
//                try (FileOutputStream fos = new FileOutputStream(RESULTS_PATH)) {
//                    resultsWb.write(fos);
//                }
//                resultsWb.close();
//
//                System.out.println("📁 Results saved: " + RESULTS_PATH);
//                updateStatus(ROW_VERIFY_TOYS,
//                        matchCount + " items with 'toys' written to eBay_Toys_Results.xlsx",
//                        true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_VERIFY_TOYS, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//                throw e;
//            }
//
//        } catch (Exception e) {
//            System.out.println("Test stopped due to error: " + e.getMessage());
//        } finally {
//            // ── Step 13: Close browser ────────────────────────────────────────
//            try {
//                Thread.sleep(10000);
//                driver.quit();
//                updateStatus(ROW_CLOSE, "Browser closed", true, testSheet, passStyle, failStyle);
//            } catch (Exception e) {
//                updateStatus(ROW_CLOSE, "Failed: " + e.getMessage(), false, testSheet, passStyle, failStyle);
//            }
//
//            // ── Save Test_Data.xlsx with updated statuses ─────────────────────
//            try (FileOutputStream fos = new FileOutputStream(TEST_DATA_PATH)) {
//                testWorkbook.write(fos);
//                testWorkbook.close();
//                System.out.println("✅ Test_Data.xlsx updated: " + TEST_DATA_PATH);
//            } catch (Exception e) {
//                System.out.println("❌ Could not save Test_Data.xlsx: " + e.getMessage());
//            }
//        }
//    }
//
//    /**
//     * Writes Actual Result (col C) and Status (col D) for the given row.
//     * Green cell = PASS, Red cell = FAIL.
//     */
//    static void updateStatus(int rowIndex, String actualResult, boolean passed,
//                             XSSFSheet testSheet, XSSFCellStyle passStyle, XSSFCellStyle failStyle) {
//
//        XSSFRow row = testSheet.getRow(rowIndex);
//        if (row == null) row = testSheet.createRow(rowIndex);
//
//        // ── Actual Result — declared just before use ──────────────────────────
//        XSSFCell actualCell = row.getCell(COL_ACTUAL);
//        if (actualCell == null) actualCell = row.createCell(COL_ACTUAL);
//        actualCell.setCellValue(actualResult);
//
//        // ── Status — declared just before use ────────────────────────────────
//        XSSFCell statusCell = row.getCell(COL_STATUS);
//        if (statusCell == null) statusCell = row.createCell(COL_STATUS);
//        statusCell.setCellValue(passed ? "PASS" : "FAIL");
//        statusCell.setCellStyle(passed ? passStyle : failStyle);
//
//        System.out.println((passed ? "✔ PASS" : "✘ FAIL") + " → Row " + (rowIndex + 1) + ": " + actualResult);
//    }
//}