import org.apache.poi.xssf.usermodel.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;
import java.util.List;

public class OutdoorToysSearchTest {

    // ── File paths ────────────────────────────────────────────────────────────
    static final String TEST_DATA_PATH = System.getProperty("user.dir") + "/excelfiles/Test_Data.xlsx";
    static final String RESULTS_PATH   = System.getProperty("user.dir") + "/eBay_Toys_Results.xlsx";

    // ── Row indices (0-based) for each test step ──────────────────────────────
    static final int ROW_LAUNCH      = 1;
    static final int ROW_MAXIMIZE    = 2;
    static final int ROW_ADVANCED    = 3;
    static final int ROW_KEYWORDS    = 4;
    static final int ROW_CATEGORY    = 5;
    static final int ROW_TITLE_DESC  = 6;
    static final int ROW_NEW         = 7;
    static final int ROW_RETURNS     = 8;
    static final int ROW_WORLDWIDE   = 9;
    static final int ROW_SEARCH      = 10;
    static final int ROW_GET_HREFS   = 11;
    static final int ROW_VERIFY_TOYS = 12;
    static final int ROW_CLOSE       = 13;

    public static void main(String[] args) throws Exception {

        XSSFWorkbook testWorkbook = ExcelUtils.loadWorkbook(TEST_DATA_PATH);
        XSSFSheet testSheet       = testWorkbook.getSheetAt(0);

        WebDriver driver = null;
        WebDriverWait wait;

        try {
            driver = new ChromeDriver();
            wait   = new WebDriverWait(driver, Duration.ofSeconds(15));

            // Step 1: Open eBay
            driver.get("http://www.ebay.com");
            ExcelUtils.updateStatus(ROW_LAUNCH, "eBay opened successfully", true, testSheet);

            // Step 2: Maximize window
            driver.manage().window().maximize();
            ExcelUtils.updateStatus(ROW_MAXIMIZE, "Window maximized", true, testSheet);

            // Step 3: Click Advanced ──────────────────────────────────────────
            WebElement advancedLink = wait.until(
                    ExpectedConditions.elementToBeClickable(By.linkText("Advanced")));
            advancedLink.click();
            Thread.sleep(1000);
            ExcelUtils.updateStatus(ROW_ADVANCED, "Clicked Advanced search", true, testSheet);

            // Step 4: Enter keywords and select search type ───────────────────
            WebElement keywordsBox = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(By.id("_nkw")));
            keywordsBox.clear();
            keywordsBox.sendKeys("outdoor toys");
            Thread.sleep(1000);

            WebElement kwDropdown = driver.findElement(By.id("s0-1-20-4[0]-7[1]-_in_kw"));
            new Select(kwDropdown).selectByVisibleText("Any words, any order");
            Thread.sleep(1000);
            ExcelUtils.updateStatus(ROW_KEYWORDS, "Entered 'outdoor toys', selected Any words",
                    true, testSheet);

            // Step 5: Select Toys & Hobbies category ──────────────────────────
            WebElement catDropdown = driver.findElement(By.id("s0-1-20-4[0]-7[3]-_sacat"));
            new Select(catDropdown).selectByVisibleText("Toys & Hobbies");
            Thread.sleep(1000);
            ExcelUtils.updateStatus(ROW_CATEGORY, "Selected Toys & Hobbies", true, testSheet);

            // Step 6: Check Title and description ─────────────────────────────
            WebElement titleDescCb = driver.findElement(
                    By.id("s0-1-20-5[1]-[0]-LH_TitleDesc"));
            if (!titleDescCb.isSelected()) titleDescCb.click();
            Thread.sleep(1000);
            ExcelUtils.updateStatus(ROW_TITLE_DESC, "Title and description checked",
                    true, testSheet);

            // Step 7: Check New condition ──────────────────────────────────────
            WebElement newCondCb = driver.findElement(
                    By.id("s0-1-20-6[4]-[0]-LH_ItemCondition"));
            if (!newCondCb.isSelected()) newCondCb.click();
            Thread.sleep(1000);
            ExcelUtils.updateStatus(ROW_NEW, "New condition checked", true, testSheet);

            // Step 8: Check Free returns and Returns accepted ──────────────────
            WebElement freeReturnsCb = driver.findElement(By.id("s0-1-20-5[5]-[0]-LH_FR"));
            if (!freeReturnsCb.isSelected()) freeReturnsCb.click();
            Thread.sleep(500);

            WebElement returnsAcceptedCb = driver.findElement(By.id("s0-1-20-5[5]-[1]-LH_RPA"));
            if (!returnsAcceptedCb.isSelected()) returnsAcceptedCb.click();
            Thread.sleep(1000);
            ExcelUtils.updateStatus(ROW_RETURNS, "Free returns & Returns accepted checked",
                    true, testSheet);

            // Step 9: Select Worldwide location ───────────────────────────────
            WebElement worldwideRadio = driver.findElement(
                    By.id("s0-1-20-6[7]-[3]-LH_PrefLoc"));
            if (!worldwideRadio.isSelected()) worldwideRadio.click();
            Thread.sleep(1000);
            ExcelUtils.updateStatus(ROW_WORLDWIDE, "Worldwide location selected", true, testSheet);

            // Step 10: Click Search and wait for results ───────────────────────
            WebElement searchBtn = driver.findElement(By.xpath(
                    "//div[@class='adv-form__actions']//button[@type='submit'][normalize-space()='Search']"));
            searchBtn.click();
            Thread.sleep(1000);
            wait.until(ExpectedConditions.titleContains("Toys & Hobbies"));
            System.out.println("Results page title: " + driver.getTitle());
            ExcelUtils.updateStatus(ROW_SEARCH, "Search clicked. Title: " + driver.getTitle(),
                    true, testSheet);

            // Step 11: Grab all links from the results page ───────────────────
            Thread.sleep(1000);
            List<WebElement> allLinks = driver.findElements(By.tagName("a"));
            ExcelUtils.updateStatus(ROW_GET_HREFS, "Found " + allLinks.size() + " links on page",
                    true, testSheet);

            // Step 12: Filter links containing "toys" and save to results file ─
            XSSFWorkbook resultsWb = new XSSFWorkbook();
            XSSFSheet resultsSheet = ExcelUtils.createResultsSheet(resultsWb);
            int rowNum     = 1;
            int matchCount = 0;

            for (WebElement link : allLinks) {
                String text = link.getText().trim();
                String href = link.getAttribute("href");

                if (href == null || href.isEmpty() || text.isEmpty()) continue;
                System.out.println("HREF: " + href);

                if (text.toLowerCase().contains("toys")) {
                    matchCount++;
                    System.out.println("Matched [" + matchCount + "]: " + text);
                    ExcelUtils.writeToyRow(resultsSheet, rowNum++, text, href);
                }
            }

            ExcelUtils.autoSizeResultColumns(resultsSheet);
            ExcelUtils.saveWorkbook(resultsWb, RESULTS_PATH);
            resultsWb.close();

            System.out.println("Results saved to: " + RESULTS_PATH);
            ExcelUtils.updateStatus(ROW_VERIFY_TOYS,
                    matchCount + " items with 'toys' written to eBay_Toys_Results.xlsx",
                    true, testSheet);

        } catch (Exception e) {
            // FIX: mark the test as failed in the sheet instead of silently swallowing the error
            System.out.println("Test stopped: " + e.getMessage());
            ExcelUtils.updateStatus(ROW_VERIFY_TOYS, "Test failed: " + e.getMessage(),
                    false, testSheet);

        } finally {
            // Step 13: Close browser and save test results ─────────────────────
            Thread.sleep(10000);
            // FIX: null-check prevents NullPointerException if driver never initialized
            if (driver != null) {
                driver.quit();
            }
            ExcelUtils.updateStatus(ROW_CLOSE, "Browser closed", true, testSheet);

            ExcelUtils.saveWorkbook(testWorkbook, TEST_DATA_PATH);
            testWorkbook.close();
            System.out.println("Test_Data.xlsx saved: " + TEST_DATA_PATH);
        }
    }
}