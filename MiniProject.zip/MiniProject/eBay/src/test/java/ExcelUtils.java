import org.apache.poi.xssf.usermodel.*;

import java.io.*;

public class ExcelUtils {

    // ── Column indices (0-based: A=0, B=1, C=2) ──────────────────────────────
    static final int COL_ACTUAL = 1; // FIX: was 2 (column C); correct is 1 (column B)
    static final int COL_STATUS = 2; // FIX: was 3 (column D); correct is 2 (column C)

    // ── Prevent instantiation ─────────────────────────────────────────────────
    private ExcelUtils() {}

    // ── Load workbook from disk ───────────────────────────────────────────────
    static XSSFWorkbook loadWorkbook(String path) throws IOException {
        try (FileInputStream fis = new FileInputStream(path)) {
            return new XSSFWorkbook(fis);
        }
    }

    // ── Save workbook to disk ─────────────────────────────────────────────────
    static void saveWorkbook(XSSFWorkbook wb, String path) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(path)) {
            wb.write(fos);
        }
    }

    // ── Write actual result + PASS/FAIL (with background color) to test sheet ─
    static void updateStatus(int rowIndex, String actualResult, boolean passed,
                             XSSFSheet testSheet) {

        XSSFRow row = testSheet.getRow(rowIndex);
        if (row == null) row = testSheet.createRow(rowIndex);

        XSSFCell actualCell = row.getCell(COL_ACTUAL);
        if (actualCell == null) actualCell = row.createCell(COL_ACTUAL);
        actualCell.setCellValue(actualResult);

        XSSFCell statusCell = row.getCell(COL_STATUS);
        if (statusCell == null) statusCell = row.createCell(COL_STATUS);
        statusCell.setCellValue(passed ? "PASS" : "FAIL");
    }

    // ── Create a results workbook and return its "Toys Items" sheet ───────────
    static XSSFSheet createResultsSheet(XSSFWorkbook wb) {
        XSSFSheet sheet = wb.createSheet("Toys Items");
        XSSFRow headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Item Name");
        headerRow.createCell(1).setCellValue("Item Link");
        return sheet;
    }

    // ── Write a single toy item row ───────────────────────────────────────────
    static void writeToyRow(XSSFSheet sheet, int rowNum, String text, String href) {
        XSSFRow row = sheet.createRow(rowNum);
        row.createCell(0).setCellValue(text);
        row.createCell(1).setCellValue(href);
    }

    // ── Auto-size columns 0 and 1 ─────────────────────────────────────────────
    static void autoSizeResultColumns(XSSFSheet sheet) {
        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);
    }
}